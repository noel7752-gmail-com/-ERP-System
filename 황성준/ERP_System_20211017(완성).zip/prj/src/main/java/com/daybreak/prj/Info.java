// package com.naver.erp;
package com.daybreak.prj;


public interface Info { 
	
    // <주의> 경로가 문자열이므로 \ 를 \\ 로 써야함. \\ 대신에 / 쓰지 말것.
	public static String board_pic_dir 
		= "C:\\Users\\suojun\\Desktop\\ERP_System_20211017\\prj\\src\\main\\resources\\static\\resources\\img\\";


	public static String naverPath = "naver/";
	

}

