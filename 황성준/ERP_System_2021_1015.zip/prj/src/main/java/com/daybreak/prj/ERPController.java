package com.daybreak.prj;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ERPController {
	
	@Autowired
	private ERPService erpService;
	
	@Autowired
	private ERPDAO erpDAO;	
    
    @RequestMapping(value = "/daybreak.do")
    public ModelAndView daybreak() {
        ModelAndView mav = new ModelAndView();
        mav.setViewName("daybreak.jsp");
        return mav;
    }


    // 통합검색 접속.
    @RequestMapping( value="/searchAll.do" )
    public ModelAndView goSearchAll( 
    		
    	
    ){
    	
        //*******************************************
        // [ModelAndView 객체] 생성하기
        // [ModelAndView 객체]에 [호출 JSP 페이지명]을 저장하기
        //*******************************************
        ModelAndView mav = new ModelAndView( );
        mav.setViewName("allSearch.jsp");
        // mav.addObject("boardDTO", boardDTO);
    		
        System.out.println( "erpController 1 " );
        //*******************************************
        // [ModelAndView 객체] 리턴하기
        //*******************************************
        return mav;
    }


    @RequestMapping( 
			value="/searchAllProc.do"
			,method=RequestMethod.POST
			,produces="application/json;charset=UTF-8"
	)
	@ResponseBody
	public  Map<String,String> insertErp( 
			
			ERPDTO erpDTO
			//*******************************************
			// <input type=file name=img> 입력양식의 파일이 저장된 MultipartFile 객체 저장 매개변수 선언.
			// <주의> 업로드된 파일이 없어도 MultipartFile 객체는 생성되어 들어온다.
			//*******************************************
			,@RequestParam("img")  MultipartFile multi
			
	){
		//*******************************************
		// 업로드 파일의 크기와 확장자 체크하기
		//*******************************************
		// 만약에 업로드된 파일이 있으면
		if( multi.isEmpty()==false ) {
				// 만약에 업로드된 파일의 크기가 1000000 byte(=1000kb) 보다 크면
				if( multi.getSize()>1000000 ) {
					Map<String,String> map = new HashMap<String,String>();
					map.put( "erpRegCnt", "0" );
					map.put( "msg","업로드 파일이 1000kb 보다크면 안됩니다." );
					return map;
				}
				// 만약에 업로드된 파일의 확장자가 이미지 확장자가 아니면
				String fileName = multi.getOriginalFilename();
				if( fileName.endsWith(".jpg")==false && fileName.endsWith(".gif")==false&& fileName.endsWith(".png")==false ) {
					Map<String,String> map = new HashMap<String,String>();
					map.put( "erpRegCnt", "0" );
					map.put( "msg", "이미지 파일이 아닙니다." );
					return map;
				}
		}
		
		//*******************************************
		// 게시판 등록 성공여부가 저장된 변수 선언. 1이 저장되면 성공했다는 의미
		// 유효성 체크 에러 메시지 저장할 변수 msg 선언.
		//*******************************************
		int erpRegCnt = 0;
		
		try {
			
				//*******************************************
				// [ERPServiceImpl 객체]의 insertBoard 메소드 호출로 
				// 게시판 글 입력하고 [게시판 입력 적용행의 개수] 얻기
				//*******************************************
				erpRegCnt = this.erpService.insertErp(erpDTO, multi);
			
			
			System.out.println( "insertErp 메소드 호출 성공 " );
		}catch(Exception ex) {
			
			
		}
		
		Map<String,String> map = new HashMap<String,String>();
		map.put( "erpRegCnt", erpRegCnt+"" );
		
		return map;
	}







    // 게시판 접속.
    // boardList.do로 바로 접속하게함.  
    // @RequestMapping(value = "/board.do")
    // public ModelAndView goBoard() {
    //     System.out.println("ERPController 쪽, ==> board.do 접속!@#!@#");

    //     ModelAndView mav = new ModelAndView();
    //     mav.setViewName("board.jsp");
    //     return mav;
    // }

    // 통계화면 접속.
    @RequestMapping(value = "/statistics.do")
    public ModelAndView goStatistics() {
        ModelAndView mav = new ModelAndView();
        mav.setViewName("statistics.jsp");
        return mav;
    }

    // 재고관리 접속.
    @RequestMapping(value = "/stock_management.do")
    public ModelAndView goSstock_management() {
        ModelAndView mav = new ModelAndView();
        mav.setViewName("stock_in_out.jsp");
        return mav;
    }

    // 재고관리 안에서 가전 검색.
    @RequestMapping(value = "/jaego_search.do")
    public ModelAndView goJaego_search() {
        ModelAndView mav = new ModelAndView();
        mav.setViewName("jaego_search.jsp");
        return mav;
    }



}
