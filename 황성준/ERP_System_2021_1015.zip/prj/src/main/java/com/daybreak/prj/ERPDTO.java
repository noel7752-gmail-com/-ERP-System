package com.daybreak.prj;

public class ERPDTO {
	
	
	private String pic;
	private String g_sub_category_code;
	private String g_sub_sub_category_code;
	private String category_code;
	private String brand_code;
	private String g_item_code;
	private String g_item_name;
	private String build_day;
	private String energy_grade_code;
	private String power_consum;
	private String color_code;
	private String g_item_sizex;
	private String g_item_sizey;
	private String g_item_sizez;
	private String discontinued;
	
	
	
	public String getPic() {
		return pic;
	}
	public void setPic(String pic) {
		this.pic = pic;
	}
	public String getG_sub_category_code() {
		return g_sub_category_code;
	}
	public void setG_sub_category_code(String g_sub_category_code) {
		this.g_sub_category_code = g_sub_category_code;
	}
	public String getG_sub_sub_category_code() {
		return g_sub_sub_category_code;
	}
	public void setG_sub_sub_category_code(String g_sub_sub_category_code) {
		this.g_sub_sub_category_code = g_sub_sub_category_code;
	}
	public String getCategory_code() {
		return category_code;
	}
	public void setCategory_code(String category_code) {
		this.category_code = category_code;
	}
	public String getBrand_code() {
		return brand_code;
	}
	public void setBrand_code(String brand_code) {
		this.brand_code = brand_code;
	}
	public String getG_item_code() {
		return g_item_code;
	}
	public void setG_item_code(String g_item_code) {
		this.g_item_code = g_item_code;
	}
	public String getG_item_name() {
		return g_item_name;
	}
	public void setG_item_name(String g_item_name) {
		this.g_item_name = g_item_name;
	}
	public String getBuild_day() {
		return build_day;
	}
	public void setBuild_day(String build_day) {
		this.build_day = build_day;
	}
	public String getEnergy_grade_code() {
		return energy_grade_code;
	}
	public void setEnergy_grade_code(String energy_grade_code) {
		this.energy_grade_code = energy_grade_code;
	}
	public String getPower_consum() {
		return power_consum;
	}
	public void setPower_consum(String power_consum) {
		this.power_consum = power_consum;
	}
	public String getColor_code() {
		return color_code;
	}
	public void setColor_code(String color_code) {
		this.color_code = color_code;
	}
	public String getG_item_sizex() {
		return g_item_sizex;
	}
	public void setG_item_sizex(String g_item_sizex) {
		this.g_item_sizex = g_item_sizex;
	}
	public String getG_item_sizey() {
		return g_item_sizey;
	}
	public void setG_item_sizey(String g_item_sizey) {
		this.g_item_sizey = g_item_sizey;
	}
	public String getG_item_sizez() {
		return g_item_sizez;
	}
	public void setG_item_sizez(String g_item_sizez) {
		this.g_item_sizez = g_item_sizez;
	}
	public String getDiscontinued() {
		return discontinued;
	}
	public void setDiscontinued(String discontinued) {
		this.discontinued = discontinued;
	}
	
	
	
	
	
	


	





































	// ===================================================================================
    // 게시판 DTO 참고용 주석. 삭제하지마시고, 그냥 코드들 참고하시고 위에 코딩 해주세요.
    // ===================================================================================
/*
	private int b_no;
    private String subject;
    private String writer;
    private String reg_date;
    private int readcount;
    private String content;

	private String pic;

    private String is_del;

    private String pwd;
    private String email;
    private int group_no;
    private int print_no;
    private int print_level;
    
    public int getB_no() {
		return b_no;
	}
	public void setB_no(int b_no) {
		this.b_no = b_no;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getReg_date() {
		return reg_date;
	}
	public void setReg_date(String reg_date) {
		this.reg_date = reg_date;
	}
	public int getReadcount() {
		return readcount;
	}
	public void setReadcount(int readcount) {
		this.readcount = readcount;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getPic() {
		return pic;
	}
	public void setPic(String pic) {
		this.pic = pic;
	}
	public String getIs_del() {
		return is_del;
	}
	public void setIs_del(String is_del) {
		this.is_del = is_del;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getGroup_no() {
		return group_no;
	}
	public void setGroup_no(int group_no) {
		this.group_no = group_no;
	}
	public int getPrint_no() {
		return print_no;
	}
	public void setPrint_no(int print_no) {
		this.print_no = print_no;
	}
	public int getPrint_level() {
		return print_level;
	}
	public void setPrint_level(int print_level) {
		this.print_level = print_level;
	}
*/
    
}
