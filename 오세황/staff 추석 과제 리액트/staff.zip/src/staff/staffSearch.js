import React, { Component } from "react";
import styled from "styled-components";
import tableStyle from "./tableStyled/tablestyled";

const CONTAINER = styled.div`
  width: 1500px;
  margin: 40px auto;
  height: 1500px;
  align-items: center;
`;
const TABLE = styled.table`
  width: 1000px;
  margin: 0 auto;
  ${tableStyle.border}
  ${tableStyle.borderCollapse}
`;
const TR = styled.tr`
  ${tableStyle.border}
`;
const TD = styled.td`
  ${tableStyle.border}
  ${tableStyle.cellPadding}
  text-align: center;
`;
const TH = styled.th`
  ${tableStyle.border}
  ${tableStyle.cellPadding}
  background-color: lightgray;
  font-size: 17px;
  font-weight: bold;
`;
const SELECT = styled.select`
  width: 60px;
  :not(:first-child) {
    margin-left: 15px;
  }
`;

class staffSearch extends Component {
  setYear = () => {
    var sysdate = new Date();
    var sysYear = sysdate.getFullYear();
    var option = [];
    for (var i = sysYear - 20; i <= sysYear + 20; i++) {
      option.push(i);
    }
    return option;
  };
  componentDidMount = () => {
    function qwe(event) {
      var option = document.getElementsByClassName("qwee");
      var days = "";
      for (var i = 1; i <= 12; i++) {
        days += `<option value="${i}" >${i}</option>`;
      }
      option[0].innerHTML = days;
      option[0].removeAttribute("disabled");
    }
    var qweEle = document.getElementsByClassName("qwe");
    qweEle[0].addEventListener("change", qwe);
  };

  render() {
    var year = this.setYear();

    return (
      <CONTAINER>
        <TABLE>
          <TR>
            <TH colSpan="6">사원정보 검색</TH>
          </TR>
          <TR>
            <TH>키워드</TH>
            <TD>
              <input type="text" name="keyword" />
            </TD>
            <TH>성별</TH>
            <TD>
              <input type="checkbox" name="gender" />남<input type="checkbox" name="gender" />여
            </TD>
            <TH>종교</TH>
            <TD>
              <SELECT name="religion">
                <option value="0"></option>
                <option value="1">기독교</option>
                <option value="2">천주교</option>
                <option value="3">불교</option>
                <option value="4">이슬람</option>
                <option value="5">무교</option>
              </SELECT>
            </TD>
          </TR>
          <TR>
            <TH>학력</TH>
            <TD>
              <input type="checkbox" name="staffSchool" value="1" />
              고졸
              <input type="checkbox" name="staffSchool" value="2" />
              전문대졸
              <input type="checkbox" name="staffSchool" value="3" />
              일반대졸
            </TD>
            <TH>기술</TH>
            <TD colSpan="3">
              <input type="checkbox" name="skill" value="1" />
              Java
              <input type="checkbox" name="skill" value="2" />
              JSP
              <input type="checkbox" name="skill" value="3" />
              ASP
              <input type="checkbox" name="skill" value="4" />
              PHP
              <input type="checkbox" name="skill" value="5" />
              Delphi
            </TD>
          </TR>
          <TR>
            <TH>졸업일</TH>
            <TD colSpan="5">
              <SELECT name="staffGradDay_start" className="qwe">
                <option value=""></option>
                {year.map((item) => (
                  <option value={item}>{item}</option>
                ))}
              </SELECT>
              년
              <SELECT name="staffGradDay_start" className="qwee" disabled>
                <option value=""></option>
              </SELECT>
              월
              <SELECT name="staffGradDay_start" disabled>
                <option value=""></option>
              </SELECT>
              일 ~
              <SELECT name="staffGradDay_end">
                <option value=""></option>
                {year.map((item) => (
                  <option value={item}>{item}</option>
                ))}
              </SELECT>
              년
              <SELECT name="staffGradDay_end" disabled>
                <option value=""></option>
              </SELECT>
              월
              <SELECT name="staffGradDay_end" disabled>
                <option value=""></option>
              </SELECT>
              일
            </TD>
          </TR>
        </TABLE>
      </CONTAINER>
    );
  }
}
export default staffSearch;
