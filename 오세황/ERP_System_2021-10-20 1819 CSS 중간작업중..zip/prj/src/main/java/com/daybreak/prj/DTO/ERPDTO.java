package com.daybreak.prj.DTO;

public class ERPDTO {
	

	private String g_pic ;
	private String g_sub_category_code;
	private String g_sub_sub_category_code;
	private String category_code;
	private String brand_code;
	private String g_item_code;
	private String g_item_name;
	private String g_build_day;
	private String energy_grade_code;
	private String g_power_consum;
	private String color_code;
	private String g_item_size_x;
	private String g_item_size_y;
	private String g_item_size_z;
	private String g_discontinued ;
	
	
	public String getG_pic() {
		return g_pic;
	}
	public void setG_pic(String g_pic) {
		this.g_pic = g_pic;
	}
	public String getG_sub_category_code() {
		return g_sub_category_code;
	}
	public void setG_sub_category_code(String g_sub_category_code) {
		this.g_sub_category_code = g_sub_category_code;
	}
	public String getG_sub_sub_category_code() {
		return g_sub_sub_category_code;
	}
	public void setG_sub_sub_category_code(String g_sub_sub_category_code) {
		this.g_sub_sub_category_code = g_sub_sub_category_code;
	}
	public String getCategory_code() {
		return category_code;
	}
	public void setCategory_code(String category_code) {
		this.category_code = category_code;
	}
	public String getBrand_code() {
		return brand_code;
	}
	public void setBrand_code(String brand_code) {
		this.brand_code = brand_code;
	}
	public String getG_item_code() {
		return g_item_code;
	}
	public void setG_item_code(String g_item_code) {
		this.g_item_code = g_item_code;
	}
	public String getG_item_name() {
		return g_item_name;
	}
	public void setG_item_name(String g_item_name) {
		this.g_item_name = g_item_name;
	}
	public String getG_build_day() {
		return g_build_day;
	}
	public void setG_build_day(String g_build_day) {
		this.g_build_day = g_build_day;
	}
	public String getEnergy_grade_code() {
		return energy_grade_code;
	}
	public void setEnergy_grade_code(String energy_grade_code) {
		this.energy_grade_code = energy_grade_code;
	}
	public String getG_power_consum() {
		return g_power_consum;
	}
	public void setG_power_consum(String g_power_consum) {
		this.g_power_consum = g_power_consum;
	}
	public String getColor_code() {
		return color_code;
	}
	public void setColor_code(String color_code) {
		this.color_code = color_code;
	}
	public String getG_item_size_x() {
		return g_item_size_x;
	}
	public void setG_item_size_x(String g_item_size_x) {
		this.g_item_size_x = g_item_size_x;
	}
	public String getG_item_size_y() {
		return g_item_size_y;
	}
	public void setG_item_size_y(String g_item_size_y) {
		this.g_item_size_y = g_item_size_y;
	}
	public String getG_item_size_z() {
		return g_item_size_z;
	}
	public void setG_item_size_z(String g_item_size_z) {
		this.g_item_size_z = g_item_size_z;
	}
	public String getG_discontinued() {
		return g_discontinued;
	}
	public void setG_discontinued(String g_discontinued) {
		this.g_discontinued = g_discontinued;
	}




	





































	// ===================================================================================
    // 게시판 DTO 참고용 주석. 삭제하지마시고, 그냥 코드들 참고하시고 위에 코딩 해주세요.
    // ===================================================================================
/*
	private int b_no;
    private String subject;
    private String writer;
    private String reg_date;
    private int readcount;
    private String content;

	private String pic;

    private String is_del;

    private String pwd;
    private String email;
    private int group_no;
    private int print_no;
    private int print_level;
    
    public int getB_no() {
		return b_no;
	}
	public void setB_no(int b_no) {
		this.b_no = b_no;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getReg_date() {
		return reg_date;
	}
	public void setReg_date(String reg_date) {
		this.reg_date = reg_date;
	}
	public int getReadcount() {
		return readcount;
	}
	public void setReadcount(int readcount) {
		this.readcount = readcount;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getPic() {
		return pic;
	}
	public void setPic(String pic) {
		this.pic = pic;
	}
	public String getIs_del() {
		return is_del;
	}
	public void setIs_del(String is_del) {
		this.is_del = is_del;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getGroup_no() {
		return group_no;
	}
	public void setGroup_no(int group_no) {
		this.group_no = group_no;
	}
	public int getPrint_no() {
		return print_no;
	}
	public void setPrint_no(int print_no) {
		this.print_no = print_no;
	}
	public int getPrint_level() {
		return print_level;
	}
	public void setPrint_level(int print_level) {
		this.print_level = print_level;
	}
*/
    
}
