package com.daybreak.prj;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ERPController {
	
    @Autowired
    private ERPService erpService;
  
    @Autowired
    private ERPDAO erpDAO;
	
    
    @RequestMapping(value = "/daybreak.do")
    public ModelAndView daybreak() {
        ModelAndView mav = new ModelAndView();
        mav.setViewName("daybreak.jsp");
        return mav;
    }


    // 통합검색 접속.
    @RequestMapping( value="/searchAll.do" )
    public ModelAndView goSearchAll( 
            
    ){
        //*******************************************
        // [ModelAndView 객체] 생성하기
        // [ModelAndView 객체]에 [호출 JSP 페이지명]을 저장하기
        //*******************************************
        ModelAndView mav = new ModelAndView( );
        mav.setViewName("allSearch.jsp");
        // mav.addObject("boardDTO", boardDTO);

        //*******************************************
        // [ModelAndView 객체] 리턴하기
        //*******************************************
        return mav;
    }

    // 게시판 접속.
    // boardList.do로 바로 접속하게함.  
    // @RequestMapping(value = "/board.do")
    // public ModelAndView goBoard() {
    //     System.out.println("ERPController 쪽, ==> board.do 접속!@#!@#");

    //     ModelAndView mav = new ModelAndView();
    //     mav.setViewName("board.jsp");
    //     return mav;
    // }

    // 통계화면 접속.
    @RequestMapping(value = "/statistics.do")
    public ModelAndView goStatistics() {
        ModelAndView mav = new ModelAndView();
        mav.setViewName("statistics.jsp");
        return mav;
    }

    // 재고관리 접속.
    @RequestMapping(value = "/stock_management.do")
    public ModelAndView goSstock_management() {
        ModelAndView mav = new ModelAndView();
        mav.setViewName("stock_in_out.jsp");
        return mav;
    }

    // 재고관리 안에서 가전 검색.
    @RequestMapping(value = "/jaego_search.do")
    public ModelAndView goJaego_search() {
        ModelAndView mav = new ModelAndView();
        mav.setViewName("jaego_search.jsp");
        return mav;
    }

    
    //새 물품 입력
    @RequestMapping( 
            value="/itemRegProc.do"
            ,method = RequestMethod.POST
            ,produces = "application/json;charset=UTF8"
        )
        @ResponseBody
        public Map<String, String> insertBoard( 
            ERPDTO erpDTO
            ,@RequestParam("img") MultipartFile multi
        ){
    	    System.out.println( "itemRegProc 시작" );
    	    
    	    String fileName = multi.getOriginalFilename();
    	    
    	    erpDTO.setPic(fileName);
    	    
    	    System.out.println( "==========================================="  );
    	    System.out.println( "pic          => " + erpDTO.getPic()           );    	    
    	    System.out.println( "G_item_code  => " + erpDTO.getG_item_code()   );
    	    System.out.println( "G_item_name  => " + erpDTO.getG_item_name()   );
    	    System.out.println( "brand_code   => " + erpDTO.getBrand_code()    );
    	    System.out.println( "category_code   => " + erpDTO.getCategory_code()     );
    	    System.out.println( "G_sub_category_code   => " + erpDTO.getG_sub_category_code()     );
    	    System.out.println( "G_sub_sub_category_code   => " + erpDTO.getG_sub_sub_category_code()    );
    	    System.out.println( "power_consum => " + erpDTO.getPower_consum()  );
    	    System.out.println( "build_day    => " + erpDTO.getBuild_day()     );
    	    System.out.println( "energy_grade_code   => " + erpDTO.getEnergy_grade_code()   );
    	    System.out.println( "color_code   => " + erpDTO.getColor_code()    );
    	    System.out.println( "whatsize     => " + erpDTO.getWhatsize()      );
    	    System.out.println( "discontinued => " + erpDTO.getDiscontinued()  );	        
    	    System.out.println( "===========================================" );
    	    
    	    String sizeMass[] = erpDTO.getWhatsize().split("x");
    	    erpDTO.setG_item_size_X( sizeMass[0] );
    	    erpDTO.setG_item_size_Y( sizeMass[1] );
    	    erpDTO.setG_item_size_Z( sizeMass[2] );
    	    
    	    System.out.println( "G_item_size_X => " + erpDTO.getG_item_size_X()  );    	    
    	    System.out.println( "G_item_size_Y => " + erpDTO.getG_item_size_Y()  );
    	    System.out.println( "G_item_size_Z => " + erpDTO.getG_item_size_Z()  );
    	    
            int ERPRegCnt = 0;
            
            ERPRegCnt = this.erpService.insertItem(erpDTO,multi);
            
            Map<String, String> map = new HashMap<String,String>();
            map.put("ERPRegCnt", ERPRegCnt+"");
            
            System.out.println( "itemRegProc 종료" );
            return map;
        }



}
