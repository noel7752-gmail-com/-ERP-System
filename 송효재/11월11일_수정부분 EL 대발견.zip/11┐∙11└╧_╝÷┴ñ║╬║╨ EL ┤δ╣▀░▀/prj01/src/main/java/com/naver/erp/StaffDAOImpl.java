package com.naver.erp;



import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


//NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN
// [DAO 클래스]인 [BoardDAOImpl 클래스] 선언
//NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN
	// @Repository 를 붙임으로써 [ DAO 클래스 ] 임을 지정하게 되고, bean 태그로 자동 등록된다.
//NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN

@Repository
public class StaffDAOImpl implements StaffDAO{
	
	//***********************************************
	// 속성변수 sqlSession 선언하고, [ SqlSessionTemplate 객체 ] 를 생성해 저장. 
	//***********************************************
		// @Autowired 역할 -> 속성변수에 붙은 자료형이 [ 클래스 ]면 이를 객체화하여 저장한다.
	@Autowired 
	private SqlSessionTemplate sqlSession;
	
	
	
	//***********************************************
	// [게시판 글 입력 후 입력 적용 행의 개수] 를 리턴하는 메소드 선언. 
	//***********************************************
	@Override
	public int insertStaff(StaffDTO staffDTO) {
		//--------------------------------------
		// SqlSessionTeamplate 객체의 insert 위치를 지정하기
		// 게시판 글 입력 SQL 구문을 실행하고 입력 성공 행의 개수 얻기.
		//--------------------------------------
			System.out.println("인설트스태프 시작");
			System.out.println( "getStaff_no => " + staffDTO.getStaff_no() );
			System.out.println( "getStaff_name => " + staffDTO.getStaff_name() );
			System.out.println("getJumin_no1 => " +  staffDTO.getJumin_no1() );
			System.out.println( "getJumin_no2 => " + staffDTO.getJumin_no2() );
			System.out.println("getReligion_code => " +  staffDTO.getReligion_code() );
			System.out.println( "getSchool_code => " + staffDTO.getSchool_code() );
			System.out.println("getStaff_skill_insert() ==>" + staffDTO.getStaff_skill_insert() );
			System.out.println( "getGraduation_year => " + staffDTO.getGraduation_year() );
			System.out.println( "getGraduation_month => " + staffDTO.getGraduation_month() );
		int staff_input_Cnt = this.sqlSession.insert(
				//--------------------------------------
				// 실행할 SQL 구문의 위치를 지정하기
				// 실행할 SQL 구문의 위치 문자열 패턴은 아래와 같다.
				// XML 파일 중에 "mapper 태그의 namespace명.mapper 태그 내부의 호출할 SQL구문 소유한 태그 id값"
				//--------------------------------------
				"com.naver.erp.StaffDAO.insertStaff"
				//--------------------------------------
				// 호출할 SQL 구문에서 사용할 데이터 지칭하기.
				//--------------------------------------
				,staffDTO
				
				);
		
		System.out.println("StaffDAOImpl.insertStaff 메소드 호출 성공");
		return staff_input_Cnt;	
		
		}
	


	
		//*************************************
		// [검색한 게시판 목록] 리턴하는 메소드 선언
		//*************************************
		public List<Map<String,String>> getStaffList() {
			
			List<Map<String,String>> staffList = this.sqlSession.selectList(
					"com.naver.erp.StaffDAO.getStaffList"	// 실행할 SQL 구문의 위치 지정
					);
				
			return staffList;
		}
		
		
		
		
	
	
		//*************************************
		// [1개 게시판 글 정보] 리턴하는 메소드 선언
		//*************************************	
		@Override
		public StaffDTO getStaff(int staff_no) {
			
		//------------------------------------------------------
		// [ SqlSessionTemplate 객체 ]의 selectOne(~,~) 를 호출하여 [1개 게시판 글 정보] 얻기
		//------------------------------------------------------
		StaffDTO staff = this.sqlSession.selectOne(
				"com.naver.erp.StaffDAO.getStaff"		// BoardDTO --> D'A'O로 바꿈(8.26 기준)
				,staff_no			
		);				
		//------------------------------------------------------
		// [ 1개 게시판 글 정보 ] 리턴하기
		//------------------------------------------------------
		return staff;
	}
		
		
		
		//*************************************
		// [종교리스트] 리턴하는 메소드 선언
		//*************************************
				public List<String> getReligionList() {
					
			 List<String> ReligionList = this.sqlSession.selectList(
							"com.naver.erp.StaffDAO.getReligionList"	// 실행할 SQL 구문의 위치 지정
							);
						
					return ReligionList;
				}
		
		
		//*************************************
		// [종교리스트] 리턴하는 메소드 선언
		//*************************************
				public List<String> getSchoolList() {
					
			 List<String> SchoolList = this.sqlSession.selectList(
							"com.naver.erp.StaffDAO.getSchoolList"	// 실행할 SQL 구문의 위치 지정
							);
						
					return SchoolList;
				}
				
		
				//*************************************
				// [종교리스트] 리턴하는 메소드 선언
				//*************************************
						public List<String> getSkillList() {
							
					 List<String> SkillList = this.sqlSession.selectList(
									"com.naver.erp.StaffDAO.getSkillList"	// 실행할 SQL 구문의 위치 지정
									);
								
							return SkillList;
						}		
				
		
				//*************************************
				// [사원 스킬] 리턴하는 메소드 선언
				//*************************************	
						public int insertSkillList(StaffDTO staffDTO) {
							System.out.println("getStaff_skill_insert() = =>>  스킬 인설트 시작!");
							
					 int staff_skill_insert = this.sqlSession.insert(
									"com.naver.erp.StaffDAO.insertSkillList"	// 실행할 SQL 구문의 위치 지정
							 ,staffDTO		);
					 		System.out.println("getStaff_skill_insert() = =>>  스킬 인설트 완료!");
							return staff_skill_insert;
						}						
						
						
		
/*		
		//****************************************************
		// [검색한 게시판 목록 총개수 ] 리턴하는 메소드 선언
		//****************************************************
		public int getStaffListAllCnt(StaffSearchDTO staffSearchDTO ) {
			int staffListAllCnt = this.sqlSession.selectOne(
					"com.naver.erp.StaffDAO.getStaffListAllCnt" // 실행할 SQL 구문의 위치 지정
					, staffSearchDTO                            // 실행할 SQL 구문에서 사용할 데이터 지정
				
			);
			return staffListAllCnt;
		}
*/		
		
	
		
		
		
				


/*
		//*************************************
		// 삭제/수정할 게시판의 존재 개수를 리턴하는 메소드 선언
		//*************************************
		public int getStaffCnt(StaffDTO staffDTO) {		// boardDTO 대신 board로 쓸 때도 있다.
			// [ SqlSessionTemplate 객체 ]의 selectOne(~,~) 를 호출하여 [게시판의 존재 개수] 얻기
			int staffCnt = this.sqlSession.selectOne(
			"com.naver.erp.StaffDAO.getStaffCnt"		// select 구문 위치
			, staffDTO									// boardDTO를 전달해드릴께요.
			);
			return staffCnt;
		}
*/		
		/*			
		//*************************************
		// 삭제/수정할 게시판의 비밀번호 존재 개수를 리턴하는 메소드 선언
		//*************************************	
		public int getPwdCnt(BoardDTO boardDTO) {
			//---------------------------------------------------------
			// [ SqlSessionTemplate 객체 ]의 selectOne(~,~) 를 호출하여 [게시판의 존재 개수] 얻기
			//---------------------------------------------------------
			int PwdCnt = this.sqlSession.selectOne(
			"com.naver.erp.BoardDAO.getPwdCnt"		
			, boardDTO									
			);
			return PwdCnt;
		}		
		
		
		
		//*************************************
		// 게시판 수정 후 수정행의 적용 개수를 리턴하는 메소드 선언.
		//*************************************			
		public int updateBoard(BoardDTO boardDTO) {
			//-------------------------------------------------------
			// [SqlSessionTemplate 객체]의 update(~,~) 를 호출하여 [게시판 수정]하기
			//-------------------------------------------------------
			int updateCnt = this.sqlSession.update(
					"com.naver.erp.BoardDAO.updateBoard" // 실행할 SQL 구문의 위치 지정
					,boardDTO							     // 실행할 SQL 구문에서 사용할 데이터 지정
			);
			return updateCnt;		
		}
		
		
	//------------------------------8월 27일------------------------------------	
		
		//*************************************
		// 삭제할 게시판의 자식글 존재 개수를 리턴하는 메소드 선언
		//*************************************			
		public int getChildrenCnt(BoardDTO boardDTO) {
			//-------------------------------------------------------
			// [SqlSessionTemplate 객체]의 update(~,~) 를 호출하여
			// [자식글 존재 개수] 얻기
			//-------------------------------------------------------
			int childrenCnt = this.sqlSession.selectOne(
					"com.naver.erp.BoardDAO.getChildrenCnt"  // 실행할 SQL 구문의 위치 지정
					,boardDTO							     // 실행할 SQL 구문에서 사용할 데이터 지정
			);
			
			return 	childrenCnt;		
											     								
		}
		
		//*************************************
		// 삭제될 게시판 이후 글의 출력 순서번호를 1씩 감소 시킨 후 수정 적용행의 개수를 리턴하는 메소드 선언
		//*************************************			
		public int downPrintNo(BoardDTO boardDTO) {
			//-------------------------------------------------------
			// [SqlSessionTemplate 객체]의 update(~,~) 를 호출하여 
			// [삭제될 게시판 이후 글의 출력 순서번호를 1씩 감소 ]하고 감소된 행의 개수 얻기
			//-------------------------------------------------------
			int downPrintNoCnt = this.sqlSession.update(
					"com.naver.erp.BoardDAO.downPrintNo" 	 // 실행할 SQL 구문의 위치 지정
					,boardDTO							     // 실행할 SQL 구문에서 사용할 데이터 지정
			);
			
			return 	downPrintNoCnt;			
											     								
		}
		
		//*************************************
		// 게시판 삭제 명령한 후 삭제 적용행의 개수를 리턴하는 메소드 선언.
		//*************************************			
		public int deleteBoard(BoardDTO boardDTO) {
			//-------------------------------------------------------
			// [SqlSessionTemplate 객체]의 delete(~,~) 를 호출하여
			// [게시판 삭제 명령]한 후 삭제 적용행의 개수 얻기
			//-------------------------------------------------------
			int deleteBoardCnt = this.sqlSession.delete(
					"com.naver.erp.BoardDAO.deleteBoard" 	 // 실행할 SQL 구문의 위치 지정
					,boardDTO							     // 실행할 SQL 구문에서 사용할 데이터 지정
			);
			
			return 	deleteBoardCnt;			
											     								
		}
*/		
		
}
		

			
		



