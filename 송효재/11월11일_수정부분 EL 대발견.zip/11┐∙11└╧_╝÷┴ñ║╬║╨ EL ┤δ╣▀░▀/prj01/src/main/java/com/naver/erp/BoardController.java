package com.naver.erp;



import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

//NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN
// URL 주소로 접속하면 호출되는 메소드를 소유한 [컨트롤러 클래스] 선언
// @Controller 를 붙임으로써 [컨트롤러 클래스]임을 지정한다.
//NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN
@Controller
public class BoardController {

	//NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN
	// 속성변수 boardService 선언하고 [BoardService 인터페이스]를 구현한 클래스를 찾아 객체 생성해 객체의 메위주를 저장.
	//NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN
		// @Autowired 역할 -> 속성변수에 붙은 자료형인 [인터페이스]를 구현한 클래스를 찾아 객체 생성해 객체의 메위주를 저장.
		// [인터페이스]를 구현한 [클래스]가 1개가 아니면 에러가 발생한다.
		// 단 @Autowired( required=flase ) 로 선언하면 [인터페이스]를 구현한 [클래스]가 0개 이어도 에러없이 null 이 저장된다. 
	@Autowired
	private BoardService boardService;
	
	
	
	//NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN
	// 속성변수 boardDAO 선언하고 [BoardDAO 인터페이스]를 구현한 클래스를 찾아 객체 생성해 객체의 메위주를 저장.
	//NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN	
	@Autowired
	private BoardDAO boardDAO;
	
	
	
	
	@RequestMapping( value="/boardList.do" )
	public ModelAndView getBoardList(
			
		){
		
		//**************************************************
		// Oracle(오라클) board 테이블 안의 데이터를 검색해와 자바 객체에 저장하기. 즉 [ 게시판 목록 ] 얻기
		//**************************************************
		List<Map<String,String>> boardList = this.boardDAO.getBoardList();		
		
		
		
		//----------------------------------
		// [ModelAndView 객체] 생성하기
		// [ModelAndView 객체] 에 [호출 JSP 페이지명]을 저장하기
		//----------------------------------		
		ModelAndView mav = new ModelAndView( );
		mav.setViewName("boardList.jsp");
		//----------------------------------
		// [ModelAndView 객체]에 [ 게시판 목록 검색 결과 ]를 저장하기
		//----------------------------------
		mav.addObject("boardList", boardList);
		//----------------------------------		
		// [ModelAndView 객체] 리턴하기
		//----------------------------------		
		return mav;			
	}


		

 
	
	
	
	
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	// /boardContentForm.do 접속 시 호출되는 메소드 선언
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	@RequestMapping( value="/boardContentForm.do" )
	
	public ModelAndView getBoardContentForm(
			@RequestParam(value="b_no") int b_no
		){
		//----------------------------------
		// [ BoardServiceImpl 객체 ]의 getBoard 메소드 호출로 [1개의 게시판 글]을 BoardDTO 객체에 담아오기 
		//----------------------------------
		BoardDTO boardDTO = this.boardService.getBoard(b_no);
		
				
		ModelAndView mav = new ModelAndView( );
		mav.setViewName("boardContentForm.jsp");
		//----------------------------------
		// [ModelAndView 객체]에 [ 수정/삭제할 1개의 게시판 글 정보 ] 저장하기.
		//----------------------------------		
		mav.addObject("boardDTO", boardDTO);	
		return mav;	
	}
	
	
	
	
	
	
	
	
	
	//NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN
	// 가상주소 /boardRegForm.do 로 접근하면 호출되는 메소드 선언
	//NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN	
		@RequestMapping( value="/boardRegForm.do" )
		public ModelAndView goBoardRegForm(
				
			){
			ModelAndView mav = new ModelAndView( );
			mav.setViewName("boardRegForm.jsp");
			return mav;			
	}
		
		
		//NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN
		// 가상주소 /boardRegProc.do 로 접근하면 호출되는 메소드 선언
		//NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN		
		@RequestMapping( value="/boardRegProc.do" )
		public ModelAndView insertBoard(
				//******************************************
				// 파라미터값을 저장할 [BoardDTO 객체]를 매개변수로 선언 
				//******************************************
					// [파라미터명]과 [BoardDTO 객체]의 [속성변수명]이 같으면
					// setter 메소드가 작동되어 [파라미터값]이 [속성변수]에 저장된다.
					// [속성변수명]에 대응하는 [파라미터명]이 없으면 setter 메소드가 작동되지 않는다.
					// [속성변수명]에 대응하는 [파라미터명]이 있는데 [파라미터값]이 없으면
					// [속성변수]의 자료형에 관계없이 무조건 NULL값이 저장된다.
					// 이때 [속성변수]의 자료형이 기본형일 경우 NULL값이 저장될 수 없어 error가 발생한다.
					// 이런 에러를 피하려면 파라미터값이 기본형이거나 속성변수의 자료형을 String 으로 해야한다.
					// 이런 에러가 발생하면 메소드안의 실행구문은 하나도 실행되지 않음에 주의한다.
					// 매개변수로 들어온 [DTO 객체]는 이 메소드가 끝난 후 호출되는 JSP 파일로 이동한다.
					// 즉, HttpServletRequest 객체에 boardDTO 라는 키값명으로 저장된다.			
				BoardDTO boardDTO
				//**************************************************
				// Error 객체를 관리하는 BindingResult 객체가 저장된 매개변수 bindingResult 선언
				//**************************************************
				, BindingResult bindingResult
				
				
		) {
			ModelAndView mav = new ModelAndView();
			mav.setViewName("boardRegProc.jsp");
			
		try {	
			System.out.println( boardDTO.getB_no() );
			System.out.println( boardDTO.getWriter() );			
			System.out.println( boardDTO.getSubject() );
			System.out.println( boardDTO.getEmail() );			
			System.out.println( boardDTO.getContent() );			
			System.out.println( boardDTO.getPwd() );
		
			
			//***************************************
			// check_BoardDTO 메소드를 호출하여 [유효성 체크]하고 경고 문자 얻기.
			//***************************************
			// 유효성 체크 에러 메시지 저장할 변수 선언.
			String msg = "";
			// check_BoardDTO 메소드를 호출하여 유효성 체크하고 에러 메시지 문자 얻기.
			
			msg = check_BoardDTO( boardDTO , bindingResult);
			 mav.addObject("msg", msg);
			// 만약 msg 안에 ""가 저장되어 있으면, 즉 유효성 체크를 통과했으면	
			if( msg.equals("") ) {
				
			//***************************************
			// [BoardServiceImpl 객체]의 insertBoard 메소드 호출로
			// 게시판 글 입력하고 [게시판 입력 적용행의 개수] 얻기.
			// DTO 안에 파라미터값이 들어가 있다고 생각하면 됌.(DB에 저장된)
			// UPDATE 부분에선 0이 나올수 있지만 INSERT만큼은 0이 나올 수 없다.(1 또는 ERORR)
			// 행의 갯수가 1이면 성공 아니면 실패.
			//***************************************			
			int boardRegCnt = this.boardService.insertBoard(boardDTO);

						
			//----------------------------------
			// [ModelAndView 객체] 생성하기
			// [ModelAndView 객체] 에 [호출 JSP 페이지명]을 저장하기
			// [ModelAndView 객체]에 [게시판 입력 적용행의 개수] 저장하기.
			// [ModelAndView 객체]에 [유효성 체크 에러 메시지] 저장하기.
			//----------------------------------			
			mav.addObject("boardRegCnt",boardRegCnt);
		//	mav.addObject("msg", msg);
		}
			// 만약 msg 안에 ""가 저장되어 있지 않으면, 즉 유효성 체크를 통과못했으므로
			else {
				mav.addObject("boardRegCnt",0);
		//		mav.addObject("msg", msg);	
			}
			
			//----------------------------------
			//[ ModelAndView 객체 ]리턴하기
			//----------------------------------
		System.out.println("BoardController.insertBoard 메소드 호출 성공");
		}catch(Exception ex) {
			mav.addObject("boardRegCnt", -1 );
			mav.addObject("msg", "서버에서 문제 발생!");
		}
			return mav;					
	}

		
		
		
		
		
		
		
		
	//NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN	
	//NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN
	// 게시판 입력 또는 수정 시 게시판 입력글의 입력양식의 유효성을 검사하고
	// 문제가 있으면 경고 문자를 리턴하는 메소드 선언.
	//NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN
	//NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN
	public String check_BoardDTO( BoardDTO boardDTO, BindingResult bindingResult )	{
		String checkMsg = "";
		//********************************************
		// BoardDTO 객체에 저장된 데이터의 유효성 체크할 BoardValidator 객체 생성하기.
		// BoardValidator 객체의 validate 메소드 호출하여 유효성 체크 실행하기.
		//********************************************
		BoardValidator boardValidator = new BoardValidator();
		boardValidator.validate(
				boardDTO			// 유효성 체크할 DTO 객체
				, bindingResult		// 유효성 체크 결과를 관리하는 BindingResult 객체
		);
		//********************************************
		// 만약 BindingResult 객체의 hasErrors() 메소드 호출하여 true 값을 얻으면
		// 무언가 잘못됐다는 의미
		//********************************************
		if( bindingResult.hasErrors() ) {
			// 변수 checkMsg 에 BoardValidator 객체에 저장된 경고문구 얻어 저장하기.
			checkMsg = bindingResult.getFieldError().getCode();
		}
		//********************************************
		// checkMsg 안의 문자 리턴하기.
		//********************************************
		
		return checkMsg;
		
	}

	
	//-------------------------------------------------8.26일자 ---------------------------------------	
	
		//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
		// /boardContentForm.do 접속 시 호출되는 메소드 선언
		//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
		@RequestMapping( value="/boardUpDelForm.do" )	
		
		public ModelAndView goBoardUpDelForm(
			//----------------------------------------------------
			// "b_no"라는 파라미터명의 파라미터값이 저장되는 매개변수 b_no 선언.
			// 수정 또는 삭제할 게시판 고유 번호가 들어오는 매개변수선언.
			//----------------------------------------------------	
				@RequestParam(value="b_no") int b_no
			){	
			//----------------------------------
			// [ boardDAOImpl 객체 ]의 getBoard 메소드 호출로
			// 1개의 게시판글을 BoardDTO 객체에 담아서 가져오기.
			//----------------------------------
			BoardDTO boardDTO = this.boardDAO.getBoard(b_no);
			
					
			ModelAndView mav = new ModelAndView( );
			mav.setViewName("boardUpDelForm.jsp");
			//----------------------------------
			// [ModelAndView 객체]에 [ 수정/삭제할 1개의 게시판 글 정보 ] 저장하기.
			//----------------------------------		
			mav.addObject("boardDTO", boardDTO);	
			return mav;
			
		}
		
		
		
		
	//-------------------------------------------------8.27일자 ---------------------------------------			
		//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
		// /boardContentForm.do 접속 시 호출되는 메소드 선언
		//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
		@RequestMapping( value="/boardUpDelProc.do" )						
		
		public ModelAndView boardUpDelProc(
				//----------------------------------------------------
				// 파라미터값을 저장할 [BoardDTO 객체]를 매개변수로 선언
				//----------------------------------------------------				
				BoardDTO boardDTO
				//----------------------------------------------------
				// "upDel" 라는 파라미터명의 파라미터값이 저장된 매개변수 upDel 선언
				//----------------------------------------------------
				,@RequestParam(value="upDel") String upDel
				//----------------------------------------------------
				// 유효성 검사 결과를 관리하는 BindingResult 객체가 저장되어 들어오는
				// 매개변수 bindingResult 선언
				//----------------------------------------------------
				,BindingResult bindingResult
		){	
			//******************************************
			// [ModelAndView 객체]에 [수정/삭제할 1개의 게시판 글 정보] 저장하기
			//******************************************				
			ModelAndView mav = new ModelAndView( );
			mav.setViewName("boardUpDelProc.jsp");
		//-----------------------------------------------------
		// 만약 게시판 삭제 모드이면
		//-----------------------------------------------------
			if( upDel.equals("del") ) {
				//---------------------------------------
				// 삭제 실행하고 삭제 적용행의 개수 얻기
				//---------------------------------------
				int boardUpDelCnt = this.boardService.deleteBoard(boardDTO);
				mav.addObject("boardUpDelCnt", boardUpDelCnt);
			}
			
			
			
			
			
			
			
			//-----------------------------------------------------
			// 만약 게시판 수정 모드이면 수정 실행하고 수정 적용행의 개수얻기.
			//-----------------------------------------------------			
			else if(upDel.equals("up")) {
				
				//***************************************
				// 유효성 체크 에러 메시지 저장할 변수 선언.
				//***************************************				
				String msg = "";
				//-----------------------------------------------------
				// check_BoardDTO 메소드를 호출하여 유효성 체크하고 에러 메시지 문자 얻기.				
				//-----------------------------------------------------
				msg = check_BoardDTO( boardDTO , bindingResult);
				//-----------------------------------------------------
				// ModelAndView 객체에 유효성 체크 시 발생한 에러 메시지 저장하기
				//-----------------------------------------------------
				mav.addObject("msg", msg);
				//-----------------------------------------------------
				// 만약 msg 안에 ""가 저장되어 있으면, 즉 유효성 체크를 통과했으면				
				//-----------------------------------------------------
				if( msg.equals("") ) {		// equals() 는 문자열 비교할때 씀
					//-----------------------------------------------------
					// BoardServiceImpl 객체의 updateBoard 라는 메소드 호출로
					// 게시판 수정 실행하고 수정 적용행의 개수 얻기.
					//-----------------------------------------------------
					int boardUpDelCnt = this.boardService.updateBoard(boardDTO);
					
		//-------------------▲ 여기서부터 boardService  ~> ~> 진행 ---------------------
		//-------------------+ 위에 삭제 모드(오후)도 마찬가지---------------------------
					
				//-----------------------------------------------------
				// ModelAndView 객체에 수정 적용행의 개수 저장하기
				//-----------------------------------------------------
					mav.addObject("boardUpDelCnt", boardUpDelCnt);
				  //mav.addObject("msg", msg);
					
															
				}
				// 만약 msg 안에 ""가 저장되어 있지 않으면, 즉 유효성 체크를 통과못했으므로

				else {
					mav.addObject("boardUpDelCnt", 0);
				  //mav.addObject("msg", msg);
				}				
			}						
			return mav;	
			
	}		
						
}
