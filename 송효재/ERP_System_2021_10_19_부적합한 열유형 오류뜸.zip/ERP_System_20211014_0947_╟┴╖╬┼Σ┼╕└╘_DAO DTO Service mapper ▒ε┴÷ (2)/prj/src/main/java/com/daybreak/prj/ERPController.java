package com.daybreak.prj;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ERPController {
	
	
	@Autowired
	private ERPDAO erpDAO;
	@Autowired
	private ERPService erpService;	
    
    @RequestMapping(value = "/daybreak.do")
    public ModelAndView daybreak() {
        ModelAndView mav = new ModelAndView();
        mav.setViewName("daybreak.jsp");
        return mav;
    }


    // 통합검색 접속.
    @RequestMapping( value="/searchAll.do" )
    public ModelAndView goSearchAll( 
    		ERPSearchDTO erpSearchDTO
    		,ERPDTO erpDTO
            
    ){
   	int searchListAllCnt = this.erpDAO.getSearchAllCnt(erpSearchDTO);
    	
    	// 페이징 처리 메소드 결과물을 변수에 담음
    	Map<String,Integer> map = Util.getPagingNos(searchListAllCnt, erpSearchDTO.getSelectPageNo(), erpSearchDTO.getRowCntPerPage(), 10);
    	erpSearchDTO.setSelectPageNo(map.get("selectPageNo"));
    	
    	// DB연동해 가져온 검색리스트
    	List<Map<String,String>> searchALLList = this.erpDAO.getSearcALLhList(erpSearchDTO);
    	
    	 // 삭제 실행하고 삭제 적용행의 개수 얻기
 //   	int deleteERPCnt = this.erpService.deleteERP(erpDTO);
    	
    	
    	
        //*******************************************
        // [ModelAndView 객체] 생성하기
        // [ModelAndView 객체]에 [호출 JSP 페이지명]을 저장하기
        //*******************************************
        ModelAndView mav = new ModelAndView( );
        mav.setViewName("allSearch.jsp");
        //mav.addObject("erpDTO", erpDTO);
        mav.addObject("searchListAllCnt",searchListAllCnt);
        mav.addObject("searchALLList",searchALLList);
        mav.addObject("pagingNos",map);
//        mav.addObject("deleteERPCnt" , deleteERPCnt);


        //*******************************************
        // [ModelAndView 객체] 리턴하기
        //*******************************************
        return mav;
    }
    
    
    
    
    
    

    // 게시판 접속.
    // boardList.do로 바로 접속하게함.  
    // @RequestMapping(value = "/board.do")
    // public ModelAndView goBoard() {
    //     System.out.println("ERPController 쪽, ==> board.do 접속!@#!@#");

    //     ModelAndView mav = new ModelAndView();
    //     mav.setViewName("board.jsp");
    //     return mav;
    // }

    // 통계화면 접속.
    @RequestMapping(value = "/statistics.do")
    public ModelAndView goStatistics() {
        ModelAndView mav = new ModelAndView();
        mav.setViewName("statistics.jsp");
        return mav;
    }

    // 재고관리 접속.
    @RequestMapping(value = "/stock_management.do")
    public ModelAndView goSstock_management() {
        ModelAndView mav = new ModelAndView();
        mav.setViewName("stock_in_out.jsp");
        return mav;
    }

    // 재고관리 안에서 가전 검색.
    @RequestMapping(value = "/jaego_search.do")
    public ModelAndView goJaego_search() {
        ModelAndView mav = new ModelAndView();
        mav.setViewName("jaego_search.jsp");
        return mav;
    }

    
    
    
    
//    //mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
//    // /boardUpDelForm.do 접속 시 호출되는 메소드 선언
//    //mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
//    @RequestMapping( value="/boardUpDelForm.do" )
//    public ModelAndView goBoardUpDelForm( 
//        // -------------------------------
//        // "b_no" 라는 파라미터명의 파라미터값이 저장되는 매개변수 b_no 선언
//        // 수정 또는 삭제할 게시판 고유번호가 들어오는 매개변수 선언
//        // -------------------------------
//        @RequestParam(value="item_code") String item_code
//    ){
//        //*******************************************
//        // boardDAOImp 객체의 getBoard 메소드 호출로
//        // 1개의 게시판글을 boardDTO 객체에 담아서 가져오기
//        //*******************************************
//        BoardDTO boardDTO = this.boardDAO.getBoard(b_no);
//        //*******************************************
//        // [ModelAndView 객체] 생성하기
//        // [ModelAndView 객체]에 [호출 JSP 페이지명]을 저장하기
//        //*******************************************
//        ModelAndView mav = new ModelAndView( );
//        // mav.setViewName(path+"boardUpDelForm.jsp");
//        mav.setViewName("boardUpDelForm.jsp");
//        mav.addObject("boardDTO", boardDTO);
//        return mav;
//    }
//    
//    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    


}
