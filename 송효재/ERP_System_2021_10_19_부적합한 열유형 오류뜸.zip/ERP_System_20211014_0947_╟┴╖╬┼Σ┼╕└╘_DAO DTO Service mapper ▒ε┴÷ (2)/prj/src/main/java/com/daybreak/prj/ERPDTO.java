package com.daybreak.prj;

public class ERPDTO {
	

	private int item_no;				// 번호
	private String pic;					// 이미지		
	private String item_code;			// 제품코드
	private String item_name;			// 제품명
	private String brand_name;			// 브랜드
	private String category_name;		// 제품종류
	private String power_consum;		// 소비전력
	private int stock_in_cnt;  		// 입고량
	private int	stock_out_cnt; 		// 출고량
	//------------------------------------------------ 
	public int getItem_no() {
		return item_no;
	}
	public void setItem_no(int item_no) {
		this.item_no = item_no;
	}
	public String getPic() {
		return pic;
	}
	public void setPic(String pic) {
		this.pic = pic;
	}
	public String getItem_code() {
		return item_code;
	}
	public void setItem_code(String item_code) {
		this.item_code = item_code;
	}
	public String getItem_name() {
		return item_name;
	}
	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}
	public String getBrand_name() {
		return brand_name;
	}
	public void setBrand_name(String brand_name) {
		this.brand_name = brand_name;
	}
	public String getCategory_name() {
		return category_name;
	}
	public void setCategory_name(String category_name) {
		this.category_name = category_name;
	}
	public String getPower_consum() {
		return power_consum;
	}
	public void setPower_consum(String power_consum) {
		this.power_consum = power_consum;
	}
	public int getStock_in_cnt() {
		return stock_in_cnt;
	}
	public void setStock_in_cnt(int stock_in_cnt) {
		this.stock_in_cnt = stock_in_cnt;
	}
	public int getStock_out_cnt() {
		return stock_out_cnt;
	}
	public void setStock_out_cnt(int stock_out_cnt) {
		this.stock_out_cnt = stock_out_cnt;
	}


	




























	// ===================================================================================
    // 게시판 DTO 참고용 주석. 삭제하지마시고, 그냥 코드들 참고하시고 위에 코딩 해주세요.
    // ===================================================================================
/*
	private int b_no;
    private String subject;
    private String writer;
    private String reg_date;
    private int readcount;
    private String content;

	private String pic;

    private String is_del;

    private String pwd;
    private String email;
    private int group_no;
    private int print_no;
    private int print_level;
    
    public int getB_no() {
		return b_no;
	}
	public void setB_no(int b_no) {
		this.b_no = b_no;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getReg_date() {
		return reg_date;
	}
	public void setReg_date(String reg_date) {
		this.reg_date = reg_date;
	}
	public int getReadcount() {
		return readcount;
	}
	public void setReadcount(int readcount) {
		this.readcount = readcount;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getPic() {
		return pic;
	}
	public void setPic(String pic) {
		this.pic = pic;
	}
	public String getIs_del() {
		return is_del;
	}
	public void setIs_del(String is_del) {
		this.is_del = is_del;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getGroup_no() {
		return group_no;
	}
	public void setGroup_no(int group_no) {
		this.group_no = group_no;
	}
	public int getPrint_no() {
		return print_no;
	}
	public void setPrint_no(int print_no) {
		this.print_no = print_no;
	}
	public int getPrint_level() {
		return print_level;
	}
	public void setPrint_level(int print_level) {
		this.print_level = print_level;
	}
*/
    
}
