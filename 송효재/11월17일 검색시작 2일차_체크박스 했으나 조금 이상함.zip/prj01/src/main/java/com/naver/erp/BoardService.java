package com.naver.erp;

public interface BoardService {
	//**********************************************
	// [게시판 글 입력 후 입력 적용 행의 개수] 리턴하는 메소드 선언.
	// 이 인터페이스를 구현화한것이[ boardServiceImpl ]임
	// public이 없어도 public 이다. 즉 public이 없어도 public의 성격을 가지고 있음. default X )
	// 인터페이스 :[ public , static final ] 의 성격을 가진 속성변수와 
	// public , abstract 의 성격을 가진 메소드로 구성된 클래스와는 다른 단위 프로그램의 한 종류이다.
	// public 이 없지만 public의 성격, abstract가 없어도 abstract 의 성격을 가지고 있음(블록이 없어서)
	//**********************************************
	
	// [게시판 글 입력 휴 입력 적용행의 개수] 리턴하는 메소드 선언
	int insertBoard(BoardDTO boardDTO);
	
	
	// [1개 게시판 글] 리턴하는 메소드 선언
	BoardDTO getBoard(int b_no);

	
	// [1개 게시판 수정 실행하고 수정 적용행의 개수]를 리턴하는 메소드 선언
	int updateBoard(BoardDTO boardDTO);
	
	
	// [1개 게시판 ] 삭제 후 적용행의 개수를 리턴하는 메소드 선언
	int deleteBoard(BoardDTO boardDTO);
	
	
}
