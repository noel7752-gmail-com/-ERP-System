package com.naver.erp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

//NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN
// 보드컨트롤러한테 지시를 받음. [ 서비스 클래스 ] 인 [ BoardServiceImpl 클래스] 선언.
// [서비스 클래스] 에는 @Service 와 @Transactional 를 붙인다.
// @Service			=> [서비스 클래스]임을 지정하고 bean 태그로 자동 등록한다.
// @Transactional	=> [서비스 클래스]의 메소드 내부에서 일어나는 모든 작업에는 [트렌젝션]이 걸린다.
//NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN
@Service
@Transactional

public class StaffServiceImpl implements StaffService{
	
	
	//**************************************************************
	// 속성변수 boardDAO 선언하고, [BoardDAO 인터페이스]를 구현한 클래스를 객체화해서 저장한다.
	//**************************************************************
	// @Autowired 역할 -> 속성변수에 붙은 자료형인 [인터페이스]를 구현한 [클래스]를 객체화하여 저장한다.
	
	
	 @Autowired
	 private StaffDAO staffDAO;
	 
	
	

	
	//**************************************************************
	// [ 1개 게시판 글 입력 적용 행의 갯수 ] 리턴하는 메소드 선언
	// 오버라이딩을 해야 인터페이스를 사용 가능.
	//**************************************************************	
	@Override
	public int insertStaff(StaffDTO staffDTO) {
		
		//----------------------------------------
		// BoardDAOImpl 객체의 insertBoard 메소드 호출하여 게시판 글 입력 후 입력 적용 행의 개수 얻기.	
		//----------------------------------------		
		int staff_input_Cnt = this.staffDAO.insertStaff(staffDTO);		
		//----------------------------------------
		// 1개 게시판 글 입력 적용 행의 개수 리턴하기	
		//----------------------------------------		
		System.out.println("StaffServiceImpl.insertStaff 메소드 호출 성공");
		
		return staff_input_Cnt;
	}
	

	@Override
	public int insertSkillList(StaffDTO staffDTO) {
		
		//----------------------------------------
		// BoardDAOImpl 객체의 insertBoard 메소드 호출하여 게시판 글 입력 후 입력 적용 행의 개수 얻기.	
		//----------------------------------------		
		int staff_skill_insert = this.staffDAO.insertSkillList(staffDTO);		
		//----------------------------------------
		// 1개 게시판 글 입력 적용 행의 개수 리턴하기	
		//----------------------------------------		
		System.out.println("StaffServiceImpl.insertStaff 메소드 호출 성공");
		
		return staff_skill_insert;
	}	
	
	
	
	//**************************************************************
	// [ 1개 게시판 글 ] 삭제 후 삭제 적용행의 개수를 리턴하는 메소드 선언
	//**************************************************************
	@Override
	public int deleteStaff(StaffDTO staffDTO) {
		
		//----------------------------------------
		// [ StaffDAOImpl ]의 getStaffCnt 메소드를 호출하여
		// 삭제할 게시판의 존재 개수를 얻는다.
		//----------------------------------------		
		int staffCnt = this.staffDAO.getStaffCnt(staffDTO);
		if(staffCnt==0) {return -1;}
		

		//----------------------------------------
		// [ StaffDAOImpl 객체]의 deleteBoard 메소드를 호출하여
		// [ 게시판 삭제 명령한 후 삭제 적용행의 개수 ]를 얻는다.
		// deleteCnt에 1이 들었으면 정상, -1,-2,-3 중 하나라도 해당이면 오류
		//----------------------------------------
		
		
		
		int deleteCnt = this.staffDAO.deleteStaff(staffDTO);
		if(deleteCnt==0) {
			return -1;
		}
		
		
		return deleteCnt;
	}	
	

	
	
	
	
	
	
	
	
	
	
	

	
	
	//**************************************************************
	// [ 1개 게시판 글 ]리턴하는 메소드 선언
	//**************************************************************	
	@Override
	public StaffDTO getStaff(int staff_no) {

		//----------------------------------------
		// [ BoardDAOImpl ] 객체의 getBoard 메소드를 호출하여
		// [ 1개 게시판 글 ]을 얻는다.
		//----------------------------------------		
		StaffDTO staff = this.staffDAO.getStaff(staff_no);
		//----------------------------------------
		// [ 1개 게시판 글 ]이 저장된 BoardDTO 객체 리턴하기.	
		//----------------------------------------
		System.out.println("StaffServiceImpl.getStaff 메소드 호출 성공");		
		return staff;
	}	
	
			
	//**************************************************************
	// [ 1개 게시판 글 ] 수정 실행하고 수정 적용행의 개수를 리턴하는 메소드 선언
	//**************************************************************
	@Override
	public int updateStaff(StaffDTO staffDTO) {
		//----------------------------------------
		// [ BoardDAOImpl ]의 getBoardCnt 메소드를 호출하여
		// 수정할 게시판의 존재 개수를 얻는다.
		// return -1 이면 게시판 글이 없는거다.
		//----------------------------------------
		int staffCnt = this.staffDAO.getStaffCnt(staffDTO);
		if(staffCnt==0) {return -1;}

		//----------------------------------------
		// [ BoardDAOImpl 객체 ]의 updateBoard 메소드를 호출하여
		// 게시판 수정 명령한 후 수정 적용행의 개수를 얻는다.
		//----------------------------------------
		int updateCnt = this.staffDAO.updateStaff(staffDTO);
		//----------------------------------------
		// 게시판 수정 명령한 후 수정 적용행의 개수를 리턴하기
		//----------------------------------------
		return updateCnt;
	}
	

	
	  //************************************************************** 
	  // [ 1개의 행의 스킬들 ] 삭제 후 삭제 적용행의 개수를 리턴하는 메소드 선언
	  //**************************************************************  
	  	@Override
	    public int DeleteStaffSkill(StaffDTO staffDTO){
	        // --------------------------------------
	        // [BoardDAOImpl 객체]의 getBoardCnt 메소드를 호출하여
	        // 삭제할 게시판의 존재 개수를 얻는다.
	        // --------------------------------------
	        int delete_staff_skill_Cnt = this.staffDAO.DeleteStaffSkill(staffDTO);
	        if(delete_staff_skill_Cnt==0) {return -1;}


	        
	        return delete_staff_skill_Cnt;


	    }	
	
	
	
	
	@Override
	public int insertUpdateSkillList(StaffDTO staffDTO) {
		System.out.println("이거는 뭐뭐임 " + staffDTO.getStaffSkillList());
		//----------------------------------------
		// BoardDAOImpl 객체의 insertBoard 메소드 호출하여 게시판 글 입력 후 입력 적용 행의 개수 얻기.	
		//----------------------------------------	
		int delete_staff_skill_Cnt = this.staffDAO.DeleteStaffSkill(staffDTO);
		int update_staff_skill = this.staffDAO.insertUpdateSkillList(staffDTO);		
		//----------------------------------------
		// 1개 게시판 글 입력 적용 행의 개수 리턴하기	
		//----------------------------------------		
		System.out.println("StaffServiceImpl.updateStaff 메소드 호출 성공");
		
		return update_staff_skill;
	}	
	
	
	
	
	
	
	
	
	
	
	
	
/*	
	//**************************************************************
	// [ 1개 게시판 글 ] 삭제 후 삭제 적용행의 개수를 리턴하는 메소드 선언
	//**************************************************************
	@Override
	public int deleteBoard(BoardDTO boardDTO) {
		
		//----------------------------------------
		// [ BoardDAOImpl ]의 getBoardCnt 메소드를 호출하여
		// 삭제할 게시판의 존재 개수를 얻는다.
		//----------------------------------------		
		int boardCnt = this.boardDAO.getBoardCnt(boardDTO);
		if(boardCnt==0) {return -1;}
		// [ BoardDAOImpl ]의 getPwdCnt 메소드를 호출하여
		// 삭제할 게시판의 비밀번호 존재 개수를 얻는다.
		// return -2 이면 암호가 틀린거다. 
		//----------------------------------------
		int pwdCnt = this.boardDAO.getPwdCnt(boardDTO);
		if(pwdCnt==0) {return -2;}
		//----------------------------------------		
		// [ BoardDAOImpl ]의 getChildrenCnt 메소드를 호출하여
		// [ 삭제할 게시판의 자식글 존재 개수 ]를 얻는다.
		//----------------------------------------
		int childenCnt = this.boardDAO.getChildrenCnt(boardDTO);
		//----------------------------------------
		// return -3 이면 자식 글이 있어서 부모글을 못지우게 하기.
		//----------------------------------------
		if(childenCnt > 0) {return -3;}
		//----------------------------------------
		// [ BoardDAOImpl 객체]의 downPrintNoCnt 메소드를 호출하여
		// [ 삭제할 게시판 이후 글의 출력 순서번호를 1씩 감소 시킨 후 수정 적용 행의 개수 ]를 얻는다.
		//----------------------------------------
		int downPrintNoCnt = this.boardDAO.downPrintNo(boardDTO);
		//----------------------------------------
		// [ BoardDAOImpl 객체]의 deleteBoard 메소드를 호출하여
		// [ 게시판 삭제 명령한 후 삭제 적용행의 개수 ]를 얻는다.
		// deleteCnt에 1이 들었으면 정상, -1,-2,-3 중 하나라도 해당이면 오류
		//----------------------------------------		
		int deleteCnt = this.boardDAO.deleteBoard(boardDTO);
		
		
		
		return deleteCnt;
	}
*/	
	
	
	
	
	
	
}
