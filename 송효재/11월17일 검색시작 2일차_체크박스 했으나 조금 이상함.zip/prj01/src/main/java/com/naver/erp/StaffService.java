package com.naver.erp;

import java.util.List;
import java.util.Map;

public interface StaffService {
	//**********************************************
	// [게시판 글 입력 후 입력 적용 행의 개수] 리턴하는 메소드 선언.
	// 이 인터페이스를 구현화한것이[ boardServiceImpl ]임
	// public이 없어도 public 이다. 즉 public이 없어도 public의 성격을 가지고 있음. default X )
	// 인터페이스 :[ public , static final ] 의 성격을 가진 속성변수와 
	// public , abstract 의 성격을 가진 메소드로 구성된 클래스와는 다른 단위 프로그램의 한 종류이다.
	// public 이 없지만 public의 성격, abstract가 없어도 abstract 의 성격을 가지고 있음(블록이 없어서)
	//**********************************************
	
	// [게시판 글 입력 휴 입력 적용행의 개수] 리턴하는 메소드 선언
	int insertStaff(StaffDTO staffDTO);
	
	int insertSkillList(StaffDTO staffDTO);
	
	
	// [1개 게시판 글] 리턴하는 메소드 선언
	StaffDTO getStaff(int staff_no);


	
	// 한 행을 삭제 후 적용행의 개수를 리턴하는 메소드 선언.
	int deleteStaff(StaffDTO staffDTO);

	
	// 한 행 안에 있는 스킬리스트도 같이 삭제시키기 위해 Service쪽에 선언.
	int DeleteStaffSkill(StaffDTO staffDTO);

	
	// [수정]같은 인설트 ㅋㅅㅋ
	int insertUpdateSkillList(StaffDTO staffDTO);
	
	
	
	
	
	
	// [staff 한 행의 수정 실행하고 수정 적용행의 개수]를 리턴하는 메소드 선언
	int updateStaff(StaffDTO staffDTO);
	
	
	// [1개 게시판 ] 삭제 후 적용행의 개수를 리턴하는 메소드 선언
//	int deleteBoard(BoardDTO boardDTO);
	
	
}
