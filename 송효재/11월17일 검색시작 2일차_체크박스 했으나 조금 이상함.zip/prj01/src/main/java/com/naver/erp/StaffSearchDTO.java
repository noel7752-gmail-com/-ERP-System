package com.naver.erp;

import java.util.List;
import java.util.Map;

public class StaffSearchDTO {
	private String keyword;
	
	private int selectPageNo = 1;   // 첫 로딩화면때 전체페이지가 보이게 하려면 1, 안보이게 하려면 0
	private int rowCntPerPage = 5;
	
	private List<String> gender;
	private int religion_code;
	private List<String> school_code;
	private List<String> skill_code;
	
	private String graduate_year_min;
	private String graduate_month_min;
	private String graduate_year_max;
	private String graduate_month_max;
//---------------------------------------------------------------------------
	public String getKeyword() {
		return keyword;
	}
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	public int getSelectPageNo() {
		return selectPageNo;
	}
	public void setSelectPageNo(int selectPageNo) {
		this.selectPageNo = selectPageNo;
	}
	public int getRowCntPerPage() {
		return rowCntPerPage;
	}
	public void setRowCntPerPage(int rowCntPerPage) {
		this.rowCntPerPage = rowCntPerPage;
	}
	public List<String> getGender() {
		return gender;
	}
	public void setGender(List<String> gender) {
		this.gender = gender;
	}
	public int getReligion_code() {
		return religion_code;
	}
	public void setReligion_code(int religion_code) {
		this.religion_code = religion_code;
	}
	public List<String> getSchool_code() {
		return school_code;
	}
	public void setSchool_code(List<String> school_code) {
		this.school_code = school_code;
	}
	public List<String> getSkill_code() {
		return skill_code;
	}
	public void setSkill_code(List<String> skill_code) {
		this.skill_code = skill_code;
	}
	public String getGraduate_year_min() {
		return graduate_year_min;
	}
	public void setGraduate_year_min(String graduate_year_min) {
		this.graduate_year_min = graduate_year_min;
	}
	public String getGraduate_month_min() {
		return graduate_month_min;
	}
	public void setGraduate_month_min(String graduate_month_min) {
		this.graduate_month_min = graduate_month_min;
	}
	public String getGraduate_year_max() {
		return graduate_year_max;
	}
	public void setGraduate_year_max(String graduate_year_max) {
		this.graduate_year_max = graduate_year_max;
	}
	public String getGraduate_month_max() {
		return graduate_month_max;
	}
	public void setGraduate_month_max(String graduate_month_max) {
		this.graduate_month_max = graduate_month_max;
	}

	
	
	

}