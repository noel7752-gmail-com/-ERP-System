package com.naver.erp;

import java.util.List;
import java.util.Map;

public interface StaffDAO {
	//*************************************
	// 게시판 글 입력 후 입력 적용 행의 개수 리턴하는 메소드 선언
	//*************************************
	int insertStaff(StaffDTO staffDTO);
	
	
	
	//*************************************
	// [검색한 게시판 목록] 리턴하는 메소드 선언
	//*************************************
	 List<Map<String,String>> getStaffList(StaffSearchDTO staffSearchDTO);


	 
	 int getStaffListAllCnt(StaffSearchDTO staffSearchDTO); 
	 
	 
	 

	//*************************************
	//1개의 게시판 정보를 리턴하는 메소드 선언
	//*************************************
	StaffDTO getStaff(int staff_no);
	
 
	 
	 
	//*************************************
	// [종교 리스트] 리턴하는 메소드 선언
	//*************************************
	List<String> getReligionList();
	//*************************************
	// [학력 리스트] 리턴하는 메소드 선언
	//*************************************	
	List<String> getSchoolList();
	//*************************************
	// [기술 리스트] 리턴하는 메소드 선언
	//*************************************	
	List<String> getSkillList();
	
	
	//[사원 스킬] 리턴하는 메소드 서언
	int  insertSkillList(StaffDTO staffDTO);
	
	
	// 한 행을 클릭시 나오는 기술리스트
	List<Map<String,String>> getStaffSkillList(int staff_no);
	
	
	// 삭제/수정 할 행이 있는지 확인.
	int getStaffCnt(StaffDTO staffDTO);
	
	// 삭제/수정할 행 안의 스킬리스트가 있는지 확인.
	int getStaffSkillCnt(StaffDTO staffDTO);
	
	// 행 삭제
	int deleteStaff(StaffDTO staffDTO);
	
	// 한 행 안에 있는 스킬리스트 삭제.
	int DeleteStaffSkill(StaffDTO staffDTO); 
	
	// 행 수정
	int updateStaff(StaffDTO staffDTO);
	
	
	// [수정]같은 인설트 ㅋㅅㅋ 
	int insertUpdateSkillList(StaffDTO staffDTO);
	
	//****************************************************
	// [검색한 게시판 목록 총개수] 리턴하는 메소드 선언
	//****************************************************
//	int getStaffListAllCnt(StaffSearchDTO staffSearchDTO);	 

	 
	 
	 
	//*************************************
	// 수정할 게시판의 존재 개수를 리턴하는 메소드 선언
	//*************************************	 
//	 int getStaffCnt(StaffDTO staffDTO); 
	 
	 
	 
	 
	//*************************************
	// 수정할 게시판의 비밀번호 존재 개수를 리턴하는 메소드 선언.
	//*************************************	 
//	 int getPwdCnt(BoardDTO boardDTO);	
	 
	 
	 
	  
	 
	//*************************************
	// 게시판 수정 명령한 후 수정 적용행의 개수를 리턴하는 메소드 선언
	//*************************************
//	 int updateBoard(BoardDTO boardDTO);
	 
	 
	 
	 
	 
	 
	//**************************************************************
	// [ 삭제할 게시판의 자식글 존재 개수 ]
	//**************************************************************	 
//	 int getChildrenCnt(BoardDTO boardDTO);
	//**************************************************************
	//  삭제될 게시판 이후 글의 순서번호를 1씩 감소  시키는 메소드 선언 
	//**************************************************************	 
//	 int downPrintNo(BoardDTO boardDTO);	 
	//**************************************************************
	// 게시판 삭제 명령한 후 삭제 적용행의 개수를 얻는 메소드 선언  
	//**************************************************************	 
//	 int deleteBoard(BoardDTO boardDTO);	 
	 
	 
	 
	 
	 

}
