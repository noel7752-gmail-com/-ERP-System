package com.staff.staff.DTO;

import java.util.ArrayList;

public class StaffSearchDTO {
    private String keyword;
    private String religion;
    private ArrayList<String> gender;
    private ArrayList<String> skill;
    private ArrayList<String> school;
    public String getKeyword() {
        return keyword;
    }
    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }
    public String getReligion() {
        return religion;
    }
    public void setReligion(String religion) {
        this.religion = religion;
    }
    public ArrayList<String> getGender() {
        return gender;
    }
    public void setGender(ArrayList<String> gender) {
        this.gender = gender;
    }
    public ArrayList<String> getSkill() {
        return skill;
    }
    public void setSkill(ArrayList<String> skill) {
        this.skill = skill;
    }
    public ArrayList<String> getSchool() {
        return school;
    }
    public void setSchool(ArrayList<String> school) {
        this.school = school;
    }
    
}
