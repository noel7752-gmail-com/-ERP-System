package com.staff.staff.DAO;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.staff.staff.DTO.StaffSearchDTO;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class StaffDAO {
    
    @Autowired
    private SqlSession sqlSession;

    public Map<String,List<Map>> getInItList() {
        List<Map> religion = sqlSession.selectList("com.naver.staff.DAO.staffDAO.getReligion");
        List<Map> school = sqlSession.selectList("com.naver.staff.DAO.staffDAO.getSchool");
        List<Map> skill = sqlSession.selectList("com.naver.staff.DAO.staffDAO.getSkill");
        Map<String,List<Map>> map = new HashMap<String,List<Map>>();
        map.put("religion",religion);
        map.put("school",school);
        map.put("skill",skill);

        return map;
    }

    public List<Map> getSearchStaffList(StaffSearchDTO staffSearchDTO) {
        List<Map> searchStaffList =  sqlSession.selectList("com.naver.staff.DAO.staffDAO.getSearchStaffList", staffSearchDTO);
        System.out.println(searchStaffList.size());
        return searchStaffList;
    }

}
