package com.staff.staff.Controller;

import java.util.List;
import java.util.Map;

import com.staff.staff.DAO.StaffDAO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@CrossOrigin(origins = "http://localhost:3000")
public class staffController {

    @Autowired
    private StaffDAO staffDAO;


    @RequestMapping(value = "/staff_search_form.do", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
    @ResponseBody
    public Map<String,List<Map>> staffSearchForm() {
        Map<String,List<Map>> initList = this.staffDAO.getInItList();
        return initList;
    }
    
}