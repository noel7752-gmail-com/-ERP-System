import React from "react";
import { Route } from "react-router-dom";

import staffSearch from "./staff/staffSearch";

function App() {
  return (
    <div>
      <Route path="/staff_search_form.do" component={staffSearch}></Route>
    </div>
  );
}

export default App;
