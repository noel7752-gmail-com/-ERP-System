import React, { Component } from "react";
import styled from "styled-components";
import tableStyle from "./tableStyled/tablestyled";
import axios from "axios";

const CONTAINER = styled.div`
  width: 1500px;
  margin: 40px auto;
  height: 1500px;
  align-items: center;
`;
const TABLE = styled.table`
  width: 1000px;
  margin: 30px auto;
  ${tableStyle.border}
  ${tableStyle.borderCollapse}
`;
const TR = styled.tr`
  ${tableStyle.border}
`;
const TD = styled.td`
  ${tableStyle.border}
  ${tableStyle.cellPadding}
  text-align: center;
`;
const TH = styled.th`
  ${tableStyle.border}
  ${tableStyle.cellPadding}
  background-color: lightgray;
  font-size: 17px;
  font-weight: bold;
`;
const SELECT = styled.select`
  width: 70px;
  :not(:first-child) {
    margin-left: 15px;
  }
`;
const DIV = styled.div`
  width: 1000px;
  margin: 30px auto;
  text-align: center;
  input:first-child {
    width: 400px;
    margin: 0px 150px;
  }
  input:not(:first-child) {
    width: 80px;
    margin-left: 15px;
  }
`;

class staffSearch extends Component {
  state = {
    init: null,
    search: false,
    result: null,
    searchInfo: {
      keyword: "",
      gender: [],
      skill: [],
      religion: 0,
      school: [],
    },
  };
  setYear = () => {
    const sysdate = new Date();
    const sysYear = sysdate.getFullYear();
    var option = [];
    for (var i = sysYear - 20; i <= sysYear + 20; i++) {
      option.push(i);
    }
    return option;
  };
  componentDidMount = () => {
    axios
      .get("http://localhost:8081/get_init_staff_form.do")
      .then((responseJSON) => {
        this.setState({
          init: responseJSON.data,
        });
        // 이벤트 등록 ======================================================================
        // 검색 눌렀을때 검색 조건 가지고 서버로 접속하기.
        const search = document.getElementById("search");
        search.addEventListener("click", () => {
          axios
            .post("http://localhost:8081/staff_search_result.do", this.state.searchInfo)
            .then((responseJSON) => {
              console.log(responseJSON.data);
              this.setState({
                result: responseJSON.data,
              });
            })
            .catch((error) => {
              console.log(error);
            });
        });
        // 모두 검색 눌렀을때 폼 리셋하고 리스트 가져오기.
        const allSearch = document.getElementById("allsearch");
        allSearch.addEventListener("click", () => {
          document.staffSearchForm.reset();
          axios
            .get("http://localhost:8081/get_staff_list.do")
            .then((responseJSON) => {
              this.setState({
                search: true,
                result: responseJSON.data,
              });
            })
            .catch((error) => {
              console.log(error);
            });
        });
        // 키워드 입력했을때 state에 저장
        const keyword = document.getElementById("keyword");
        keyword.addEventListener("change", (event) => {
          this.setState({
            searchInfo: {
              ...this.state.searchInfo,
              [event.target.name]: event.target.value,
            },
          });
        });
        // 성별 체크했을때 state저장
        const gender = document.getElementsByClassName("gender");
        for (var i = 0; i < gender.length; i++) {
          gender[i].addEventListener("change", (event) => {
            const checked = event.target.checked;
            if (checked) {
              this.setState({
                searchInfo: {
                  ...this.state.searchInfo,
                  gender: [...this.state.searchInfo.gender, event.target.value],
                },
              });
            } else {
              this.setState({
                searchInfo: {
                  ...this.state.searchInfo,
                  gender: [...this.state.searchInfo.gender.filter((item) => item !== event.target.value)],
                },
              });
            }
          });
        }
        // 종교 선택했을때 state저장
        const religion = document.getElementById("religion");
        religion.addEventListener("change", (event) => {
          this.setState({
            searchInfo: {
              ...this.state.searchInfo,
              [event.target.name]: event.target.value,
            },
          });
        });
        // 학력 체크했을때 state저장
        const school = document.getElementsByClassName("school");
        for (var j = 0; j < school.length; j++) {
          school[j].addEventListener("change", (event) => {
            const checked = event.target.checked;
            if (checked) {
              this.setState({
                searchInfo: {
                  ...this.state.searchInfo,
                  school: [...this.state.searchInfo.school, event.target.value],
                },
              });
            } else {
              this.setState({
                searchInfo: {
                  ...this.state.searchInfo,
                  school: [...this.state.searchInfo.school.filter((item) => item !== event.target.value)],
                },
              });
            }
          });
        }
        // 스킬 체크했을때 state저장
        const skill = document.getElementsByClassName("skill");
        for (var t = 0; t < skill.length; t++) {
          skill[t].addEventListener("change", (event) => {
            const checked = event.target.checked;
            if (checked) {
              this.setState({
                searchInfo: {
                  ...this.state.searchInfo,
                  skill: [...this.state.searchInfo.skill, event.target.value],
                },
              });
            } else {
              this.setState({
                searchInfo: {
                  ...this.state.searchInfo,
                  skill: [...this.state.searchInfo.skill.filter((item) => item !== event.target.value)],
                },
              });
            }
          });
        }
        // 이벤트 등록 끝 ======================================================================
      })
      .catch((error) => {
        console.log(error);
      });
  };

  render() {
    const year = this.setYear();
    const state = this.state;
    return state.init === null ? (
      <center>
        <h1>Loading...</h1>
      </center>
    ) : (
      <CONTAINER>
        <form name="staffSearchForm" id="searchForm" method="post">
          <TABLE>
            <TR>
              <TH colSpan="6">사원정보 검색</TH>
            </TR>
            <TR>
              <TH>키워드</TH>
              <TD>
                <input type="text" name="keyword" id="keyword" />
              </TD>
              <TH>성별</TH>
              <TD>
                <input type="checkbox" name="gender" value="1" className="gender" />남<input type="checkbox" name="gender" value="2" className="gender" />여
              </TD>
              <TH>종교</TH>
              <TD>
                <SELECT name="religion" id="religion">
                  <option></option>
                  {state.init.religion.map((item) => (
                    <option value={item.RELIGION_CODE}>{item.RELIGION_NAME}</option>
                  ))}
                </SELECT>
              </TD>
            </TR>
            <TR>
              <TH>학력</TH>
              <TD>
                {state.init.school.map((item) => {
                  return (
                    <>
                      <input type="checkbox" name="staffSchool" className="school" value={item.SCHOOL_CODE} />
                      {item.SCHOOL_NAME}
                    </>
                  );
                })}
              </TD>
              <TH>기술</TH>
              <TD colSpan="3">
                {state.init.skill.map((item) => {
                  return (
                    <>
                      <input type="checkbox" name="staffSkill" className="skill" value={item.SKILL_CODE} />
                      {item.SKILL_NAME}
                    </>
                  );
                })}
              </TD>
            </TR>
            <TR>
              <TH>졸업일</TH>
              <TD colSpan="5">
                <SELECT name="staffGradDay_start">
                  <option value=""></option>
                  {year.map((item) => (
                    <option value={item}>{item}</option>
                  ))}
                </SELECT>
                년
                <SELECT name="staffGradDay_start">
                  <option value=""></option>
                </SELECT>
                월
                <SELECT name="staffGradDay_start">
                  <option value=""></option>
                </SELECT>
                일 ~
                <SELECT name="staffGradDay_end">
                  <option value=""></option>
                  {year.map((item) => (
                    <option value={item}>{item}</option>
                  ))}
                </SELECT>
                년
                <SELECT name="staffGradDay_end">
                  <option value=""></option>
                </SELECT>
                월
                <SELECT name="staffGradDay_end">
                  <option value=""></option>
                </SELECT>
                일
              </TD>
            </TR>
          </TABLE>
          <DIV>
            <input type="button" id="search" value="검색" />
            <input type="button" id="allsearch" value="모두 검색" />
            <input type="reset" value="초기화" />
            <input type="button" value="등록" />
          </DIV>
        </form>
        {state.search === false ? (
          <center>
            <h1>검색해주세요!</h1>
          </center>
        ) : state.result.length === 0 ? (
          <center>
            <h1>검색결과가 없습니다!</h1>
          </center>
        ) : (
          <TABLE>
            <TR>
              <TH>번호</TH>
              <TH>이름</TH>
              <TH>학교</TH>
              <TH>종교</TH>
              <TH>스킬</TH>
              <TH>졸업일</TH>
              <TH></TH>
            </TR>
            {state.result.map((item) => (
              <TR>
                <TD>{item.STAFF_NO}</TD>
                <TD>{item.STAFF_NAME}</TD>
                <TD>{item.SCHOOL_NAME}</TD>
                <TD>{item.RELIGION_NAME}</TD>
                <TD>{item.SKILL_NAME}</TD>
                <TD>{item.GRADUATE_DAY}</TD>
                <TD>
                  <input type="button" value="수정/삭제" />
                </TD>
              </TR>
            ))}
          </TABLE>
        )}
      </CONTAINER>
    );
  }
}
export default staffSearch;
