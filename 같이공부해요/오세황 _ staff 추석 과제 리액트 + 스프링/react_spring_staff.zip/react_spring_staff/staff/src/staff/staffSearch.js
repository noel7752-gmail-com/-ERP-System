import React, { Component } from "react";
import styled from "styled-components";
import tableStyle from "./tableStyled/tablestyled";
import axios from "axios";

const CONTAINER = styled.div`
  width: 1500px;
  margin: 40px auto;
  height: 1500px;
  align-items: center;
`;
const TABLE = styled.table`
  width: 1000px;
  margin: 0 auto;
  ${tableStyle.border}
  ${tableStyle.borderCollapse}
`;
const TR = styled.tr`
  ${tableStyle.border}
`;
const TD = styled.td`
  ${tableStyle.border}
  ${tableStyle.cellPadding}
  text-align: center;
`;
const TH = styled.th`
  ${tableStyle.border}
  ${tableStyle.cellPadding}
  background-color: lightgray;
  font-size: 17px;
  font-weight: bold;
`;
const SELECT = styled.select`
  width: 70px;
  :not(:first-child) {
    margin-left: 15px;
  }
`;

class staffSearch extends Component {
  state = {
    init: null,
  };
  setYear = () => {
    var sysdate = new Date();
    var sysYear = sysdate.getFullYear();
    var option = [];
    for (var i = sysYear - 20; i <= sysYear + 20; i++) {
      option.push(i);
    }
    return option;
  };
  componentDidMount = () => {
    axios
      .get("http://localhost:8081/staff_search_form.do")
      .then((responseJSON) => {
        this.setState({
          init: responseJSON.data,
        });
      })
      .catch((error) => {
        console.log(error);
      });
  };

  render() {
    var year = this.setYear();
    const state = this.state;
    return state.init === null ? (
      <center>
        <h1>Loading...</h1>
      </center>
    ) : (
      <CONTAINER>
        <TABLE>
          <TR>
            <TH colSpan="6">사원정보 검색</TH>
          </TR>
          <TR>
            <TH>키워드</TH>
            <TD>
              <input type="text" name="keyword" />
            </TD>
            <TH>성별</TH>
            <TD>
              <input type="checkbox" name="gender" />남<input type="checkbox" name="gender" />여
            </TD>
            <TH>종교</TH>
            <TD>
              <SELECT name="religion">
                {state.init.religion.map((item) => (
                  <option value={item.RELIGION_CODE}>{item.RELIGION_NAME}</option>
                ))}
              </SELECT>
            </TD>
          </TR>
          <TR>
            <TH>학력</TH>
            <TD>
              {state.init.school.map((item) => {
                return (
                  <>
                    <input type="checkbox" name="staffSchool" value={item.SCHOOL_CODE} />
                    {item.SCHOOL_NAME}
                  </>
                );
              })}
            </TD>
            <TH>기술</TH>
            <TD colSpan="3">
              {state.init.skill.map((item) => {
                return (
                  <>
                    <input type="checkbox" name="staffSkill" value={item.SKILL_CODE} />
                    {item.SKILL_NAME}
                  </>
                );
              })}
            </TD>
          </TR>
          <TR>
            <TH>졸업일</TH>
            <TD colSpan="5">
              <SELECT name="staffGradDay_start">
                <option value=""></option>
                {year.map((item) => (
                  <option value={item}>{item}</option>
                ))}
              </SELECT>
              년
              <SELECT name="staffGradDay_start" disabled>
                <option value=""></option>
              </SELECT>
              월
              <SELECT name="staffGradDay_start" disabled>
                <option value=""></option>
              </SELECT>
              일 ~
              <SELECT name="staffGradDay_end">
                <option value=""></option>
                {year.map((item) => (
                  <option value={item}>{item}</option>
                ))}
              </SELECT>
              년
              <SELECT name="staffGradDay_end" disabled>
                <option value=""></option>
              </SELECT>
              월
              <SELECT name="staffGradDay_end" disabled>
                <option value=""></option>
              </SELECT>
              일
            </TD>
          </TR>
        </TABLE>
      </CONTAINER>
    );
  }
}
export default staffSearch;
