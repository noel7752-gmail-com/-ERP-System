const tableStyle = {
  border: `
        border: 1px solid black;
    `,
  cellPadding: `padding: 5px;
    `,
  borderCollapse: `
        border-collapse: collapse;
    `,
};
export default tableStyle;
