package com.daybreak.prj.DAO;

import java.util.List;
import java.util.Map;

import com.daybreak.prj.DTO.ERPDTO;
import com.daybreak.prj.DTO.ERPSearchDTO;

public interface ERPDAO {
	
	// =====================================================================
	// 리스트 가져오는 부분.
	List<Map<String,String>> getSearcALLhList(ERPSearchDTO erpSearchDTO);
	int getSearchAllCnt(ERPSearchDTO erpSearchDTO);
	// =====================================================================

	// =====================================================================
    // 입력하는 메소드 선언
    int insertErp(ERPDTO erpDTO);
	// =====================================================================

	// =====================================================================
	// 게시판 이미지 이름 가져오는  메소드 선언
	public String G_pic(ERPDTO erpDTO);
	// =====================================================================

	// =====================================================================
    // 삭제할 제품 존재개수 리턴
    public int get_del_ERPCnt(ERPDTO erpDTO);
	// =====================================================================

	// =====================================================================
    // 삭제후 삭제 적용행의 개수 리턴
    public int delete_erp(ERPDTO erpDTO);
	// =====================================================================

	// =====================================================================
    // input 쪽 삭제 적용 개수 리턴 
    public int delete_input(ERPDTO erpDTO);
	// =====================================================================

	// =====================================================================
    // output 쪽 삭제 적용 개수 리턴 
    public int delete_output(ERPDTO erpDTO);
	// =====================================================================

	// =====================================================================
    // 수정 적용 개수 리턴 
	public int getUpdateItemCnt(ERPDTO erpDTO);
	// =====================================================================



    //============================================================================
	//각 재고관리 카테고리별 검색리스트 가져오는 메소드
	public List<Map<String,String>> getSearch_G_List(ERPSearchDTO erpSearchDTO);

	public List<Map<String,String>> getSearch_T_List(ERPSearchDTO erpSearchDTO);
	
	public List<Map<String,String>> getSearch_P_List(ERPSearchDTO erpSearchDTO);
	
	public List<Map<String,String>> getSearch_M_List(ERPSearchDTO erpSearchDTO);
	//============================================================================
	//각 카테고리별 갬색개수를 가져오는 메소드
	int getSearch_G_List_Cnt(ERPSearchDTO erpSearchDTO);
	int getSearch_T_List_Cnt(ERPSearchDTO erpSearchDTO);
	int getSearch_P_List_Cnt(ERPSearchDTO erpSearchDTO);
	int getSearch_M_List_Cnt(ERPSearchDTO erpSearchDTO);
	
	
	
	
	//=======================================================
	// 통합검색쪽 검색 조건(셀렉스 및 체크박스) 값 가져오는 메소드
	
	
	// 대 카테고리
	List<Map<String,String>> get_Category_List();
	
	//가전 종류 카테고리
	List<Map<String,String>> get_Gajeon_Category_List();
	List<Map<String,String>> get_Season_Gajeon_Category_List();
	List<Map<String,String>> get_kitchen_Gajeon_Category_List();
	List<Map<String,String>> get_Life_Gajeon_Category_List();
	
	
	//TV 종류 카테고리
	List<Map<String,String>> get_TV_Category_List();
	
	
	//PC 종류 카테고리
	List<Map<String,String>> get_PC_Category_List();
	List<Map<String,String>> get_Gaming_PC_Category_List();
	List<Map<String,String>> get_Office_PC_Category_List();
	
	
	//모바일 종류 카테고리
	List<Map<String,String>> get_Mobile_Category_List();
	List<Map<String,String>> get_Phone_Category_List();
	List<Map<String,String>> get_Tablet_Category_List();
	
	
	
	
































    // ===================================================================================
    // 게시판 DAO 참고용 주석. 삭제하지마시고, 그냥 코드들 참고하시고 위에 코딩 해주세요.
    // ===================================================================================
/*
    // ****************************************************
    // [게시판 글 입력 후 입력 적용 행의 개수] 리턴하는 메소드 선언
    // ****************************************************
    int insertBoard(BoardDTO boardDTO);
	
    // ******************************************************
    // [검색한 게시판 목록] 리턴하는 메소드 선언
    // ******************************************************
    List<Map<String,String>> getBoardList( BoardSearchDTO boardSearchDTO );

    // ******************************************************
    // [1개의 게시판 정보]를 리턴하는 메소드 선언
    // ******************************************************
    BoardDTO getBoard(int b_no);
    // ******************************************************
    // 조회수를 1 증가하고 업데이트한 행의 개수를 얻는 메소드 선언
    // ******************************************************
    int updateReadcount(int b_no);  
    
    // ******************************************************
    // 수정할 게시판의 존재 개수를 리턴하는 
    // ******************************************************
    int getBoardCnt(BoardDTO boardDTO);
    // ******************************************************
    // 수정할 게시판의 비밀번호 존재 개수를 리턴하는 메소드 선언
    // ******************************************************
    int getPwdCnt(BoardDTO boardDTO);
    // ******************************************************
    // 게시판 수정 명령한 후 수정 적용행의 개수를 리턴하는 메소드 선언
    // ******************************************************
    int updateBoard(BoardDTO boardDTO);

    // ******************************************************
    // [삭제할 게시판의 아들글 존재개수]를 얻는 메소드 선언
    // ******************************************************
    int getChildrenCnt(BoardDTO boardDTO);

    // ******************************************************
    // [삭제될 게시판 이후 글의 출력 순서번호를 1씩 감소 시키는 메소드 선언
    // ******************************************************
    int downPrintNo(BoardDTO boardDTO);

    // ******************************************************
    // [게시판 삭제 명령한 후 삭제 적용행의 개수]를 얻는 메소드 선언
    // ******************************************************
    int deleteBoard(BoardDTO boardDTO);

    // ******************************************************
    // [게시판 글 출력번호 1증가하고 수정 행의 개수] 리턴하는 메소드 선언
    // ******************************************************
    int updatePrintNo(BoardDTO boardDTO);

    // ******************************************************
    // [검색한 게시판 목록 총개수] 리턴하는 메소드 선언
    // ******************************************************
    int getBoardListCount(BoardSearchDTO boardSearchDTO);
    
    // ******************************************************
    // 게시판 이미지 이름가져오는 메소드 선언
    // ******************************************************
    public String getPic(BoardDTO boardDTO);
*/

}
