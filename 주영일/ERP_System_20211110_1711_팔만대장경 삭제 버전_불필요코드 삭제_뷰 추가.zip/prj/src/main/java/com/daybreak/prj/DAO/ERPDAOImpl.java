package com.daybreak.prj.DAO;

import java.util.List;
import java.util.Map;

import org.apache.taglibs.standard.lang.jstl.test.beans.PublicInterface2;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.daybreak.prj.DTO.ERPDTO;
import com.daybreak.prj.DTO.ERPHomeDTO;
import com.daybreak.prj.DTO.ERPSearchDTO;
import com.daybreak.prj.DTO.ERPStockDTO;

// mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
// [DAO 클래스]인 [BoardDAOImpl 클래스] 선언
// mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    // @Repository 를 붙임으로써 [DAO 클래스]임을 지정하게 되고, bean 태그로 자동 등록된다.  
// mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
@Repository
public class ERPDAOImpl implements ERPDAO {

    // ******************************************************
    // 속성변수 sqlSession 선언하고, [SqlSessionTemplate 객체]를 생성해 저장
    // ******************************************************
        // @Autowired 역할 -> 속성변수에 붙은 자료형이 [인터페이스]면 이를 구현한 [클래스]를 객체화하여 저장한다.
        // @Autowired 역할 -> 속성변수에 붙은 자료형이 [클래스]면 이를 객체화 하여 저장한다.  
    @Autowired
    private SqlSessionTemplate sqlSession;    

    
    // =====================================================================
    // 리스트 가져오는 부분. 
    public List<Map<String, String>> getSearcALLhList(ERPSearchDTO erpSearchDTO) {


        System.out.println(" 검색 키워드 ITEM_CODE ====> " + erpSearchDTO.getITEM_CODE());
        System.out.println(" 검색 키워드 getSearch_energy_grade_code ====> " + erpSearchDTO.getSearch_energy_grade_code());

		List<Map<String,String>> searchList = this.sqlSession.selectList(
				"com.daybreak.prj.ERPDAO.getSearcALLhList"
				,erpSearchDTO
		);
		return searchList;
	}

	public int getSearchAllCnt(ERPSearchDTO erpSearchDTO) {
		int searchAlCnt = this.sqlSession.selectOne(
				"com.daybreak.prj.ERPDAO.getSearchAllCnt"	
				,erpSearchDTO
		);
		return searchAlCnt;
	}    
    // =====================================================================




    // =====================================================================
    // 재고관리 카테고리 리스트(가전) [[[입고 가져오는 부분. 
    public List<Map<String, String>> get_g_stock_manage(ERPSearchDTO erpSearchDTO) {

		List<Map<String,String>> get_g_stock_manageList = this.sqlSession.selectList(
				"com.daybreak.prj.ERPDAO.get_g_stock_manage"
				,erpSearchDTO
		);
		return get_g_stock_manageList;
	}
    // 입고 리스트 검색개수 리턴 메서드
    public int get_stock_SearchAllCnt(ERPSearchDTO erpSearchDTO) {
		int searchAlCnt = this.sqlSession.selectOne(
				"com.daybreak.prj.ERPDAO.get_stock_SearchAllCnt"	
				,erpSearchDTO
		);
		return searchAlCnt;
	}
    // =====================================================================

    // =====================================================================
    // 재고관리 카테고리 리스트(가전) [[[출고 가져오는 부분. 
    public List<Map<String, String>> get_g_stock_manage_out(ERPSearchDTO erpSearchDTO) {

		List<Map<String,String>> get_g_stock_manageList = this.sqlSession.selectList(
				"com.daybreak.prj.ERPDAO.get_g_stock_manage_out"
				,erpSearchDTO
		);
		return get_g_stock_manageList;
	}
    // 출고 리스트 검색개수 리턴 메서드
    public int get_out_stock_SearchAllCnt(ERPSearchDTO erpSearchDTO) {
		int searchAlCnt = this.sqlSession.selectOne(
				"com.daybreak.prj.ERPDAO.get_out_stock_SearchAllCnt"	
				,erpSearchDTO
		);
		return searchAlCnt;
	}
    // =====================================================================



    //MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
    // =====================================================================
    // 재고관리 카테고리 리스트(pc) [[[입고 가져오는 부분. 
    public List<Map<String, String>> get_p_stock_manage(ERPSearchDTO erpSearchDTO) {

		List<Map<String,String>> get_p_stock_manageList = this.sqlSession.selectList(
				"com.daybreak.prj.ERPDAO.get_p_stock_manage"
				,erpSearchDTO
		);
		return get_p_stock_manageList;
	}
    // 입고 리스트 검색개수 리턴 메서드
    public int get_p_stock_SearchAllCnt(ERPSearchDTO erpSearchDTO) {
		int searchAlCnt = this.sqlSession.selectOne(
				"com.daybreak.prj.ERPDAO.get_p_stock_SearchAllCnt"	
				,erpSearchDTO
		);
		return searchAlCnt;
	}
    // =====================================================================

    // =====================================================================
    // 재고관리 카테고리 리스트(pc) [[[출고 가져오는 부분. 
    public List<Map<String, String>> get_p_stock_manage_out(ERPSearchDTO erpSearchDTO) {

		List<Map<String,String>> get_p_stock_manageList = this.sqlSession.selectList(
				"com.daybreak.prj.ERPDAO.get_p_stock_manage_out"
				,erpSearchDTO
		);
		return get_p_stock_manageList;
	}
    // 출고 리스트 검색개수 리턴 메서드
    public int get_p_out_stock_SearchAllCnt(ERPSearchDTO erpSearchDTO) {
		int searchAlCnt = this.sqlSession.selectOne(
				"com.daybreak.prj.ERPDAO.get_p_out_stock_SearchAllCnt"	
				,erpSearchDTO
		);
		return searchAlCnt;
	}
	//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM


	//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
    // 재고관리 카테고리 리스트 가져오는 부분(모바일) 입고 
    public List<Map<String,String>> get_m_stock_manage(ERPSearchDTO erpSearchDTO){
        List<Map<String,String>> get_m_stock_manageList = this.sqlSession.selectList(
                "com.daybreak.prj.ERPDAO.get_m_stock_manage"
                ,erpSearchDTO
        );
        return get_m_stock_manageList;
    }
    
    // 재고관리 카테고리 리스트 가져오는 부분(모바일) 출고 
    public List<Map<String,String>> get_m_stock_manage_out(ERPSearchDTO erpSearchDTO)	{
        List<Map<String,String>> get_m_stock_manageList = this.sqlSession.selectList(
                "com.daybreak.prj.ERPDAO.get_m_stock_manage_out"
                ,erpSearchDTO
        );
        return get_m_stock_manageList;
    }
        

    // 재고관리(입고) 카테고리 총개수 가져오는 부분(모바일) 
    public int get_m_stock_SearchAllCnt(ERPSearchDTO erpSearchDTO){
        int searchAlCnt = this.sqlSession.selectOne(
                "com.daybreak.prj.ERPDAO.get_m_stock_SearchAllCnt"	
                ,erpSearchDTO
        );
        return searchAlCnt;
    }
    
    // 재고관리(출고) 카테고리 총개수 가져오는 부분(모바일) 
    public int get_m_out_stock_SearchAllCnt(ERPSearchDTO erpSearchDTO){
        int searchAlCnt = this.sqlSession.selectOne(
                "com.daybreak.prj.ERPDAO.get_m_out_stock_SearchAllCnt"	
                ,erpSearchDTO
        );
        return searchAlCnt;   
    }
	//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
    


    //MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
    // 재고관리 카테고리 리스트(TV) [[[입고 가져오는 부분. 
    public List<Map<String, String>> get_t_stock_manage(ERPSearchDTO erpSearchDTO) {
    	

		List<Map<String,String>> get_t_stock_manageList = this.sqlSession.selectList(
				"com.daybreak.prj.ERPDAO.get_t_stock_manage"
				,erpSearchDTO
		);
		return get_t_stock_manageList;
	}

    // TV 입고 리스트 검색개수 리턴 메서드
    public int get_t_stock_SearchAllCnt(ERPSearchDTO erpSearchDTO) {
		int searchAlCnt = this.sqlSession.selectOne(
				"com.daybreak.prj.ERPDAO.get_t_stock_SearchAllCnt"	
				,erpSearchDTO
		);
		return searchAlCnt;
	}  


    // 재고관리 카테고리 리스트(TV) [[[출고 가져오는 부분. 
    public List<Map<String, String>> get_t_stock_manage_out(ERPSearchDTO erpSearchDTO) {

        List<Map<String,String>> get_t_stock_manageList = this.sqlSession.selectList(
                "com.daybreak.prj.ERPDAO.get_t_stock_manage_out"
                ,erpSearchDTO
        );
        return get_t_stock_manageList;
    }    
    
    // TV 출고 리스트 검색개수 리턴 메서드
    public int get_t_out_stock_SearchAllCnt(ERPSearchDTO erpSearchDTO) {
        int searchAlCnt = this.sqlSession.selectOne(
                "com.daybreak.prj.ERPDAO.get_t_out_stock_SearchAllCnt"	
                ,erpSearchDTO
        );
        return searchAlCnt;
    }    
    //MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM









    // =====================================================================
    // [게시판 글 입력 후 입력 적용 행의 개수]를 리턴하는 메소드 선언
    public int insertErp(ERPDTO erpDTO){
    	
    System.out.println("ErpDAOImpl. sqlSession.insert() 메소드 수행시작\r");
    // ----------------------------------------------
    // SqlSessionTemplate 객체의 insert 메소드 호출로
    // 게시판 글 입력 SQL 구문을 실행하고 입력 성공 행의 개수 얻기.
    // ----------------------------------------------
    int erpRegCnt = sqlSession.insert(
        // ----------------------------------------------
        // 실행할 SQL 구문의 위치를 지정하기.
        // 실행할 SQL 구문의 위치 문자열 패턴은 아래와 같다.
        // xml 파일 중에 "mapper태그의namespace명.mapper태그내부의호출할SQL구문소유한태그id값"
        // ----------------------------------------------
        "com.daybreak.prj.ERPDAO.insertErp"  
        // ----------------------------------------------
        // 호출할 SQL 구문에서 사용할 데이터 지정하기
        // ----------------------------------------------
        ,erpDTO                             
    );
    System.out.println("ErpDAOImpl. sqlSession.insert() 메소드 수행완료\r");
    return erpRegCnt;
    }
    // =====================================================================


    // =====================================================================
	// 게시판 이미지 이름 가져오는  메소드 선언
	public String G_pic(ERPDTO erpDTO){
		String g_pic  = this.sqlSession.selectOne(
				"com.daybreak.prj.ERPDAO.G_pic"	   // 실행할 SQL 구문의 위치 지정
				,erpDTO                        // 실행할 SQL 구문에서 사용할 데이터 지정
		);
		return g_pic ;
	}
    // =====================================================================


    // =====================================================================
    // 삭제할 제품 존재개수 리턴
    public int get_del_ERPCnt(ERPDTO erpDTO){
        //-------------------------------------------------------
        // [SqlSessionTemplate 객체]의 update(~,~) 를 호출하여 [자식글 존재 개수] 얻기
        //-------------------------------------------------------
        int del_ERPCnt = this.sqlSession.selectOne(
                "com.daybreak.prj.ERPDAO.get_del_ERPCnt"  // 실행할 SQL 구문의 위치 지정
                ,erpDTO							     // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return del_ERPCnt;
    }
    // =====================================================================

    // =====================================================================
    // 제품 삭제 명령한 후 삭제 적용행의 개수를 리턴하는 메소드 선언
    public int delete_erp(ERPDTO erpDTO){
        //-------------------------------------------------------
        // [SqlSessionTemplate 객체]의 update(~,~) 를 호출하여 
        // [게시판 삭제 명령]한 후 삭제 적용행의 개수 얻기
        //-------------------------------------------------------
        int deleteErpCnt = this.sqlSession.delete(
                "com.daybreak.prj.ERPDAO.delete_erp"  // 실행할 SQL 구문의 위치 지정
                ,erpDTO							  // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return deleteErpCnt;
    }
    // =====================================================================

    // =====================================================================
    // input 삭제 명령한 후 삭제 적용행의 개수를 리턴하는 메소드 선언
    public int delete_input(ERPDTO erpDTO){
        //-------------------------------------------------------
        // [SqlSessionTemplate 객체]의 update(~,~) 를 호출하여 
        // [게시판 삭제 명령]한 후 삭제 적용행의 개수 얻기
        //-------------------------------------------------------
        int delete_inputCnt = this.sqlSession.delete(
                "com.daybreak.prj.ERPDAO.delete_input"  // 실행할 SQL 구문의 위치 지정
                ,erpDTO							  // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return delete_inputCnt;
    }
    // =====================================================================

    // =====================================================================
    // input 삭제 명령한 후 삭제 적용행의 개수를 리턴하는 메소드 선언
    public int delete_output(ERPDTO erpDTO){
        //-------------------------------------------------------
        // [SqlSessionTemplate 객체]의 update(~,~) 를 호출하여 
        // [게시판 삭제 명령]한 후 삭제 적용행의 개수 얻기
        //-------------------------------------------------------
        int delete_outputCnt = this.sqlSession.delete(
                "com.daybreak.prj.ERPDAO.delete_output"  // 실행할 SQL 구문의 위치 지정
                ,erpDTO							  // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return delete_outputCnt;
    }
    // =====================================================================




    // =====================================================================
    // 제품 수정 명령한 후 수정 적용행의 개수를 리턴하는 메소드 선언
    public int getUpdateItemCnt(ERPDTO erpDTO) {

        System.out.println("ERPDTO 확인 DAO 임플에서 getG_sub_category_code===> " + erpDTO.getG_sub_category_code());
        System.out.println("ERPDTO 확인 DAO 임플에서 getG_sub_sub_category_code===> " + erpDTO.getG_sub_sub_category_code());
        System.out.println("ERPDTO 확인 DAO 임플에서 getBrand_code ===> " + erpDTO.getBrand_code());
        System.out.println("ERPDTO 확인 DAO 임플에서 getCategory_code ===> " + erpDTO.getCategory_code());
        System.out.println("ERPDTO 확인 DAO 임플에서 getColor_code===> " + erpDTO.getColor_code());
        System.out.println("ERPDTO 확인 DAO 임플에서 getEnergy_grade_code===> " + erpDTO.getEnergy_grade_code());
        System.out.println("ERPDTO 확인 DAO 임플에서 getG_build_day===> " + erpDTO.getG_build_day());
        System.out.println("ERPDTO 확인 DAO 임플에서 getG_discontinued===> " + erpDTO.getG_discontinued());
        System.out.println("ERPDTO 확인 DAO 임플에서 getG_item_code===> " + erpDTO.getG_item_code());
        System.out.println("ERPDTO 확인 DAO 임플에서 getG_item_name===> " + erpDTO.getG_item_name());
        System.out.println("ERPDTO 확인 DAO 임플에서 getG_item_size_x===> " + erpDTO.getG_item_size_x());
        System.out.println("ERPDTO 확인 DAO 임플에서 getG_item_size_y===> " + erpDTO.getG_item_size_y());
        System.out.println("ERPDTO 확인 DAO 임플에서 getG_item_size_z===> " + erpDTO.getG_item_size_z());
        System.out.println("ERPDTO 확인 DAO 임플에서 getParamV===> " + erpDTO.getParamV());

		int updateItemCnt = this.sqlSession.update(
	            //-----------------------------------------------
	            "com.daybreak.prj.ERPDAO.updateItem"
	            //-----------------------------------------------
	            ,erpDTO
	        );                       

	        // -------------------------------------------
	        // [1개 게시판 글 정보] 리턴하기
	        // -------------------------------------------
	        return updateItemCnt;
	}
    // =====================================================================


  




	//=================================================
	// 검색조건 품목리스트 가져는 메소드
	
	// 가전 종류 가져오는 메소드
	@Override
	public List<Map<String,String>> get_Category_List() {
		List<Map<String,String>> category_list = this.sqlSession.selectList(

                "com.daybreak.prj.ERPDAO.get_Category_List"

            );
        return category_list;
	}

	@Override
	public List<Map<String, String>> get_Gajeon_Category_List() {
		List<Map<String,String>> gajeon_category_list = this.sqlSession.selectList(

                "com.daybreak.prj.ERPDAO.get_Gajeon_Category_List"

            );
        return gajeon_category_list;
	}

	@Override
	public List<Map<String, String>> get_Season_Gajeon_Category_List() {
		List<Map<String,String>> season_gajeon_category_list = this.sqlSession.selectList(

                "com.daybreak.prj.ERPDAO.get_Season_Gajeon_Category_List"

            );
        return season_gajeon_category_list;
	}

	@Override
	public List<Map<String, String>> get_kitchen_Gajeon_Category_List() {
		List<Map<String,String>> kitchen_gajeon_category_list = this.sqlSession.selectList(

                "com.daybreak.prj.ERPDAO.get_kitchen_Gajeon_Category_List"

            );
        return kitchen_gajeon_category_list;
	}

	@Override
	public List<Map<String, String>> get_Life_Gajeon_Category_List() {
		List<Map<String,String>> life_gajeon_category_list = this.sqlSession.selectList(

                "com.daybreak.prj.ERPDAO.get_Life_Gajeon_Category_List"

            );
        return life_gajeon_category_list;
	}
	
	//TV 종류 카테고리 가져오는 메소드
	@Override
	public List<Map<String, String>> get_TV_Category_List() {
		List<Map<String,String>> tV_category_list = this.sqlSession.selectList(

                "com.daybreak.prj.ERPDAO.get_TV_Category_List"

            );
        return tV_category_list;
	}
	
	// PC 종류 가져오는 메소드
	@Override
	public List<Map<String, String>> get_PC_Category_List() {
		List<Map<String,String>> pc_category_list = this.sqlSession.selectList(

                "com.daybreak.prj.ERPDAO.get_PC_Category_List"

            );
        return pc_category_list;
	}

	@Override
	public List<Map<String, String>> get_Gaming_PC_Category_List() {
		List<Map<String,String>> gaming_pc_category_list = this.sqlSession.selectList(

                "com.daybreak.prj.ERPDAO.get_Gaming_PC_Category_List"

            );
        return gaming_pc_category_list;
	}

	@Override
	public List<Map<String, String>> get_Office_PC_Category_List() {
		List<Map<String,String>> office_pc_category_list = this.sqlSession.selectList(

                "com.daybreak.prj.ERPDAO.get_Office_PC_Category_List"

            );
        return office_pc_category_list;
	}

	// Mobile 종류 가져오는 메소드
	@Override
	public List<Map<String, String>> get_Mobile_Category_List() {
		List<Map<String,String>> mobile_category_list = this.sqlSession.selectList(

                "com.daybreak.prj.ERPDAO.get_Mobile_Category_List"

            );
        return mobile_category_list;
	}

	@Override
	public List<Map<String, String>> get_Phone_Category_List() {
		List<Map<String,String>> phone_category_list = this.sqlSession.selectList(

                "com.daybreak.prj.ERPDAO.get_Phone_Category_List"

            );
        return phone_category_list;
	}

	@Override
	public List<Map<String, String>> get_Tablet_Category_List() {
		List<Map<String,String>> tablet_category_list = this.sqlSession.selectList(

                "com.daybreak.prj.ERPDAO.get_Tablet_Category_List"

            );
        return tablet_category_list;
	}
	//=================================================











    //============================================================================================================================================
	// 검색화면에서 뿌려지는 각종 리스트들 나머지, 전부,   
    // 각 세부 및 색상 브랜드 카테고리 리스트 담아서 다 가져옴. 
	//=======================================================
	


	//=================================================
	// 에너지 소비 등급 가져오기
	@Override
	public List<Map<String, String>> get_Energy_Grade_List() {
		List<Map<String,String>> energy_grade_list = this.sqlSession.selectList(

                "com.daybreak.prj.ERPDAO.get_Energy_Grade_List"

            );
        return energy_grade_list;
	}
	
	// 여기서부터는 각 카테로리별 브랜드와 컬러를 가져오는 메소드
	@Override
	public List<Map<String, String>> get_Brand_List(ERPSearchDTO erpSearchDTO) {
		List<Map<String,String>> brand_list = this.sqlSession.selectList(

                "com.daybreak.prj.ERPDAO.get_Brand_List"
				,erpSearchDTO

            );
        return brand_list;
	}

	@Override
	public List<Map<String, String>> get_Color_List(ERPSearchDTO erpSearchDTO) {
		List<Map<String,String>> color_list = this.sqlSession.selectList(

                "com.daybreak.prj.ERPDAO.get_Color_List"
				,erpSearchDTO

            );
        return color_list;
	}

//==================================================================================================================================
//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM







//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
    // =====================================================================
    //입출고 입력
	public int getInsertStockCnt(ERPStockDTO erpStockDTO) {
        System.out.println( "ERPDAO.getInsertStockCnt 시작" );
		
		int updateItemCnt = this.sqlSession.update(
	            //-----------------------------------------------
	            "com.daybreak.prj.ERPDAO.insertStock"
	            //-----------------------------------------------
	            ,erpStockDTO
	    );                       

        System.out.println( "ERPDAO.getInsertStockCnt 종료" );
	    return updateItemCnt;
	}
    // =====================================================================
//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM









//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// 통계  ----
//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
    //======================================================================
	// ▼ 10월23일 각 대분류 카테고리별 총수량 및 소분류 '1'(에어컨)의 총수량 개수▼ 
    // =====================================================================
    // 가전 카테고리 총수량
    // =====================================================================
    public int G_Category_AllCnt(){
        //-------------------------------------------------------
        // 
        //-------------------------------------------------------
        int g_item_Cnt = this.sqlSession.selectOne(
                "com.daybreak.prj.ERPDAO.G_Category_AllCnt"  // 실행할 SQL 구문의 위치 지정
                						     // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return g_item_Cnt;
    }


    // =====================================================================
    // TV 카테고리 총수량(전체통계쪽)
    // =====================================================================
    public int T_Category_AllCnt(){
        //-------------------------------------------------------
        // 
        //-------------------------------------------------------
        int t_item_Cnt = this.sqlSession.selectOne(
                "com.daybreak.prj.ERPDAO.T_Category_AllCnt"  // 실행할 SQL 구문의 위치 지정
                						     // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return t_item_Cnt;
    }

    
    // =====================================================================
    // PC 카테고리 총수량(전체통계쪽)
    // =====================================================================
    public int P_Category_AllCnt(){
        //-------------------------------------------------------
        // 
        //-------------------------------------------------------
        int p_item_Cnt = this.sqlSession.selectOne(
                "com.daybreak.prj.ERPDAO.P_Category_AllCnt"  // 실행할 SQL 구문의 위치 지정
                						     // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return p_item_Cnt;
    }

    
    // =====================================================================
    // 모바일 카테고리 총수량(전체통계쪽)
    // =====================================================================
    public int M_Category_AllCnt(){
        //-------------------------------------------------------
        // 
        //-------------------------------------------------------
        int m_item_Cnt = this.sqlSession.selectOne(
                "com.daybreak.prj.ERPDAO.M_Category_AllCnt"  // 실행할 SQL 구문의 위치 지정
                						     // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return m_item_Cnt;
    }





// ▲ 10월23일 각 대분류 카테고리별 총수량 및 소분류 '1'(에어컨)의 총수량 개수 <끝>▲



  //=================================================================================================================
  //=================================================================================================================
  //=================================================================================================================
    //-------------------------------
    // 10월 24일
    // 가전 소품목 색상 BEST10 LIST 담는 메소드 선언.
    //-------------------------------
    public List<Map<String, String>> G_Sub_Sub_Color_Best_ten_AllList(ERPDTO erpDTO) {
		List<Map<String,String>> g_sub_sub_color_best_ten_alllist = this.sqlSession.selectList(

                "com.daybreak.prj.ERPDAO.G_Sub_Sub_Best_ten_AllList"		

            );
        return g_sub_sub_color_best_ten_alllist;
	}

    public List<Map<String, String>> T_Sub_Sub_Color_Best_ten_AllList(ERPDTO erpDTO) {
		List<Map<String,String>> t_sub_sub_color_best_ten_alllist = this.sqlSession.selectList(

                "com.daybreak.prj.ERPDAO.T_Sub_Sub_Best_ten_AllList"

            );
        return t_sub_sub_color_best_ten_alllist;
	}
    //-----------------
    // 가전 소품목 색상 BEST10 LIST 담는 메소드 선언.
    //-----------------
    public List<Map<String, String>> P_Sub_Sub_Color_Best_ten_AllList(ERPDTO erpDTO) {
    	
		List<Map<String,String>> p_sub_sub_color_best_ten_alllist = this.sqlSession.selectList(

                "com.daybreak.prj.ERPDAO.P_Sub_Sub_Best_ten_AllList"

            );
        return p_sub_sub_color_best_ten_alllist;
	}
    //-----------------
    // 가전 소품목 색상 BEST10 LIST 담는 메소드 선언.
    //-----------------
    public List<Map<String, String>> M_Sub_Sub_Color_Best_ten_AllList(ERPDTO erpDTO) {
		List<Map<String,String>> m_sub_sub_color_best_ten_alllist = this.sqlSession.selectList(

                "com.daybreak.prj.ERPDAO.M_Sub_Sub_Best_ten_AllList"

            );
        return m_sub_sub_color_best_ten_alllist;
	}

//=================================================================================================================
//================================================10월 25일(월) 통계부분===========================================
//=================================================================================================================
  //MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
    // =====================================================================
    // 2019년 가전 입고 수량
    // =====================================================================
    public int G_year_2019_CNT(){
        //-------------------------------------------------------
        // 
        //-------------------------------------------------------
        int g_year_2019_CNT = this.sqlSession.selectOne(
                "com.daybreak.prj.ERPDAO.G_year_2019_CNT"  // 실행할 SQL 구문의 위치 지정
                						     // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return g_year_2019_CNT;
    }


    // =====================================================================
    // 2020년 가전 입고 수량
    // =====================================================================
    public int G_year_2020_CNT(){
        //-------------------------------------------------------
        // 
        //-------------------------------------------------------
        int g_year_2020_CNT = this.sqlSession.selectOne(
                "com.daybreak.prj.ERPDAO.G_year_2020_CNT"  // 실행할 SQL 구문의 위치 지정
                						     // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return g_year_2020_CNT;
    }
    
    // =====================================================================
    // 2021년 가전 입고 수량
    // =====================================================================
    public int G_year_2021_CNT(){
        //-------------------------------------------------------
        // 
        //-------------------------------------------------------
        int g_year_2021_CNT = this.sqlSession.selectOne(
                "com.daybreak.prj.ERPDAO.G_year_2021_CNT"  // 실행할 SQL 구문의 위치 지정
                						     // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return g_year_2021_CNT;
    }

    // =====================================================================
    // 2019년 pc 입고 수량
    // =====================================================================
    public int P_year_2019_CNT(){
        //-------------------------------------------------------
        // 
        //-------------------------------------------------------
        int p_year_2019_CNT = this.sqlSession.selectOne(
                "com.daybreak.prj.ERPDAO.P_year_2019_CNT"  // 실행할 SQL 구문의 위치 지정
                						     // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return p_year_2019_CNT;
    }

    // =====================================================================
    // 2020년 pc 입고 수량
    // =====================================================================
    public int P_year_2020_CNT(){
        //-------------------------------------------------------
        // 
        //-------------------------------------------------------
        int p_year_2020_CNT = this.sqlSession.selectOne(
                "com.daybreak.prj.ERPDAO.P_year_2020_CNT"  // 실행할 SQL 구문의 위치 지정
                						     // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return p_year_2020_CNT;
    }
    
    // =====================================================================
    // 2021년 pc 입고 수량
    // =====================================================================
    public int P_year_2021_CNT(){
        //-------------------------------------------------------
        // 
        //-------------------------------------------------------
        int p_year_2021_CNT = this.sqlSession.selectOne(
                "com.daybreak.prj.ERPDAO.P_year_2021_CNT"  // 실행할 SQL 구문의 위치 지정
                						     // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return p_year_2021_CNT;
    }

	// =====================================================================
    // 2019년 모바일 입고 수량
    // =====================================================================
    public int M_year_2019_CNT(){
        //-------------------------------------------------------
        // 
        //-------------------------------------------------------
        int m_year_2019_CNT = this.sqlSession.selectOne(
                "com.daybreak.prj.ERPDAO.M_year_2019_CNT"  // 실행할 SQL 구문의 위치 지정
                						     // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return m_year_2019_CNT;
    }

    // =====================================================================
    // 2020년 모바일 입고 수량
    // =====================================================================
    public int M_year_2020_CNT(){
        //-------------------------------------------------------
        // 
        //-------------------------------------------------------
        int m_year_2020_CNT = this.sqlSession.selectOne(
                "com.daybreak.prj.ERPDAO.M_year_2020_CNT"  // 실행할 SQL 구문의 위치 지정
                						     // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return m_year_2020_CNT;
    }
    
    // =====================================================================
    // 2021년 모바일 입고 수량
    // =====================================================================
    public int M_year_2021_CNT(){
        //-------------------------------------------------------
        // 
        //-------------------------------------------------------
        int m_year_2021_CNT = this.sqlSession.selectOne(
                "com.daybreak.prj.ERPDAO.M_year_2021_CNT"  // 실행할 SQL 구문의 위치 지정
                						     // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return m_year_2021_CNT;
    }

	// =====================================================================
    // 2019년 tv 입고 수량
    // =====================================================================
    public int T_year_2019_CNT(){
        //-------------------------------------------------------
        // 
        //-------------------------------------------------------
        int t_year_2019_CNT = this.sqlSession.selectOne(
                "com.daybreak.prj.ERPDAO.T_year_2019_CNT"  // 실행할 SQL 구문의 위치 지정
                						     // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return t_year_2019_CNT;
    }

    // =====================================================================
    // 2020년 tv 입고 수량
    // =====================================================================
    public int T_year_2020_CNT(){
        //-------------------------------------------------------
        // 
        //-------------------------------------------------------
        int t_year_2020_CNT = this.sqlSession.selectOne(
                "com.daybreak.prj.ERPDAO.T_year_2020_CNT"  // 실행할 SQL 구문의 위치 지정
                						     // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return t_year_2020_CNT;
    }
    
    // =====================================================================
    // 2021년 tv 입고 수량
    // =====================================================================
    public int T_year_2021_CNT(){
        //-------------------------------------------------------
        // 
        //-------------------------------------------------------
        int t_year_2021_CNT = this.sqlSession.selectOne(
                "com.daybreak.prj.ERPDAO.T_year_2021_CNT"  // 실행할 SQL 구문의 위치 지정
                						     // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return t_year_2021_CNT;
    }

    //MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
    // =====================================================================
    // 가전 소분류별 각각의 총수량 TEST (세부통계쪽)
    // =====================================================================
    public int G_SubSub_Each_AllCnt(){
        //-------------------------------------------------------
        // 
        //-------------------------------------------------------
        int g_subsub_eachcnt = this.sqlSession.selectOne(
                "com.daybreak.prj.ERPDAO.G_Sub_Sub_Each_Cnt"  // 실행할 SQL 구문의 위치 지정
                						     // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return g_subsub_eachcnt;
    }
    
// ▲ 10월23일 가전 제품 카테고리별 총수량 및 소분류 '1'(에어컨)의 총수량 개수 <끝>▲


    public int G_SubSub_Each_AllCnt_2(){
        //-------------------------------------------------------
        // 
        //-------------------------------------------------------
        int g_subsub_eachcnt_2 = this.sqlSession.selectOne(
                "com.daybreak.prj.ERPDAO.G_Sub_Sub_Each_Cnt_2"  // 실행할 SQL 구문의 위치 지정
                						     // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return g_subsub_eachcnt_2;
    }
    
// ▲ 10월23일 가전 제품 카테고리별 총수량 및 소분류 '2'(공기청정)의 총수량 개수 <끝>▲
  
    
    public int G_SubSub_Each_AllCnt_3(){
        //-------------------------------------------------------
        // 
        //-------------------------------------------------------
        int g_subsub_eachcnt_3 = this.sqlSession.selectOne(
                "com.daybreak.prj.ERPDAO.G_Sub_Sub_Each_Cnt_3"  // 실행할 SQL 구문의 위치 지정
                						     // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return g_subsub_eachcnt_3;
    }
    
// ▲ 10월23일 가전 제품 카테고리별 총수량 및 소분류 '3'(난방기기)의 총수량 개수 <끝>▲
    
    
    public int G_SubSub_Each_AllCnt_4(){
        //-------------------------------------------------------
        // 
        //-------------------------------------------------------
        int g_subsub_eachcnt_4 = this.sqlSession.selectOne(
                "com.daybreak.prj.ERPDAO.G_Sub_Sub_Each_Cnt_4"  // 실행할 SQL 구문의 위치 지정
                						     // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return g_subsub_eachcnt_4;
    }
    
// ▲ 10월23일 가전 제품 카테고리별 총수량 및 소분류 '4'(냉장고)의 총수량 개수 <끝>▲
    
    
    public int G_SubSub_Each_AllCnt_5(){
        //-------------------------------------------------------
        // 
        //-------------------------------------------------------
        int g_subsub_eachcnt_5 = this.sqlSession.selectOne(
                "com.daybreak.prj.ERPDAO.G_Sub_Sub_Each_Cnt_5"  // 실행할 SQL 구문의 위치 지정
                						     // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return g_subsub_eachcnt_5;
    }
    
// ▲ 10월23일 가전 제품 카테고리별 총수량 및 소분류 '5'(전기밥솥)의 총수량 개수 <끝>▲
    
    
    public int G_SubSub_Each_AllCnt_6(){
        //-------------------------------------------------------
        // 
        //-------------------------------------------------------
        int g_subsub_eachcnt_6 = this.sqlSession.selectOne(
                "com.daybreak.prj.ERPDAO.G_Sub_Sub_Each_Cnt_6"  // 실행할 SQL 구문의 위치 지정
                						     // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return g_subsub_eachcnt_6;
    }
    
// ▲ 10월23일 가전 제품 카테고리별 총수량 및 소분류 '6'(에어프라이어)의 총수량 개수 <끝>▲
    
    
    public int G_SubSub_Each_AllCnt_7(){
        //-------------------------------------------------------
        // 
        //-------------------------------------------------------
        int g_subsub_eachcnt_7 = this.sqlSession.selectOne(
                "com.daybreak.prj.ERPDAO.G_Sub_Sub_Each_Cnt_7"  // 실행할 SQL 구문의 위치 지정
                						     // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return g_subsub_eachcnt_7;
    }
    
// ▲ 10월23일 가전 제품 카테고리별 총수량 및 소분류 '7'(세탁기)의 총수량 개수 <끝>▲
    
    
    public int G_SubSub_Each_AllCnt_8(){
        //-------------------------------------------------------
        // 
        //-------------------------------------------------------
        int g_subsub_eachcnt_8 = this.sqlSession.selectOne(
                "com.daybreak.prj.ERPDAO.G_Sub_Sub_Each_Cnt_8"  // 실행할 SQL 구문의 위치 지정
                						     // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return g_subsub_eachcnt_8;
    }
    
// ▲ 10월23일 가전 제품 카테고리별 총수량 및 소분류 '8'(건조기)의 총수량 개수 <끝>▲
    
    
    public int G_SubSub_Each_AllCnt_9(){
        //-------------------------------------------------------
        // 
        //-------------------------------------------------------
        int g_subsub_eachcnt_9 = this.sqlSession.selectOne(
                "com.daybreak.prj.ERPDAO.G_Sub_Sub_Each_Cnt_9"  // 실행할 SQL 구문의 위치 지정
                						     // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return g_subsub_eachcnt_9;
    }
    
// ▲ 10월23일 가전 제품 카테고리별 총수량 및 소분류 '9'(청소기)의 총수량 개수 <끝>▲
    

       
    // =====================================================================
    // TV 소분류별 각각의 총수량 TEST (세부통계쪽)
    // =====================================================================
    public int T_SubSub_Each_AllCnt(){
        //-------------------------------------------------------
        // 
        //-------------------------------------------------------
        int t_subsub_eachcnt = this.sqlSession.selectOne(
                "com.daybreak.prj.ERPDAO.T_Sub_Sub_Each_Cnt"  // 실행할 SQL 구문의 위치 지정
                						     // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return t_subsub_eachcnt;
    }
    
// ▲ 10월23일 TV 카테고리별 총수량 및 소분류 '1'(QLED)의 총수량 개수 <끝>▲
    
    

    public int T_SubSub_Each_AllCnt_2(){
        //-------------------------------------------------------
        // 
        //-------------------------------------------------------
        int t_subsub_eachcnt_2 = this.sqlSession.selectOne(
                "com.daybreak.prj.ERPDAO.T_Sub_Sub_Each_Cnt_2"  // 실행할 SQL 구문의 위치 지정
                						     // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return t_subsub_eachcnt_2;
    }
    
// ▲ 10월23일 TV 카테고리별 총수량 및 소분류 '2'(mini_LED)의 총수량 개수 <끝>▲
    
    
    
    public int T_SubSub_Each_AllCnt_3(){
        //-------------------------------------------------------
        // 
        //-------------------------------------------------------
        int t_subsub_eachcnt_3 = this.sqlSession.selectOne(
                "com.daybreak.prj.ERPDAO.T_Sub_Sub_Each_Cnt_3"  // 실행할 SQL 구문의 위치 지정
                						     // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return t_subsub_eachcnt_3;
    }
    
// ▲ 10월23일 TV 카테고리별 총수량 및 소분류 '2'(mini_LED)의 총수량 개수 <끝>▲
    
    
    
    // =====================================================================
    // PC 소분류별 각각의 총수량 TEST (세부통계쪽)
    // =====================================================================
    public int P_SubSub_Each_AllCnt(){
        //-------------------------------------------------------
        // 
        //-------------------------------------------------------
        int p_subsub_eachcnt = this.sqlSession.selectOne(
                "com.daybreak.prj.ERPDAO.P_Sub_Sub_Each_Cnt"  // 실행할 SQL 구문의 위치 지정
                						     // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return p_subsub_eachcnt;
    }
    
// ▲ 10월23일 PC 카테고리별 총수량 및 소분류 '1'(사무용_인강용)의 총수량 개수 <끝>▲
    
    
    
    public int P_SubSub_Each_AllCnt_2(){
        //-------------------------------------------------------
        // 
        //-------------------------------------------------------
        int p_subsub_eachcnt_2 = this.sqlSession.selectOne(
                "com.daybreak.prj.ERPDAO.P_Sub_Sub_Each_Cnt_2"  // 실행할 SQL 구문의 위치 지정
                						     // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return p_subsub_eachcnt_2;
    }
    
// ▲ 10월23일 PC 카테고리별 총수량 및 소분류 '2'(게이밍)의 총수량 개수 <끝>▲
    
    
    
    public int P_SubSub_Each_AllCnt_3(){
        //-------------------------------------------------------
        // 
        //-------------------------------------------------------
        int p_subsub_eachcnt_3 = this.sqlSession.selectOne(
                "com.daybreak.prj.ERPDAO.P_Sub_Sub_Each_Cnt_3"  // 실행할 SQL 구문의 위치 지정
                						     // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return p_subsub_eachcnt_3;
    }
    
// ▲ 10월23일 PC 카테고리별 총수량 및 소분류 '3'(비지니스)의 총수량 개수 <끝>▲
    
    
    
    public int P_SubSub_Each_AllCnt_4(){
        //-------------------------------------------------------
        // 
        //-------------------------------------------------------
        int p_subsub_eachcnt_4 = this.sqlSession.selectOne(
                "com.daybreak.prj.ERPDAO.P_Sub_Sub_Each_Cnt_4"  // 실행할 SQL 구문의 위치 지정
                						     // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return p_subsub_eachcnt_4;
    }
    
// ▲ 10월23일 PC 카테고리별 총수량 및 소분류 '4'(게이밍노트북)의 총수량 개수 <끝>▲
    
    
    
    // =====================================================================
    // 모바일 소분류별 각각의 총수량 TEST (세부통계쪽)
    // =====================================================================
    public int M_SubSub_Each_AllCnt(){
        //-------------------------------------------------------
        // 
        //-------------------------------------------------------
        int m_subsub_eachcnt = this.sqlSession.selectOne(
                "com.daybreak.prj.ERPDAO.M_Sub_Sub_Each_Cnt"  // 실행할 SQL 구문의 위치 지정
                						     // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return m_subsub_eachcnt;
    }
    
// ▲ 10월23일 모바일 카테고리별 총수량 및 소분류 '1'(삼성전자)의 총수량 개수 <끝>▲
    
    
    
    public int M_SubSub_Each_AllCnt_2(){
        //-------------------------------------------------------
        // 
        //-------------------------------------------------------
        int m_subsub_eachcnt_2 = this.sqlSession.selectOne(
                "com.daybreak.prj.ERPDAO.M_Sub_Sub_Each_Cnt_2"  // 실행할 SQL 구문의 위치 지정
                						     // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return m_subsub_eachcnt_2;
    }
    
// ▲ 10월23일 모바일 카테고리별 총수량 및 소분류 '1'(삼성전자)의 총수량 개수 <끝>▲
    
    
    
    public int M_SubSub_Each_AllCnt_3(){
        //-------------------------------------------------------
        // 
        //-------------------------------------------------------
        int m_subsub_eachcnt_3 = this.sqlSession.selectOne(
                "com.daybreak.prj.ERPDAO.M_Sub_Sub_Each_Cnt_3"  // 실행할 SQL 구문의 위치 지정
                						     // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return m_subsub_eachcnt_3;
    }
    
// ▲ 10월23일 모바일 카테고리별 총수량 및 소분류 '1'(삼성전자)의 총수량 개수 <끝>▲
    
    
    
    public int M_SubSub_Each_AllCnt_4(){
        //-------------------------------------------------------
        // 
        //-------------------------------------------------------
        int m_subsub_eachcnt_4 = this.sqlSession.selectOne(
                "com.daybreak.prj.ERPDAO.M_Sub_Sub_Each_Cnt_4"  // 실행할 SQL 구문의 위치 지정
                						     // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return m_subsub_eachcnt_4;
    }
    
// ▲ 10월23일 모바일 카테고리별 총수량 및 소분류 '1'(삼성전자)의 총수량 개수 <끝>▲
    
    
    
    public int M_SubSub_Each_AllCnt_5(){
        //-------------------------------------------------------
        // 
        //-------------------------------------------------------
        int m_subsub_eachcnt_5 = this.sqlSession.selectOne(
                "com.daybreak.prj.ERPDAO.M_Sub_Sub_Each_Cnt_5"  // 실행할 SQL 구문의 위치 지정
                						     // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return m_subsub_eachcnt_5;
    }
    
// ▲ 10월23일 모바일 카테고리별 총수량 및 소분류 '1'(삼성전자)의 총수량 개수 <끝>▲
    
    
    
    public int M_SubSub_Each_AllCnt_6(){
        //-------------------------------------------------------
        // 
        //-------------------------------------------------------
        int m_subsub_eachcnt_6 = this.sqlSession.selectOne(
                "com.daybreak.prj.ERPDAO.M_Sub_Sub_Each_Cnt_6"  // 실행할 SQL 구문의 위치 지정
                						     // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return m_subsub_eachcnt_6;
    }
    
    // ▲ 10월23일 모바일 카테고리별 총수량 및 소분류 '1'(삼성전자)의 총수량 개수 <끝>▲
  //MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
   
    // ▼ 가전 선호 브랜드 best 5 총수량<끝>
    public List<Map<String,String>> G_SubSub_Best_Brand(ERPDTO erpDTO){
        //-------------------------------------------------------
        // 
        //-------------------------------------------------------
    	List<Map<String,String>>  g_subsub_brand_best = this.sqlSession.selectList(
                "com.daybreak.prj.ERPDAO.G_Sub_Sub_Best_brand_1"  // 실행할 SQL 구문의 위치 지정
                						     // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return g_subsub_brand_best;
    }
    
    
    // ▼ TV 선호 브랜드 best 5 총수량<끝>
    public List<Map<String,String>> T_SubSub_Best_Brand(ERPDTO erpDTO){
        //-------------------------------------------------------
        // 
        //-------------------------------------------------------
    	List<Map<String,String>>  t_subsub_brand_best = this.sqlSession.selectList(
                "com.daybreak.prj.ERPDAO.T_Sub_Sub_Best_brand_1"  // 실행할 SQL 구문의 위치 지정
                						     // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return t_subsub_brand_best;
    }
    
    
 // ▼ PC 선호 브랜드 best 5 총수량<끝>
    public List<Map<String,String>> P_SubSub_Best_Brand(ERPDTO erpDTO){
        //-------------------------------------------------------
        // 
        //-------------------------------------------------------
    	List<Map<String,String>>  p_subsub_brand_best = this.sqlSession.selectList(
                "com.daybreak.prj.ERPDAO.P_Sub_Sub_Best_brand_1"  // 실행할 SQL 구문의 위치 지정
                						     // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return p_subsub_brand_best;
    }
    
    
 // ▼ 모바일 선호 브랜드 best 5 총수량<끝>
    public List<Map<String,String>> M_SubSub_Best_Brand(ERPDTO erpDTO){
        //-------------------------------------------------------
        // 
        //-------------------------------------------------------
    	List<Map<String,String>>  m_subsub_brand_best = this.sqlSession.selectList(
                "com.daybreak.prj.ERPDAO.M_Sub_Sub_Best_brand_1"  // 실행할 SQL 구문의 위치 지정
                						     // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return m_subsub_brand_best;
    }    
    
//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM






//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
    // 게시판 요약 부분.
    //  아래 메인페이지 재고요약 부분에 전부 포함되어 주석 처리 함.


    
    //메인에 표기할 주간 게시판 얻는 메소드
	// public List<Map<String,String>> getWeeklyBoard(ERPSearchDTO erpSearchDTO){
    //     System.out.println( "ERPDAO.getWeeklyBoard 시작" );		
		
	// 	List<Map<String,String>> weeklyBoardList = this.sqlSession.selectList(
	// 			"com.daybreak.prj.ERPDAO.getWeekBoard"
	// 			,erpSearchDTO
	// 	);
		
		
    //     System.out.println( "ERPDAO.getWeeklyBoard 종료" );	       
    //     return weeklyBoardList;
	// }


	//재고요약 1번 - 카테고리별 가장 출고량이 많은 품목
	// public List<Map<String,String>> getBestItemByCategory(ERPSearchDTO erpSearchDTO){
    //     System.out.println( "ERPDAO.getBestItemByCategory 시작" );
        
	// 	List<Map<String,String>> bestItemByCategoryList = this.sqlSession.selectList(
	// 			"com.daybreak.prj.ERPDAO.getCategoryBestItem"
	// 			,erpSearchDTO
	// 	);
        
		
    //     System.out.println( "ERPDAO.getBestItemByCategory 종료" );		
    //     return bestItemByCategoryList;		
	// }
//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM


//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// insert all 로 input output 디폴트 수량 0 isert 해주기.
    public int stock_in_out_insert_all(ERPDTO erpDTO) {
        int stock_in_out_insert_all_cnt = this.sqlSession.insert(

                "com.daybreak.prj.ERPDAO.stock_in_out_insert_all"
                ,erpDTO

            );
        return stock_in_out_insert_all_cnt;
    } 
//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM










//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// 메인 재고요약 순환 부분.  
    //메인 홈 최다 조회수 게시판 얻는 메소드
	public List<Map<String,String>> getHomeBoardList(ERPHomeDTO erpHomeDTO){
        System.out.println( "ERPDAO.getHomeBoardList 시작" );
        
		List<Map<String,String>> homeBoardList = this.sqlSession.selectList(
				"com.daybreak.prj.ERPDAO.getHomeBoard"
				,erpHomeDTO
		);
        
		
        System.out.println( "ERPDAO.getHomeBoardList 종료" );		
        return homeBoardList;	
		
	}

    //메인 홈 재고요약 1번 검색하는 메소드
	public List<Map<String,String>> getHomeSummarybtnOneList(ERPHomeDTO erpHomeDTO){
        System.out.println( "ERPDAO.getHomeSummarybtnOneList 시작" );
        
		List<Map<String,String>> homeSummarybtnOneList = this.sqlSession.selectList(
				"com.daybreak.prj.ERPDAO.getHomeSummarybtnOneList"
				,erpHomeDTO
		);
        
		
        System.out.println( "ERPDAO.getHomeSummarybtnOneList 종료" );		
        return homeSummarybtnOneList;	

	}
	
	//메인 홈 재고요약 2번 검색하는 메소드
	public List<Map<String,String>> getHomeSummarybtnTwoList(ERPHomeDTO erpHomeDTO){
        System.out.println( "ERPDAO.getHomeSummarybtnTwoList 시작" );
        
		List<Map<String,String>> homeSummarybtnTwoList = this.sqlSession.selectList(
				"com.daybreak.prj.ERPDAO.getHomeSummarybtnTwoList"
				,erpHomeDTO
		);
        
		
        System.out.println( "ERPDAO.getHomeSummarybtnTwoList 종료" );		
        return homeSummarybtnTwoList;	
				
	}

	//메인 홈 재고요약 3번 검색하는 메소드
	public List<Map<String,String>> getHomeSummarybtnThreeList(ERPHomeDTO erpHomeDTO){
        System.out.println( "ERPDAO.getHomeSummarybtnThreeList 시작" );
        
		List<Map<String,String>> homeSummarybtnThreeList = this.sqlSession.selectList(
				"com.daybreak.prj.ERPDAO.getHomeSummarybtnThreeList"
				,erpHomeDTO
		);
        
		
        System.out.println( "ERPDAO.getHomeSummarybtnThreeList 종료" );		
        return homeSummarybtnThreeList;	
        
	}

	//메인 홈 재고요약 4번 검색하는 메소드
	public List<Map<String,String>> getHomeSummarybtnFourList(ERPHomeDTO erpHomeDTO){
        System.out.println( "ERPDAO.getHomeSummarybtnFourList 시작" );
        
		List<Map<String,String>> homeSummarybtnFourList = this.sqlSession.selectList(
				"com.daybreak.prj.ERPDAO.getHomeSummarybtnFourList"
				,erpHomeDTO
		);
        
		
        System.out.println( "ERPDAO.getHomeSummarybtnFourList 종료" );		
        return homeSummarybtnFourList;	
        
	}
//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM







































    

    // ===================================================================================
    // 게시판 DAOImpl 참고용 주석. 삭제하지마시고, 그냥 코드들 참고하시고 위에 코딩 해주세요.
    // ===================================================================================
/*
    // ******************************************************
    // [게시판 글 입력 후 입력 적용 행의 개수]를 리턴하는 메소드 선언
    // ******************************************************
    public int insertBoard(BoardDTO boardDTO){
        // ----------------------------------------------
        // SqlSessionTemplate 객체의 insert 메소드 호출로
        // 게시판 글 입력 SQL 구문을 실행하고 입력 성공 행의 개수 얻기.
        // ----------------------------------------------
        int boardRegCnt = sqlSession.insert(
            // ----------------------------------------------
            // 실행할 SQL 구문의 위치를 지정하기.
            // 실행할 SQL 구문의 위치 문자열 패턴은 아래와 같다.
            // xml 파일 중에 "mapper태그의namespace명.mapper태그내부의호출할SQL구문소유한태그id값"
            // ----------------------------------------------
            "com.daybreak.prj.BoardDAO.insertBoard"  
            // ----------------------------------------------
            // 호출할 SQL 구문에서 사용할 데이터 지정하기
            // ----------------------------------------------
            ,boardDTO                             
        );
        System.out.println("BoardDAOImpl. sqlSession.insert() 메서드 수행완료\r");
        return boardRegCnt;
    }

    // ******************************************************
    // [검색한 게시판 목록] 리턴하는 메소드 선언
    // ******************************************************
    public List<Map<String,String>>getBoardList( BoardSearchDTO boardSearchDTO){
        List<Map<String,String>> boardList = this.sqlSession.selectList(

            "com.daybreak.prj.BoardDAO.getBoardList"  // 실행할 SQL 구문의 위치 지정  
            , boardSearchDTO                       // 실행할 SQL 구문에서 사용할 데이터 지정

        );
        System.out.println("BoardDAOImpl 게시판 목록 List 값 확인 =>" + boardList);
        return boardList;
    }

    // ******************************************************
    // 게시판 이미지 이름가져오는 메소드 선언
    // ******************************************************
    public String getPic(BoardDTO boardDTO){
        
        String pic = this.sqlSession.selectOne(

            "com.daybreak.prj.BoardDAO.getPic"  // 실행할 SQL 구문의 위치 지정  
            , boardDTO                       // 실행할 SQL 구문에서 사용할 데이터 지정

        );
        return pic;
    }

    // ******************************************************
    // [1개 게시판 글 정보] 리턴하는 메소드 선언
    // ******************************************************
    public BoardDTO getBoard(int b_no){

        // -------------------------------------------
        // [SqlSessionTemplate 객체]의 selectOne(~,~) 를 호출하여 [1개 게시판 글 정보] 얻기
        // selectOne 은 1행 m열의 select 결과를 얻을 때 사용하는 메소드이다.  
        // -------------------------------------------
        BoardDTO board = this.sqlSession.selectOne(
            //-----------------------------------------------
            // 실행할 SQL 구문의 위치를 지정하기.
            // 실행할 SQL 구문의 위치 문자열 패턴은 아래와 같다.
            // xml 파일 중에 "mapper태그의namespace명.mapper태그내부의호출할SQL구문소유한태그id값"
            //-----------------------------------------------
            "com.daybreak.prj.BoardDAO.getBoard"	// 실행할 SQL 구문의 위치 지정
            //-----------------------------------------------
            // 실행할 SQL구문에서 사용할 데이터 지정하기
            //-----------------------------------------------
            ,b_no								// 실행할 SQL 구문에서 사용할 데이터 지정
        );                       
        // -------------------------------------------
        // [1개 게시판 글 정보] 리턴하기
        // -------------------------------------------
        return board;
    }

    // ******************************************************
    // [게시판 글 조회수 증가하고 수정행의 개수] 리턴하는 메소드 선언
    // ******************************************************
    public int updateReadcount(int b_no) {
        // ------------------------------------------------------------
        // [SqlSessionTemplate 객체]의 update(~,~) 를 호출하여 [조회수 증가]하기
        // ------------------------------------------------------------
        int updateCnt = this.sqlSession.update(
            
            "com.daybreak.prj.BoardDAO.updateReadcount" // 실행할 SQL 구문의 위치 지정
            ,b_no                                    // 실행할 SQL 구문에서 사용할 데이터 지정

        );
        return updateCnt;
    }

    // ******************************************************
    // [게시판 글 수정행의 개수] 리턴하는 메소드 선언
    // ******************************************************
    public int updateChange(int b_no) {
        // ------------------------------------------------------------
        // [SqlSessionTemplate 객체]의 update(~,~) 를 호출하여 [조회수 증가]하기
        // ------------------------------------------------------------
        int updateChange = this.sqlSession.update(
            
            "com.daybreak.prj.BoardDAO.updateChange" // 실행할 SQL 구문의 위치 지정
            ,b_no                                 // 실행할 SQL 구문에서 사용할 데이터 지정

        );
        return updateChange;
    }

    // ******************************************************
    // 삭제/수정할 게시판의 존재 개수를 리턴하는 메소드 선언
    // ******************************************************
    public int getBoardCnt(BoardDTO boardDTO){
        // --------------------------------------------------------
        // [SqlSessionTemplate 객체]의 selectOne(~,~) 를 호출하여 [게시판의 존재 개수] 얻기
        // --------------------------------------------------------
        int boardCnt = this.sqlSession.selectOne(
            "com.daybreak.prj.BoardDAO.getBoardCnt"   // 실행할 SQL 구문의 위치 지정
            ,boardDTO                              // 실행할 SQL 구문에서 사용할 데이터 지정
    
        );
        return boardCnt;
    }

    // ******************************************************
    // 삭제/수정할 게시판의 비밀번호 존재 개수를 리턴하는 메소드 선언
    // ******************************************************
    public int getPwdCnt(BoardDTO boardDTO){
        // --------------------------------------------------------
        // [SqlSessionTemplate 객체]의 selectOne(~,~) 를 호출하여 [비밀번호 존재 개수] 얻기
        // --------------------------------------------------------
        int pwdCnt = this.sqlSession.selectOne(
            "com.daybreak.prj.BoardDAO.getPwdCnt"   // 실행할 SQL 구문의 위치 지정
            ,boardDTO                            // 실행할 SQL 구문에서 사용할 데이터 지정
    
        );
        return pwdCnt;
    }

    // ******************************************************
    // 게시판 수정 후 수정행의 적용 개수를 리턴하는 메소드 선언
    // ******************************************************
    public int updateBoard(BoardDTO boardDTO){
        //-------------------------------------------------------
        // [SqlSessionTemplate 객체]의 update(~,~) 를 호출하여 [게시판 수정]하기
        //-------------------------------------------------------
        int updateCnt = this.sqlSession.update(
                "com.daybreak.prj.BoardDAO.updateBoard"  // 실행할 SQL 구문의 위치 지정
                ,boardDTO							  // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return updateCnt;
    }

    // ******************************************************
    // 삭제할 게시판의 자식글 존재 개수를 리턴하는 메소드 선언
    // ******************************************************
    public int getChildrenCnt(BoardDTO boardDTO){
        //-------------------------------------------------------
        // [SqlSessionTemplate 객체]의 update(~,~) 를 호출하여 [자식글 존재 개수] 얻기
        //-------------------------------------------------------
        int childrenCnt = this.sqlSession.selectOne(
                "com.daybreak.prj.BoardDAO.getChildrenCnt"  // 실행할 SQL 구문의 위치 지정
                ,boardDTO							     // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return childrenCnt;
    }

    // ******************************************************
    // 삭제될 게시판 이후 글의 출력 순서번호를 1씩 감소 시킨 후 수정 적용행의 개수를 리턴하는 메소드 선언
    // ******************************************************
    public int downPrintNo(BoardDTO boardDTO){
        //-------------------------------------------------------
        // [SqlSessionTemplate 객체]의 update(~,~) 를 호출하여 
        // [삭제될 게시판 이후 글의 출력순서번호를 1씩 감소]하고 감소된 행의 개수 얻기
        //-------------------------------------------------------
        int downPrintNoCnt = this.sqlSession.update(
                "com.daybreak.prj.BoardDAO.downPrintNo"  // 실행할 SQL 구문의 위치 지정
                ,boardDTO							  // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return downPrintNoCnt;
    }

    // ******************************************************
    // 게시판 삭제 명령한 후 삭제 적용행의 개수를 리턴하는 메소드 선언
    // ******************************************************
    public int deleteBoard(BoardDTO boardDTO){
        //-------------------------------------------------------
        // [SqlSessionTemplate 객체]의 update(~,~) 를 호출하여 
        // [게시판 삭제 명령]한 후 삭제 적용행의 개수 얻기
        //-------------------------------------------------------
        int deleteBoardCnt = this.sqlSession.delete(
                "com.daybreak.prj.BoardDAO.deleteBoard"  // 실행할 SQL 구문의 위치 지정
                ,boardDTO							  // 실행할 SQL 구문에서 사용할 데이터 지정
        );
        return deleteBoardCnt;
    }

    // ******************************************************
    // [게시판 글 출력번호 1증가하고 수정 행의 개수] 리턴하는 메소드 선언
    // ******************************************************
    public int updatePrintNo(BoardDTO boardDTO){
        System.out.println("BoardDAOImpl updatePrintNo 메서드 호출 ");
        //-------------------------------------------------------
        // [SqlSessionTemplate 객체]의 update(~,~) 를 호출하여 
        // [게시판 글 출력번호 1증가하고 수정 행의 개수] 얻기
        //-------------------------------------------------------
        int updatePrintNoCnt = sqlSession.update(
           
            "com.daybreak.prj.BoardDAO.updatePrintNo"  // 실행할 SQL 구문의 위치 지정
            ,boardDTO							    // 실행할 SQL 구문에서 사용할 데이터 지정
    
        );
        //-------------------------------------------------------
        // [수정 행의 개수] 리턴하기
        //-------------------------------------------------------
        return updatePrintNoCnt;
    }

    // ******************************************************
    // [검색한 게시판 목록 개수] 리턴하는 메소드 선언
    // ******************************************************
    public int getBoardListCount(BoardSearchDTO boardSearchDTO){
        // -------------------------------------------
        // [SqlSessionTemplate 객체]의 selectOne(~,~) 를 호출하여 [1개 게시판 글 정보] 얻기
        // selectOne 은 1행 m열의 select 결과를 얻을 때 사용하는 메소드이다.  
        // -------------------------------------------
        int getBoardListCount = this.sqlSession.selectOne(
            //-----------------------------------------------
            // 실행할 SQL 구문의 위치를 지정하기.
            // 실행할 SQL 구문의 위치 문자열 패턴은 아래와 같다.
            // xml 파일 중에 "mapper태그의namespace명.mapper태그내부의호출할SQL구문소유한태그id값"
            //-----------------------------------------------
            "com.daybreak.prj.BoardDAO.getBoardListCount"	// 실행할 SQL 구문의 위치 지정
            //-----------------------------------------------
            // 실행할 SQL구문에서 사용할 데이터 지정하기
            //-----------------------------------------------
            , boardSearchDTO
        );                       
        // -------------------------------------------
        // [1개 게시판 글 정보] 리턴하기
        // -------------------------------------------
        System.out.println("BoardDAOImpl 게시판 목록 검색개수 확인 =>" + getBoardListCount);
        return getBoardListCount;
    }
*/   
    
}
