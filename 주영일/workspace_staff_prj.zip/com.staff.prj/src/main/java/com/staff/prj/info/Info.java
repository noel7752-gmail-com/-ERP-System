package com.staff.prj.info;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;


//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// 유틸 관련 메소드를 가진 클래스 선언
//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM

public class Info {
	public static String staffPath = "staff/";
}
