package com.daybreak.prj.Controller;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.constraints.Null;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.daybreak.prj.DAO.ERPDAO;
import com.daybreak.prj.DTO.ERPDTO;
import com.daybreak.prj.DTO.ERPHomeDTO;
import com.daybreak.prj.DTO.ERPSearchDTO;
import com.daybreak.prj.DTO.ERPStockDTO;
import com.daybreak.prj.Service.ERPService;
import com.daybreak.prj.Util.Util;

@Controller
public class ERPController {
	
	@Autowired
	private ERPDAO erpDAO;
	@Autowired
	private ERPService erpService;	
	
	// 메인화면 접속
    @RequestMapping(value = "/daybreak.do")
    public ModelAndView daybreak(
        ERPSearchDTO erpSearchDTO
    ) {

        ModelAndView mav = new ModelAndView();


        // 지도에 수량 찍어주려고 테스트
    	int searchListAllCnt = this.erpDAO.getSearchAllCnt(erpSearchDTO);


        mav.setViewName("daybreak.jsp");


        // 지도에 수량 찍어주려고 테스트
        mav.addObject("searchListAllCnt",searchListAllCnt);




        // =====================================================================================================
        // 메인페이지 재고요약 순환 부분
        //주간 조회수 높은 게시물 보이기
        ERPHomeDTO erpHomeDTO = new ERPHomeDTO();
        erpHomeDTO.setHomeBoardDaySelect("14");
        List<Map<String, String>> homeBoardList = this.erpDAO.getHomeBoardList(erpHomeDTO);
        mav.addObject("homeBoardList",homeBoardList );
        System.out.println( "첫 접속 homeBoardDaySelect => " + erpHomeDTO.getHomeBoardDaySelect() );
        System.out.println(homeBoardList);

        //재고요약 1번 - 카테고리별 가장 출고량이 많은 품목
        erpHomeDTO.setHomeSummarybtnOneSelect("365");
        List<Map<String, String>> homeSummarybtnOneList = this.erpDAO.getHomeSummarybtnOneList(erpHomeDTO);
        mav.addObject("homeSummarybtnOneList",homeSummarybtnOneList );
        
        //재고요약 2번 - 카테고리별 가장 출고량이 많은 소카테고리
        erpHomeDTO.setHomeSummarybtnTwoSelect("365");
        List<Map<String, String>> homeSummarybtnTwoList = this.erpDAO.getHomeSummarybtnTwoList(erpHomeDTO);
        mav.addObject("homeSummarybtnTwoList",homeSummarybtnTwoList);
        
        //재고요약 3번 - 카테고리별 가장 입고량이 많은 제품
        erpHomeDTO.setHomeSummarybtnThreeSelect("365");
        List<Map<String, String>> homeSummarybtnThreeList = this.erpDAO.getHomeSummarybtnThreeList(erpHomeDTO);
        mav.addObject("homeSummarybtnThreeList",homeSummarybtnThreeList);
        
        //재고요약 4번 - 최다 잔고 제품
        erpHomeDTO.setHomeSummarybtnThreeSelect("365");
        List<Map<String, String>> homeSummarybtnFourList = this.erpDAO.getHomeSummarybtnFourList(erpHomeDTO);
        mav.addObject("homeSummarybtnFourList",homeSummarybtnFourList);        
        // =====================================================================================================


        return mav;
    }


    // 통합검색 접속.
    @RequestMapping( value="/searchAll.do" )
    public ModelAndView goSearchAll( 
    		ERPSearchDTO erpSearchDTO
            
    ){
        System.out.println("searchAll.do 접속 확인 >>>>>>");
    	//검색결과의 제품수를 가져오는 메소드실행후 변수에 담음
    	int searchListAllCnt = this.erpDAO.getSearchAllCnt(erpSearchDTO);
    	
    	// 페이징 처리 메소드 결과물을 변수에 담음
    	Map<String,Integer> map = Util.getPagingNos(searchListAllCnt, erpSearchDTO.getSelectPageNo(), erpSearchDTO.getRowCntPerPage(), 10);
    	erpSearchDTO.setSelectPageNo(map.get("selectPageNo"));
    	
    	// DB연동해 가져온 검색리스트
    	List<Map<String,String>> searchALLList = this.erpDAO.getSearcALLhList(erpSearchDTO);


        // 검색화면에서 뿌려지는 각종 리스트들
        List<Map<String,String>> category_list = this.erpDAO.get_Category_List();
    	List<Map<String,String>> gajeon_category_list = this.erpDAO.get_Gajeon_Category_List();
    	List<Map<String,String>> season_gajeon_category_list = this.erpDAO.get_Season_Gajeon_Category_List();
    	List<Map<String,String>> kitchen_gajeon_category_list = this.erpDAO.get_kitchen_Gajeon_Category_List();
    	List<Map<String,String>> life_gajeon_category_list = this.erpDAO.get_Life_Gajeon_Category_List();
    	List<Map<String,String>> tv_category_list = this.erpDAO.get_TV_Category_List();
    	List<Map<String,String>> pc_category_list = this.erpDAO.get_PC_Category_List();
    	List<Map<String,String>> gaming_pc_category_list = this.erpDAO.get_Gaming_PC_Category_List();
    	List<Map<String,String>> office_pc_category_list = this.erpDAO.get_Office_PC_Category_List();
    	List<Map<String,String>> mobile_category_list = this.erpDAO.get_Mobile_Category_List();
    	List<Map<String,String>> phone_category_list = this.erpDAO.get_Phone_Category_List();
    	List<Map<String,String>> tablet_category_list = this.erpDAO.get_Tablet_Category_List();

    	

        //=================================================================================================================================================
        // 검색화면에서 뿌려지는 각종 리스트들 나머지, 전부,   
        // 각 세부 및 색상 브랜드 카테고리 리스트 담아서 다 가져옴. 
    	List<Map<String,String>> energy_grade_list = this.erpDAO.get_Energy_Grade_List();
    	

    	List<Map<String,String>> g_brand_list = this.erpDAO.get_G_Brand_List();
    	List<Map<String,String>> g_color_list = this.erpDAO.get_G_Color_List();
    	

    	List<Map<String,String>> g_season_color_list = this.erpDAO.get_G_Season_Color_List();
    	List<Map<String,String>> g_season_brand_list = this.erpDAO.get_G_Season_Brand_List();
    	List<Map<String,String>> g_season_aircon_color_list = this.erpDAO.get_G_Season_Aircon_Color_List();
    	List<Map<String,String>> g_season_aircon_brand_list = this.erpDAO.get_G_Season_Aircon_Brand_List();
    	List<Map<String,String>> g_season_airfresh_brand_list = this.erpDAO.get_G_Season_Airfresh_Brand_List();
    	List<Map<String,String>> g_season_airfresh_color_list = this.erpDAO.get_G_Season_Airfresh_Color_List();
    	List<Map<String,String>> g_season_hitter_brand_list = this.erpDAO.get_G_Season_Hitter_Brand_List();
    	List<Map<String,String>> g_season_hitter_color_list = this.erpDAO.get_G_Season_Hitter_Color_List();
    	List<Map<String,String>> g_season_aircon_airfrash_color_list = this.erpDAO.get_G_Season_Aircon_Airfresh_Color_List();
    	List<Map<String,String>> g_season_aircon_airfrash_brand_list = this.erpDAO.get_G_Season_Aircon_Airfresh_Brand_List();
    	List<Map<String,String>> g_season_aircon_hitter_color_list = this.erpDAO.get_G_Season_Aircon_Hitter_Color_List();
    	List<Map<String,String>> g_season_aircon_hitter_brand_list = this.erpDAO.get_G_Season_Aircon_Hitter_Brand_List();
    	List<Map<String,String>> g_season_airfresh_hitter_color_list = this.erpDAO.get_G_Season_Airfresh_Hitter_Color_List();
    	List<Map<String,String>> g_season_airfresh_hitter_brand_list = this.erpDAO.get_G_Season_Airfresh_Hitter_Brand_List();
    	

    	List<Map<String,String>> g_kitchen_color_list = this.erpDAO.get_G_Kitchen_Color_List();
    	List<Map<String,String>> g_kitchen_brand_list = this.erpDAO.get_G_Kitchen_Brand_List();
    	List<Map<String,String>> g_kitchen_fridge_color_list = this.erpDAO.get_G_Kitchen_Fridge_Color_List();
    	List<Map<String,String>> g_kitchen_fridge_brand_list = this.erpDAO.get_G_Kitchen_Fridge_Brand_List();
    	List<Map<String,String>> g_kitchen_cooker_color_list = this.erpDAO.get_G_Kitchen_Cooker_Color_List();
    	List<Map<String,String>> g_kitchen_cooker_brand_list = this.erpDAO.get_G_Kitchen_Cooker_Brand_List();
    	List<Map<String,String>> g_kitchen_airfryer_color_list = this.erpDAO.get_G_Kitchen_Airfryer_Color_List();
    	List<Map<String,String>> g_kitchen_airfryer_brand_list = this.erpDAO.get_G_Kitchen_Airfryer_Brand_List();
    	List<Map<String,String>> g_kitchen_fridge_cooker_color_list = this.erpDAO.get_G_Kitchen_Fridge_Cooker_Color_List();
    	List<Map<String,String>> g_kitchen_fridge_cooker_brand_list = this.erpDAO.get_G_Kitchen_Fridge_Cooker_Brand_List();
    	List<Map<String,String>> g_kitchen_fridge_airfryer_color_list = this.erpDAO.get_G_Kitchen_Fridge_Airfryer_Color_List();
    	List<Map<String,String>> g_kitchen_fridge_airfryer_brand_list = this.erpDAO.get_G_Kitchen_Fridge_Airfryer_Brand_List();
    	List<Map<String,String>> g_kitchen_cooker_airfryer_color_list = this.erpDAO.get_G_Kitchen_Cooker_Airfryer_Color_List();
    	List<Map<String,String>> g_kitchen_cooker_airfryer_brand_list = this.erpDAO.get_G_Kitchen_Cooker_Airfryer_Brand_List();
    	
    	
    	List<Map<String,String>> g_life_color_list = this.erpDAO.get_G_Life_Color_List();
    	List<Map<String,String>> g_life_brand_list = this.erpDAO.get_G_Life_Brand_List();
    	List<Map<String,String>> g_life_washer_color_list = this.erpDAO.get_G_Life_Washer_Color_List();
    	List<Map<String,String>> g_life_washer_brand_list = this.erpDAO.get_G_Life_Washer_Brand_List();
    	List<Map<String,String>> g_life_dryer_color_list = this.erpDAO.get_G_Life_Dryer_Color_List();
    	List<Map<String,String>> g_life_dryer_brand_list = this.erpDAO.get_G_Life_Dryer_Brand_List();
    	List<Map<String,String>> g_life_cleaner_color_list = this.erpDAO.get_G_Life_Cleaner_Color_List();
    	List<Map<String,String>> g_life_cleaner_brand_list = this.erpDAO.get_G_Life_Cleaner_Brand_List();
    	List<Map<String,String>> g_life_washer_dryer_color_list = this.erpDAO.get_G_Life_Washer_Dryer_Color_List();
    	List<Map<String,String>> g_life_washer_dryer_brand_list = this.erpDAO.get_G_Life_Washer_Dryer_Brand_List();
    	List<Map<String,String>> g_life_washer_cleaner_color_list = this.erpDAO.get_G_Life_Washer_Cleaner_Color_List();
    	List<Map<String,String>> g_life_washer_cleaner_brand_list = this.erpDAO.get_G_Life_Washer_Cleaner_Brand_List();
    	List<Map<String,String>> g_life_dryer_cleaner_color_list = this.erpDAO.get_G_Life_Dryer_Cleaner_Color_List();
    	List<Map<String,String>> g_life_dryer_cleaner_brand_list = this.erpDAO.get_G_Life_Dryer_Cleaner_Brand_List();
    	
    	
    	
    	
    	
    	
    	List<Map<String,String>> t_brand_list = this.erpDAO.get_T_Brand_List();
    	List<Map<String,String>> t_color_list = this.erpDAO.get_T_Color_List();
    	List<Map<String,String>> t_qled_brand_list = this.erpDAO.get_T_QLED_Brand_List();
    	List<Map<String,String>> t_qled_color_list = this.erpDAO.get_T_QLED_Color_List();
    	List<Map<String,String>> t_miniled_brand_list = this.erpDAO.get_T_MINILED_Brand_List();
    	List<Map<String,String>> t_miniled_color_list = this.erpDAO.get_T_MINILED_Color_List();
    	List<Map<String,String>> t_oled_brand_list = this.erpDAO.get_T_OLED_Brand_List();
    	List<Map<String,String>> t_oled_color_list = this.erpDAO.get_T_OLED_Color_List();
    	
    	
    	List<Map<String,String>> p_brand_list = this.erpDAO.get_P_Brand_List();
    	List<Map<String,String>> p_color_list = this.erpDAO.get_P_Color_List();	
    	List<Map<String,String>> p_desktop_brand_list = this.erpDAO.get_P_Desktop_Brand_List();
    	List<Map<String,String>> p_desktop_color_list = this.erpDAO.get_P_Desktop_Color_List();
    	List<Map<String,String>> p_notebook_brand_list = this.erpDAO.get_P_Notebook_Brand_List();
    	List<Map<String,String>> p_notebook_color_list = this.erpDAO.get_P_Notebook_Color_List();
    	List<Map<String,String>> p_desktop_office_brand_list = this.erpDAO.get_P_Desktop_Office_Brand_List();
    	List<Map<String,String>> p_desktop_office_color_list = this.erpDAO.get_P_Desktop_Office_Color_List();
    	List<Map<String,String>> p_desktop_gaming_brand_list = this.erpDAO.get_P_Desktop_Gaming_Brand_List();
    	List<Map<String,String>> p_desktop_gaming_color_list = this.erpDAO.get_P_Desktop_Gaming_Color_List();
    	List<Map<String,String>> p_notebook_business_brand_list = this.erpDAO.get_P_Notebook_Business_Brand_List();
    	List<Map<String,String>> p_notebook_business_color_list = this.erpDAO.get_P_Notebook_Business_Color_List();
    	List<Map<String,String>> p_notebook_gaming_brand_list = this.erpDAO.get_P_Notebook_Gaming_Brand_List();
    	List<Map<String,String>> p_notebook_gaming_color_list = this.erpDAO.get_P_Notebook_Gaming_Color_List();
    	
    	
    	List<Map<String,String>> m_brand_list = this.erpDAO.get_M_Brand_List();
    	List<Map<String,String>> m_color_list = this.erpDAO.get_M_Color_List();   
    	List<Map<String,String>> m_phone_brand_list = this.erpDAO.get_M_Phone_Brand_List();
    	List<Map<String,String>> m_phone_color_list = this.erpDAO.get_M_Phone_Color_List();
    	List<Map<String,String>> m_tablet_brand_list = this.erpDAO.get_M_Tablet_Brand_List();
    	List<Map<String,String>> m_tablet_color_list = this.erpDAO.get_M_Tablet_Color_List();
    	List<Map<String,String>> m_phone_samsung_brand_list = this.erpDAO.get_M_Phone_Samsung_Brand_List();
    	List<Map<String,String>> m_phone_samsung_color_list = this.erpDAO.get_M_Phone_Samsung_Color_List();
    	List<Map<String,String>> m_phone_apple_brand_list = this.erpDAO.get_M_Phone_Apple_Brand_List();
    	List<Map<String,String>> m_phone_apple_color_list = this.erpDAO.get_M_Phone_Apple_Color_List();
    	List<Map<String,String>> m_phone_other_brand_list = this.erpDAO.get_M_Phone_Other_Brand_List();
    	List<Map<String,String>> m_phone_other_color_list = this.erpDAO.get_M_Phone_Other_Color_List();
    	List<Map<String,String>> m_phone_samsung_apple_brand_list = this.erpDAO.get_M_Phone_Samsung_Apple_Brand_List();
    	List<Map<String,String>> m_phone_samsung_apple_color_list = this.erpDAO.get_M_Phone_Samsung_Apple_Color_List();
    	List<Map<String,String>> m_phone_samsung_other_brand_list = this.erpDAO.get_M_Phone_Samsung_Other_Brand_List();
    	List<Map<String,String>> m_phone_samsung_other_color_list = this.erpDAO.get_M_Phone_Samsung_Other_Color_List();
    	List<Map<String,String>> m_phone_apple_other_brand_list = this.erpDAO.get_M_Phone_Apple_Other_Brand_List();
    	List<Map<String,String>> m_phone_apple_other_color_list = this.erpDAO.get_M_Phone_Apple_Other_Color_List();
    	List<Map<String,String>> m_tablet_android_brand_list = this.erpDAO.get_M_Tablet_Android_Brand_List();
    	List<Map<String,String>> m_tablet_android_color_list = this.erpDAO.get_M_Tablet_Android_Color_List();
    	List<Map<String,String>> m_tablet_windows_brand_list = this.erpDAO.get_M_Tablet_Windows_Brand_List();
    	List<Map<String,String>> m_tablet_windows_color_list = this.erpDAO.get_M_Tablet_Windows_Color_List();
    	List<Map<String,String>> m_tablet_ipad_brand_list = this.erpDAO.get_M_Tablet_Ipad_Brand_List();
    	List<Map<String,String>> m_tablet_ipad_color_list = this.erpDAO.get_M_Tablet_Ipad_Color_List();
    	List<Map<String,String>> m_tablet_android_windows_brand_list = this.erpDAO.get_M_Tablet_Android_Windows_Brand_List();
    	List<Map<String,String>> m_tablet_android_windows_color_list = this.erpDAO.get_M_Tablet_Android_Windows_Color_List();
    	List<Map<String,String>> m_tablet_android_ipad_brand_list = this.erpDAO.get_M_Tablet_Android_Ipad_Brand_List();
    	List<Map<String,String>> m_tablet_android_ipad_color_list = this.erpDAO.get_M_Tablet_Android_Ipad_Color_List();
    	List<Map<String,String>> m_tablet_windows_ipad_brand_list = this.erpDAO.get_M_Tablet_Windows_Ipad_Brand_List();
    	List<Map<String,String>> m_tablet_windows_ipad_color_list = this.erpDAO.get_M_Tablet_Windows_Ipad_Color_List();
        //=================================================================================================================================================








    	
        //*******************************************
        // [ModelAndView 객체] 생성하기
        // [ModelAndView 객체]에 [호출 JSP 페이지명]을 저장하기
        //*******************************************
        ModelAndView mav = new ModelAndView( );
        mav.setViewName("allSearch.jsp");
        // mav.addObject("boardDTO", boardDTO);
        mav.addObject("searchListAllCnt",searchListAllCnt);
        mav.addObject("searchALLList",searchALLList);
        mav.addObject("pagingNos",map);



        // 검색화면에서 뿌려지는 각종 리스트들
        mav.addObject("category_list",category_list);
        mav.addObject("gajeon_category_list",gajeon_category_list);
        mav.addObject("season_gajeon_category_list",season_gajeon_category_list);
        mav.addObject("kitchen_gajeon_category_list",kitchen_gajeon_category_list);
        mav.addObject("life_gajeon_category_list",life_gajeon_category_list);
        mav.addObject("tv_category_list",tv_category_list);
        mav.addObject("pc_category_list",pc_category_list);
        mav.addObject("gaming_pc_category_list",gaming_pc_category_list);
        mav.addObject("office_pc_category_list",office_pc_category_list);
        mav.addObject("mobile_category_list",mobile_category_list);
        mav.addObject("phone_category_list",phone_category_list);
        mav.addObject("tablet_category_list",tablet_category_list);


        //================================================================================================================================================
        // 검색화면에서 뿌려지는 각종 리스트들 나머지, 전부,   
        // 각 세부 및 색상 브랜드 카테고리 리스트 담아서 다 가져온걸 addObject 함.
        mav.addObject("energy_grade_list",energy_grade_list);
        mav.addObject("g_brand_list",g_brand_list);
        mav.addObject("g_color_list",g_color_list);
        
        
        mav.addObject("g_season_color_list",g_season_color_list);
        mav.addObject("g_season_brand_list",g_season_brand_list);
        
        mav.addObject("g_season_aircon_color_list",g_season_aircon_color_list);
        mav.addObject("g_season_aircon_brand_list",g_season_aircon_brand_list);
        mav.addObject("g_season_airfresh_brand_list",g_season_airfresh_brand_list);
        mav.addObject("g_season_airfresh_color_list",g_season_airfresh_color_list);
        mav.addObject("g_season_hitter_brand_list",g_season_hitter_brand_list);
        mav.addObject("g_season_hitter_color_list",g_season_hitter_color_list);
        mav.addObject("g_season_aircon_airfrash_color_list",g_season_aircon_airfrash_color_list);
        mav.addObject("g_season_aircon_airfrash_brand_list",g_season_aircon_airfrash_brand_list);
        mav.addObject("g_season_aircon_hitter_color_list",g_season_aircon_hitter_color_list);
        mav.addObject("g_season_aircon_hitter_brand_list",g_season_aircon_hitter_brand_list);
        mav.addObject("g_season_airfresh_hitter_color_list",g_season_airfresh_hitter_color_list);
        mav.addObject("g_season_airfresh_hitter_brand_list",g_season_airfresh_hitter_brand_list);
        
        
        mav.addObject("g_kitchen_color_list",g_kitchen_color_list);
        mav.addObject("g_kitchen_brand_list",g_kitchen_brand_list);
        
        mav.addObject("g_kitchen_fridge_color_list",g_kitchen_fridge_color_list);
        mav.addObject("g_kitchen_fridge_brand_list",g_kitchen_fridge_brand_list);
        mav.addObject("g_kitchen_cooker_color_list",g_kitchen_cooker_color_list);
        mav.addObject("g_kitchen_cooker_brand_list",g_kitchen_cooker_brand_list);
        mav.addObject("g_kitchen_airfryer_color_list",g_kitchen_airfryer_color_list);
        mav.addObject("g_kitchen_airfryer_brand_list",g_kitchen_airfryer_brand_list);
        
        mav.addObject("g_kitchen_fridge_cooker_color_list",g_kitchen_fridge_cooker_color_list);
        mav.addObject("g_kitchen_fridge_cooker_brand_list",g_kitchen_fridge_cooker_brand_list);
        mav.addObject("g_kitchen_fridge_airfryer_color_list",g_kitchen_fridge_airfryer_color_list);
        mav.addObject("g_kitchen_fridge_airfryer_brand_list",g_kitchen_fridge_airfryer_brand_list);
        mav.addObject("g_kitchen_cooker_airfryer_color_list",g_kitchen_cooker_airfryer_color_list);
        mav.addObject("g_kitchen_cooker_airfryer_brand_list",g_kitchen_cooker_airfryer_brand_list);
 
        
        mav.addObject("g_life_color_list",g_life_color_list);
        mav.addObject("g_life_brand_list",g_life_brand_list);
        mav.addObject("g_life_washer_color_list",g_life_washer_color_list);
        mav.addObject("g_life_washer_brand_list",g_life_washer_brand_list);
        mav.addObject("g_life_dryer_color_list",g_life_dryer_color_list);
        mav.addObject("g_life_dryer_brand_list",g_life_dryer_brand_list);
        mav.addObject("g_life_cleaner_color_list",g_life_cleaner_color_list);
        mav.addObject("g_life_cleaner_brand_list",g_life_cleaner_brand_list);
        mav.addObject("g_life_washer_dryer_color_list",g_life_washer_dryer_color_list);
        mav.addObject("g_life_washer_dryer_brand_list",g_life_washer_dryer_brand_list);
        mav.addObject("g_life_washer_cleaner_color_list",g_life_washer_cleaner_color_list);
        mav.addObject("g_life_washer_cleaner_brand_list",g_life_washer_cleaner_brand_list);
        mav.addObject("g_life_dryer_cleaner_color_list",g_life_dryer_cleaner_color_list);
        mav.addObject("g_life_dryer_cleaner_brand_list",g_life_dryer_cleaner_brand_list);
        
        
        
        
        mav.addObject("t_brand_list",t_brand_list);
        mav.addObject("t_color_list",t_color_list);
        mav.addObject("t_qled_brand_list",t_qled_brand_list);
        mav.addObject("t_qled_color_list",t_qled_color_list);
        mav.addObject("t_miniled_brand_list",t_miniled_brand_list);
        mav.addObject("t_miniled_color_list",t_miniled_color_list); 
        mav.addObject("t_oled_brand_list",t_oled_brand_list);
        mav.addObject("t_oled_color_list",t_oled_color_list); 
        
        
        mav.addObject("p_brand_list",p_brand_list);
        mav.addObject("p_color_list",p_color_list);
        mav.addObject("p_desktop_brand_list",p_desktop_brand_list);
        mav.addObject("p_desktop_color_list",p_desktop_color_list);
        mav.addObject("p_notebook_brand_list",p_notebook_brand_list);
        mav.addObject("p_notebook_color_list",p_notebook_color_list);
        mav.addObject("p_desktop_office_brand_list",p_desktop_office_brand_list);
        mav.addObject("p_desktop_office_color_list",p_desktop_office_color_list);
        mav.addObject("p_desktop_gaming_brand_list",p_desktop_gaming_brand_list);
        mav.addObject("p_desktop_gaming_color_list",p_desktop_gaming_color_list);
        mav.addObject("p_notebook_business_brand_list",p_notebook_business_brand_list);
        mav.addObject("p_notebook_business_color_list",p_notebook_business_color_list);
        mav.addObject("p_notebook_gaming_brand_list",p_notebook_gaming_brand_list);
        mav.addObject("p_notebook_gaming_color_list",p_notebook_gaming_color_list);
        
        
        mav.addObject("m_brand_list",m_brand_list);
        mav.addObject("m_color_list",m_color_list);  
        mav.addObject("m_phone_brand_list",m_phone_brand_list);
        mav.addObject("m_phone_color_list",m_phone_color_list); 
        mav.addObject("m_tablet_brand_list",m_tablet_brand_list);
        mav.addObject("m_tablet_color_list",m_tablet_color_list); 
        mav.addObject("m_phone_samsung_brand_list",m_phone_samsung_brand_list);
        mav.addObject("m_phone_samsung_color_list",m_phone_samsung_color_list); 
        mav.addObject("m_phone_apple_brand_list",m_phone_apple_brand_list);
        mav.addObject("m_phone_apple_color_list",m_phone_apple_color_list);
        mav.addObject("m_phone_other_brand_list",m_phone_other_brand_list);
        mav.addObject("m_phone_other_color_list",m_phone_other_color_list); 
        mav.addObject("m_phone_samsung_apple_brand_list",m_phone_samsung_apple_brand_list);
        mav.addObject("m_phone_samsung_apple_color_list",m_phone_samsung_apple_color_list); 
        mav.addObject("m_phone_samsung_other_brand_list",m_phone_samsung_other_brand_list);
        mav.addObject("m_phone_samsung_other_color_list",m_phone_samsung_other_color_list); 
        mav.addObject("m_phone_apple_other_brand_list",m_phone_apple_other_brand_list);
        mav.addObject("m_phone_apple_other_color_list",m_phone_apple_other_color_list); 
        mav.addObject("m_tablet_android_brand_list",m_tablet_android_brand_list);
        mav.addObject("m_tablet_android_color_list",m_tablet_android_color_list);
        mav.addObject("m_tablet_windows_brand_list",m_tablet_windows_brand_list);
        mav.addObject("m_tablet_windows_color_list",m_tablet_windows_color_list);
        mav.addObject("m_tablet_ipad_brand_list",m_tablet_ipad_brand_list);
        mav.addObject("m_tablet_ipad_color_list",m_tablet_ipad_color_list);
        mav.addObject("m_tablet_android_windows_brand_list",m_tablet_android_windows_brand_list);
        mav.addObject("m_tablet_android_windows_color_list",m_tablet_android_windows_color_list);
        mav.addObject("m_tablet_android_ipad_brand_list",m_tablet_android_ipad_brand_list);
        mav.addObject("m_tablet_android_ipad_color_list",m_tablet_android_ipad_color_list);
        mav.addObject("m_tablet_windows_ipad_brand_list",m_tablet_windows_ipad_brand_list);
        mav.addObject("m_tablet_windows_ipad_color_list",m_tablet_windows_ipad_color_list);
        //================================================================================================================================================





        //*******************************************
        // [ModelAndView 객체] 리턴하기
        //*******************************************
        return mav;
    }
    // ==============================================================================
    // 재고관리 - 가전검색페이지 
    // 가전검색페이지 접속.
    @RequestMapping( value="/searchgajeon.do" )
    public ModelAndView goSearchGajeon( 
    		ERPSearchDTO erpSearchDTO
            
    ){
    	//검색결과의 제품수를 가져오는 메소드실행후 변수에 담음
    	int search_g_list_cnt = this.erpDAO.getSearch_G_List_Cnt(erpSearchDTO);
    	
    	// 페이징 처리 메소드 결과물을 변수에 담음
    	Map<String,Integer> map = Util.getPagingNos(search_g_list_cnt, erpSearchDTO.getSelectPageNo(), erpSearchDTO.getRowCntPerPage(), 10);
    	erpSearchDTO.setSelectPageNo(map.get("selectPageNo"));
    	
    	// DB연동해 가져온 검색리스트
    	List<Map<String,String>> g_searchList = this.erpDAO.getSearch_G_List(erpSearchDTO);
    	System.out.println(g_searchList);
    	System.out.println(search_g_list_cnt);
        //*******************************************
        // [ModelAndView 객체] 생성하기
        // [ModelAndView 객체]에 [호출 JSP 페이지명]을 저장하기
        //*******************************************
        ModelAndView mav = new ModelAndView( );
        mav.setViewName("g_search.jsp");
        // mav.addObject("boardDTO", boardDTO);
        mav.addObject("search_g_list_cnt",search_g_list_cnt);
        mav.addObject("g_searchList",g_searchList);
        mav.addObject("pagingNos",map);


        //*******************************************
        // [ModelAndView 객체] 리턴하기
        //*******************************************
        return mav;
    }  
    
    
    
    // 티비 검색페이지 접속.
    @RequestMapping( value="/searchtv.do" )
    public ModelAndView goSearchTV( 
    		ERPSearchDTO erpSearchDTO
            
    ){
    	//검색결과의 제품수를 가져오는 메소드실행후 변수에 담음
    	int search_t_list_cnt = this.erpDAO.getSearch_T_List_Cnt(erpSearchDTO);
    	
    	// 페이징 처리 메소드 결과물을 변수에 담음
    	Map<String,Integer> map = Util.getPagingNos(search_t_list_cnt, erpSearchDTO.getSelectPageNo(), erpSearchDTO.getRowCntPerPage(), 10);
    	erpSearchDTO.setSelectPageNo(map.get("selectPageNo"));
    	
    	// DB연동해 가져온 검색리스트
    	List<Map<String,String>> t_searchList = this.erpDAO.getSearch_T_List(erpSearchDTO);
    	System.out.println("searchtv.do 리스트 ==>>> "+t_searchList.get(0));
    	
        //*******************************************
        // [ModelAndView 객체] 생성하기
        // [ModelAndView 객체]에 [호출 JSP 페이지명]을 저장하기
        //*******************************************
        ModelAndView mav = new ModelAndView( );
        mav.setViewName("t_search.jsp");
        // mav.addObject("boardDTO", boardDTO);
        mav.addObject("search_t_list_cnt",search_t_list_cnt);
        mav.addObject("t_searchList",t_searchList);
        mav.addObject("pagingNos",map);


        //*******************************************
        // [ModelAndView 객체] 리턴하기
        //*******************************************
        return mav;
    }
    
    
    
    // PC검색페이지 접속.
    @RequestMapping( value="/searchpc.do" )
    public ModelAndView goSearchPC( 
    		ERPSearchDTO erpSearchDTO
            
    ){
    	//검색결과의 제품수를 가져오는 메소드실행후 변수에 담음
    	int search_p_list_cnt = this.erpDAO.getSearch_P_List_Cnt(erpSearchDTO);
    	
    	// 페이징 처리 메소드 결과물을 변수에 담음
    	Map<String,Integer> map = Util.getPagingNos(search_p_list_cnt, erpSearchDTO.getSelectPageNo(), erpSearchDTO.getRowCntPerPage(), 10);
    	erpSearchDTO.setSelectPageNo(map.get("selectPageNo"));
    	System.out.println("map 안에 들었는것 확인 min_pageNo 리스트 ==>>> "+map.get("min_pageNo"));
    	System.out.println("map 안에 들었는것 확인 max_pageNo 리스트 ==>>> "+map.get("max_pageNo"));
    	System.out.println("map 안에 들었는것 확인 search_p_list_cnt 리스트 ==>>> "+search_p_list_cnt);
    	

    	// DB연동해 가져온 검색리스트
    	List<Map<String,String>> p_searchList = this.erpDAO.getSearch_P_List(erpSearchDTO);
    	System.out.println("searchpc.do 리스트 ==>>> "+p_searchList.get(0));
    	
    	
        //*******************************************
        // [ModelAndView 객체] 생성하기
        // [ModelAndView 객체]에 [호출 JSP 페이지명]을 저장하기
        //*******************************************
        ModelAndView mav = new ModelAndView( );
        mav.setViewName("p_search.jsp");
        // mav.addObject("boardDTO", boardDTO);
        mav.addObject("search_p_list_cnt",search_p_list_cnt);
        mav.addObject("p_searchList",p_searchList);
        mav.addObject("pagingNos",map);


        //*******************************************
        // [ModelAndView 객체] 리턴하기
        //*******************************************
        return mav;
    }
    
    
    
    // 모바일검색페이지 접속.
    @RequestMapping( value="/searchmobile.do" )
    public ModelAndView goSearchMobile( 
    		ERPSearchDTO erpSearchDTO
            
    ){
    	//검색결과의 제품수를 가져오는 메소드실행후 변수에 담음
    	int search_m_list_cnt = this.erpDAO.getSearch_M_List_Cnt(erpSearchDTO);
    	
    	// 페이징 처리 메소드 결과물을 변수에 담음
    	Map<String,Integer> map = Util.getPagingNos(search_m_list_cnt, erpSearchDTO.getSelectPageNo(), erpSearchDTO.getRowCntPerPage(), 10);
    	erpSearchDTO.setSelectPageNo(map.get("selectPageNo"));
    	
    	// DB연동해 가져온 검색리스트
    	List<Map<String,String>> m_searchList = this.erpDAO.getSearch_M_List(erpSearchDTO);
    	
    	
        //*******************************************
        // [ModelAndView 객체] 생성하기
        // [ModelAndView 객체]에 [호출 JSP 페이지명]을 저장하기
        //*******************************************
        ModelAndView mav = new ModelAndView( );
        mav.setViewName("m_search.jsp");
        // mav.addObject("boardDTO", boardDTO);
        mav.addObject("search_m_list_cnt",search_m_list_cnt);
        mav.addObject("m_searchList",m_searchList);
        mav.addObject("pagingNos",map);


        //*******************************************
        // [ModelAndView 객체] 리턴하기
        //*******************************************
        return mav;
    }
    
    

  //===================================================================================================================
  //===================================================================================================================
  //===================================================================================================================
    //입출력 접속 컨트롤러 메소드
    
    
    // 가전 재고관리(입고) 접속.
    @RequestMapping(value = "/g_stock_management.do")
    public ModelAndView go_G_Sstock_management(
        ERPSearchDTO erpSearchDTO
    ) {


    // DB연동해 가져온 재고관리(가전) 검색리스트
    List<Map<String,String>> get_g_stock_manageList = this.erpDAO.get_g_stock_manage(erpSearchDTO);


    // 입출고 페이지 분리로 인한 출고 리스트 메서드 주석처리.  
    // List<Map<String,String>> get_g_stock_manage_outList = this.erpDAO.get_g_stock_manage_out(erpSearchDTO);

    


    //검색결과의 제품수를 가져오는 메소드실행후 변수에 담음
    int searchListAllCnt = this.erpDAO.get_stock_SearchAllCnt(erpSearchDTO);

    // 페이징 처리 메소드 결과물을 변수에 담음
    Map<String,Integer> map = Util.getPagingNos(searchListAllCnt, erpSearchDTO.getSelectPageNo(), erpSearchDTO.getRowCntPerPage(), 10);
    erpSearchDTO.setSelectPageNo(map.get("selectPageNo"));

    


   	 // 검색화면에서 뿌려지는 각종 리스트들
        List<Map<String,String>> category_list = this.erpDAO.get_Category_List();
    	List<Map<String,String>> gajeon_category_list = this.erpDAO.get_Gajeon_Category_List();
    	List<Map<String,String>> season_gajeon_category_list = this.erpDAO.get_Season_Gajeon_Category_List();
    	List<Map<String,String>> kitchen_gajeon_category_list = this.erpDAO.get_kitchen_Gajeon_Category_List();
    	List<Map<String,String>> life_gajeon_category_list = this.erpDAO.get_Life_Gajeon_Category_List();
    	

        //=================================================================================================================================================
        // 검색화면에서 뿌려지는 각종 리스트들 나머지, 전부,   
        // 각 세부 및 색상 브랜드 카테고리 리스트 담아서 다 가져옴. 
    	List<Map<String,String>> energy_grade_list = this.erpDAO.get_Energy_Grade_List();
    	

    	List<Map<String,String>> g_brand_list = this.erpDAO.get_G_Brand_List();
    	List<Map<String,String>> g_color_list = this.erpDAO.get_G_Color_List();
    	

    	List<Map<String,String>> g_season_color_list = this.erpDAO.get_G_Season_Color_List();
    	List<Map<String,String>> g_season_brand_list = this.erpDAO.get_G_Season_Brand_List();
    	List<Map<String,String>> g_season_aircon_color_list = this.erpDAO.get_G_Season_Aircon_Color_List();
    	List<Map<String,String>> g_season_aircon_brand_list = this.erpDAO.get_G_Season_Aircon_Brand_List();
    	List<Map<String,String>> g_season_airfresh_brand_list = this.erpDAO.get_G_Season_Airfresh_Brand_List();
    	List<Map<String,String>> g_season_airfresh_color_list = this.erpDAO.get_G_Season_Airfresh_Color_List();
    	List<Map<String,String>> g_season_hitter_brand_list = this.erpDAO.get_G_Season_Hitter_Brand_List();
    	List<Map<String,String>> g_season_hitter_color_list = this.erpDAO.get_G_Season_Hitter_Color_List();
    	List<Map<String,String>> g_season_aircon_airfrash_color_list = this.erpDAO.get_G_Season_Aircon_Airfresh_Color_List();
    	List<Map<String,String>> g_season_aircon_airfrash_brand_list = this.erpDAO.get_G_Season_Aircon_Airfresh_Brand_List();
    	List<Map<String,String>> g_season_aircon_hitter_color_list = this.erpDAO.get_G_Season_Aircon_Hitter_Color_List();
    	List<Map<String,String>> g_season_aircon_hitter_brand_list = this.erpDAO.get_G_Season_Aircon_Hitter_Brand_List();
    	List<Map<String,String>> g_season_airfresh_hitter_color_list = this.erpDAO.get_G_Season_Airfresh_Hitter_Color_List();
    	List<Map<String,String>> g_season_airfresh_hitter_brand_list = this.erpDAO.get_G_Season_Airfresh_Hitter_Brand_List();
    	

    	List<Map<String,String>> g_kitchen_color_list = this.erpDAO.get_G_Kitchen_Color_List();
    	List<Map<String,String>> g_kitchen_brand_list = this.erpDAO.get_G_Kitchen_Brand_List();
    	List<Map<String,String>> g_kitchen_fridge_color_list = this.erpDAO.get_G_Kitchen_Fridge_Color_List();
    	List<Map<String,String>> g_kitchen_fridge_brand_list = this.erpDAO.get_G_Kitchen_Fridge_Brand_List();
    	List<Map<String,String>> g_kitchen_cooker_color_list = this.erpDAO.get_G_Kitchen_Cooker_Color_List();
    	List<Map<String,String>> g_kitchen_cooker_brand_list = this.erpDAO.get_G_Kitchen_Cooker_Brand_List();
    	List<Map<String,String>> g_kitchen_airfryer_color_list = this.erpDAO.get_G_Kitchen_Airfryer_Color_List();
    	List<Map<String,String>> g_kitchen_airfryer_brand_list = this.erpDAO.get_G_Kitchen_Airfryer_Brand_List();
    	List<Map<String,String>> g_kitchen_fridge_cooker_color_list = this.erpDAO.get_G_Kitchen_Fridge_Cooker_Color_List();
    	List<Map<String,String>> g_kitchen_fridge_cooker_brand_list = this.erpDAO.get_G_Kitchen_Fridge_Cooker_Brand_List();
    	List<Map<String,String>> g_kitchen_fridge_airfryer_color_list = this.erpDAO.get_G_Kitchen_Fridge_Airfryer_Color_List();
    	List<Map<String,String>> g_kitchen_fridge_airfryer_brand_list = this.erpDAO.get_G_Kitchen_Fridge_Airfryer_Brand_List();
    	List<Map<String,String>> g_kitchen_cooker_airfryer_color_list = this.erpDAO.get_G_Kitchen_Cooker_Airfryer_Color_List();
    	List<Map<String,String>> g_kitchen_cooker_airfryer_brand_list = this.erpDAO.get_G_Kitchen_Cooker_Airfryer_Brand_List();
    	
    	
    	List<Map<String,String>> g_life_color_list = this.erpDAO.get_G_Life_Color_List();
    	List<Map<String,String>> g_life_brand_list = this.erpDAO.get_G_Life_Brand_List();
    	List<Map<String,String>> g_life_washer_color_list = this.erpDAO.get_G_Life_Washer_Color_List();
    	List<Map<String,String>> g_life_washer_brand_list = this.erpDAO.get_G_Life_Washer_Brand_List();
    	List<Map<String,String>> g_life_dryer_color_list = this.erpDAO.get_G_Life_Dryer_Color_List();
    	List<Map<String,String>> g_life_dryer_brand_list = this.erpDAO.get_G_Life_Dryer_Brand_List();
    	List<Map<String,String>> g_life_cleaner_color_list = this.erpDAO.get_G_Life_Cleaner_Color_List();
    	List<Map<String,String>> g_life_cleaner_brand_list = this.erpDAO.get_G_Life_Cleaner_Brand_List();
    	List<Map<String,String>> g_life_washer_dryer_color_list = this.erpDAO.get_G_Life_Washer_Dryer_Color_List();
    	List<Map<String,String>> g_life_washer_dryer_brand_list = this.erpDAO.get_G_Life_Washer_Dryer_Brand_List();
    	List<Map<String,String>> g_life_washer_cleaner_color_list = this.erpDAO.get_G_Life_Washer_Cleaner_Color_List();
    	List<Map<String,String>> g_life_washer_cleaner_brand_list = this.erpDAO.get_G_Life_Washer_Cleaner_Brand_List();
    	List<Map<String,String>> g_life_dryer_cleaner_color_list = this.erpDAO.get_G_Life_Dryer_Cleaner_Color_List();
    	List<Map<String,String>> g_life_dryer_cleaner_brand_list = this.erpDAO.get_G_Life_Dryer_Cleaner_Brand_List();
    	
    	
        ModelAndView mav = new ModelAndView();
        mav.setViewName("g_stock_in_out.jsp");




        // DB연동해 가져온 재고관리(가전) 검색리스트 addObject
        mav.addObject("get_g_stock_manageList",get_g_stock_manageList);
        // 입출고 페이지 분리로 인한 출고 리스트 주석처리.  
        // mav.addObject("get_g_stock_manage_outList",get_g_stock_manage_outList);
        

        // 페이징 처리.
        mav.addObject("searchListAllCnt",searchListAllCnt);
        mav.addObject("pagingNos",map);




        // 검색화면에서 뿌려지는 각종 리스트들
        mav.addObject("category_list",category_list);
        mav.addObject("gajeon_category_list",gajeon_category_list);
        mav.addObject("season_gajeon_category_list",season_gajeon_category_list);
        mav.addObject("kitchen_gajeon_category_list",kitchen_gajeon_category_list);
        mav.addObject("life_gajeon_category_list",life_gajeon_category_list);

        //================================================================================================================================================
        // 검색화면에서 뿌려지는 각종 리스트들 나머지, 전부,   
        // 각 세부 및 색상 브랜드 카테고리 리스트 담아서 다 가져온걸 addObject 함.
        mav.addObject("energy_grade_list",energy_grade_list);
        mav.addObject("g_brand_list",g_brand_list);
        mav.addObject("g_color_list",g_color_list);
        
        
        mav.addObject("g_season_color_list",g_season_color_list);
        mav.addObject("g_season_brand_list",g_season_brand_list);
        
        mav.addObject("g_season_aircon_color_list",g_season_aircon_color_list);
        mav.addObject("g_season_aircon_brand_list",g_season_aircon_brand_list);
        mav.addObject("g_season_airfresh_brand_list",g_season_airfresh_brand_list);
        mav.addObject("g_season_airfresh_color_list",g_season_airfresh_color_list);
        mav.addObject("g_season_hitter_brand_list",g_season_hitter_brand_list);
        mav.addObject("g_season_hitter_color_list",g_season_hitter_color_list);
        mav.addObject("g_season_aircon_airfrash_color_list",g_season_aircon_airfrash_color_list);
        mav.addObject("g_season_aircon_airfrash_brand_list",g_season_aircon_airfrash_brand_list);
        mav.addObject("g_season_aircon_hitter_color_list",g_season_aircon_hitter_color_list);
        mav.addObject("g_season_aircon_hitter_brand_list",g_season_aircon_hitter_brand_list);
        mav.addObject("g_season_airfresh_hitter_color_list",g_season_airfresh_hitter_color_list);
        mav.addObject("g_season_airfresh_hitter_brand_list",g_season_airfresh_hitter_brand_list);
        
        
        mav.addObject("g_kitchen_color_list",g_kitchen_color_list);
        mav.addObject("g_kitchen_brand_list",g_kitchen_brand_list);
        
        mav.addObject("g_kitchen_fridge_color_list",g_kitchen_fridge_color_list);
        mav.addObject("g_kitchen_fridge_brand_list",g_kitchen_fridge_brand_list);
        mav.addObject("g_kitchen_cooker_color_list",g_kitchen_cooker_color_list);
        mav.addObject("g_kitchen_cooker_brand_list",g_kitchen_cooker_brand_list);
        mav.addObject("g_kitchen_airfryer_color_list",g_kitchen_airfryer_color_list);
        mav.addObject("g_kitchen_airfryer_brand_list",g_kitchen_airfryer_brand_list);
        
        mav.addObject("g_kitchen_fridge_cooker_color_list",g_kitchen_fridge_cooker_color_list);
        mav.addObject("g_kitchen_fridge_cooker_brand_list",g_kitchen_fridge_cooker_brand_list);
        mav.addObject("g_kitchen_fridge_airfryer_color_list",g_kitchen_fridge_airfryer_color_list);
        mav.addObject("g_kitchen_fridge_airfryer_brand_list",g_kitchen_fridge_airfryer_brand_list);
        mav.addObject("g_kitchen_cooker_airfryer_color_list",g_kitchen_cooker_airfryer_color_list);
        mav.addObject("g_kitchen_cooker_airfryer_brand_list",g_kitchen_cooker_airfryer_brand_list);
 
        
        mav.addObject("g_life_color_list",g_life_color_list);
        mav.addObject("g_life_brand_list",g_life_brand_list);
        mav.addObject("g_life_washer_color_list",g_life_washer_color_list);
        mav.addObject("g_life_washer_brand_list",g_life_washer_brand_list);
        mav.addObject("g_life_dryer_color_list",g_life_dryer_color_list);
        mav.addObject("g_life_dryer_brand_list",g_life_dryer_brand_list);
        mav.addObject("g_life_cleaner_color_list",g_life_cleaner_color_list);
        mav.addObject("g_life_cleaner_brand_list",g_life_cleaner_brand_list);
        mav.addObject("g_life_washer_dryer_color_list",g_life_washer_dryer_color_list);
        mav.addObject("g_life_washer_dryer_brand_list",g_life_washer_dryer_brand_list);
        mav.addObject("g_life_washer_cleaner_color_list",g_life_washer_cleaner_color_list);
        mav.addObject("g_life_washer_cleaner_brand_list",g_life_washer_cleaner_brand_list);
        mav.addObject("g_life_dryer_cleaner_color_list",g_life_dryer_cleaner_color_list);
        mav.addObject("g_life_dryer_cleaner_brand_list",g_life_dryer_cleaner_brand_list);
        return mav;
    }


    //===================================================================================================================
    // 가전 재고관리(출고) 접속.
    @RequestMapping(value = "/g_out_stock_management.do")
    public ModelAndView go_G_out_stock_management(
        ERPSearchDTO erpSearchDTO
    ) {

    // ======================================================
    // DB연동해 가져온 재고관리(가전) 검색리스트
    // 입출고 분리로 인한 입고 리스트 메서드 주석처리.
    // List<Map<String,String>> get_g_stock_manageList = this.erpDAO.get_g_stock_manage(erpSearchDTO);

    List<Map<String,String>> get_g_stock_manage_outList = this.erpDAO.get_g_stock_manage_out(erpSearchDTO);
    // ======================================================

    


    //검색결과의 제품수를 가져오는 메소드실행후 변수에 담음
    int searchListAllCnt = this.erpDAO.get_out_stock_SearchAllCnt(erpSearchDTO);



    // 페이징 처리 메소드 결과물을 변수에 담음
    Map<String,Integer> map = Util.getPagingNos(searchListAllCnt, erpSearchDTO.getSelectPageNo(), erpSearchDTO.getRowCntPerPage(), 10);
    erpSearchDTO.setSelectPageNo(map.get("selectPageNo"));

    


        // 검색화면에서 뿌려지는 각종 리스트들
        List<Map<String,String>> category_list = this.erpDAO.get_Category_List();
        List<Map<String,String>> gajeon_category_list = this.erpDAO.get_Gajeon_Category_List();
        List<Map<String,String>> season_gajeon_category_list = this.erpDAO.get_Season_Gajeon_Category_List();
        List<Map<String,String>> kitchen_gajeon_category_list = this.erpDAO.get_kitchen_Gajeon_Category_List();
        List<Map<String,String>> life_gajeon_category_list = this.erpDAO.get_Life_Gajeon_Category_List();
        

        //=================================================================================================================================================
        // 검색화면에서 뿌려지는 각종 리스트들 나머지, 전부,   
        // 각 세부 및 색상 브랜드 카테고리 리스트 담아서 다 가져옴. 
        List<Map<String,String>> energy_grade_list = this.erpDAO.get_Energy_Grade_List();
        

        List<Map<String,String>> g_brand_list = this.erpDAO.get_G_Brand_List();
        List<Map<String,String>> g_color_list = this.erpDAO.get_G_Color_List();
        

        List<Map<String,String>> g_season_color_list = this.erpDAO.get_G_Season_Color_List();
        List<Map<String,String>> g_season_brand_list = this.erpDAO.get_G_Season_Brand_List();
        List<Map<String,String>> g_season_aircon_color_list = this.erpDAO.get_G_Season_Aircon_Color_List();
        List<Map<String,String>> g_season_aircon_brand_list = this.erpDAO.get_G_Season_Aircon_Brand_List();
        List<Map<String,String>> g_season_airfresh_brand_list = this.erpDAO.get_G_Season_Airfresh_Brand_List();
        List<Map<String,String>> g_season_airfresh_color_list = this.erpDAO.get_G_Season_Airfresh_Color_List();
        List<Map<String,String>> g_season_hitter_brand_list = this.erpDAO.get_G_Season_Hitter_Brand_List();
        List<Map<String,String>> g_season_hitter_color_list = this.erpDAO.get_G_Season_Hitter_Color_List();
        List<Map<String,String>> g_season_aircon_airfrash_color_list = this.erpDAO.get_G_Season_Aircon_Airfresh_Color_List();
        List<Map<String,String>> g_season_aircon_airfrash_brand_list = this.erpDAO.get_G_Season_Aircon_Airfresh_Brand_List();
        List<Map<String,String>> g_season_aircon_hitter_color_list = this.erpDAO.get_G_Season_Aircon_Hitter_Color_List();
        List<Map<String,String>> g_season_aircon_hitter_brand_list = this.erpDAO.get_G_Season_Aircon_Hitter_Brand_List();
        List<Map<String,String>> g_season_airfresh_hitter_color_list = this.erpDAO.get_G_Season_Airfresh_Hitter_Color_List();
        List<Map<String,String>> g_season_airfresh_hitter_brand_list = this.erpDAO.get_G_Season_Airfresh_Hitter_Brand_List();
        

        List<Map<String,String>> g_kitchen_color_list = this.erpDAO.get_G_Kitchen_Color_List();
        List<Map<String,String>> g_kitchen_brand_list = this.erpDAO.get_G_Kitchen_Brand_List();
        List<Map<String,String>> g_kitchen_fridge_color_list = this.erpDAO.get_G_Kitchen_Fridge_Color_List();
        List<Map<String,String>> g_kitchen_fridge_brand_list = this.erpDAO.get_G_Kitchen_Fridge_Brand_List();
        List<Map<String,String>> g_kitchen_cooker_color_list = this.erpDAO.get_G_Kitchen_Cooker_Color_List();
        List<Map<String,String>> g_kitchen_cooker_brand_list = this.erpDAO.get_G_Kitchen_Cooker_Brand_List();
        List<Map<String,String>> g_kitchen_airfryer_color_list = this.erpDAO.get_G_Kitchen_Airfryer_Color_List();
        List<Map<String,String>> g_kitchen_airfryer_brand_list = this.erpDAO.get_G_Kitchen_Airfryer_Brand_List();
        List<Map<String,String>> g_kitchen_fridge_cooker_color_list = this.erpDAO.get_G_Kitchen_Fridge_Cooker_Color_List();
        List<Map<String,String>> g_kitchen_fridge_cooker_brand_list = this.erpDAO.get_G_Kitchen_Fridge_Cooker_Brand_List();
        List<Map<String,String>> g_kitchen_fridge_airfryer_color_list = this.erpDAO.get_G_Kitchen_Fridge_Airfryer_Color_List();
        List<Map<String,String>> g_kitchen_fridge_airfryer_brand_list = this.erpDAO.get_G_Kitchen_Fridge_Airfryer_Brand_List();
        List<Map<String,String>> g_kitchen_cooker_airfryer_color_list = this.erpDAO.get_G_Kitchen_Cooker_Airfryer_Color_List();
        List<Map<String,String>> g_kitchen_cooker_airfryer_brand_list = this.erpDAO.get_G_Kitchen_Cooker_Airfryer_Brand_List();
        
        
        List<Map<String,String>> g_life_color_list = this.erpDAO.get_G_Life_Color_List();
        List<Map<String,String>> g_life_brand_list = this.erpDAO.get_G_Life_Brand_List();
        List<Map<String,String>> g_life_washer_color_list = this.erpDAO.get_G_Life_Washer_Color_List();
        List<Map<String,String>> g_life_washer_brand_list = this.erpDAO.get_G_Life_Washer_Brand_List();
        List<Map<String,String>> g_life_dryer_color_list = this.erpDAO.get_G_Life_Dryer_Color_List();
        List<Map<String,String>> g_life_dryer_brand_list = this.erpDAO.get_G_Life_Dryer_Brand_List();
        List<Map<String,String>> g_life_cleaner_color_list = this.erpDAO.get_G_Life_Cleaner_Color_List();
        List<Map<String,String>> g_life_cleaner_brand_list = this.erpDAO.get_G_Life_Cleaner_Brand_List();
        List<Map<String,String>> g_life_washer_dryer_color_list = this.erpDAO.get_G_Life_Washer_Dryer_Color_List();
        List<Map<String,String>> g_life_washer_dryer_brand_list = this.erpDAO.get_G_Life_Washer_Dryer_Brand_List();
        List<Map<String,String>> g_life_washer_cleaner_color_list = this.erpDAO.get_G_Life_Washer_Cleaner_Color_List();
        List<Map<String,String>> g_life_washer_cleaner_brand_list = this.erpDAO.get_G_Life_Washer_Cleaner_Brand_List();
        List<Map<String,String>> g_life_dryer_cleaner_color_list = this.erpDAO.get_G_Life_Dryer_Cleaner_Color_List();
        List<Map<String,String>> g_life_dryer_cleaner_brand_list = this.erpDAO.get_G_Life_Dryer_Cleaner_Brand_List();
        
        
        ModelAndView mav = new ModelAndView();
        mav.setViewName("g_stock_out.jsp");



        // ======================================================
        // DB연동해 가져온 재고관리(가전) 검색리스트 addObject
        // 입출고 분리로 인한 입고 리스트 주석처리.
        // mav.addObject("get_g_stock_manageList",get_g_stock_manageList);
        mav.addObject("get_g_stock_manage_outList",get_g_stock_manage_outList);
        // ======================================================
        

        // 페이징 처리.
        mav.addObject("searchListAllCnt",searchListAllCnt);
        mav.addObject("pagingNos",map);




        // 검색화면에서 뿌려지는 각종 리스트들
        mav.addObject("category_list",category_list);
        mav.addObject("gajeon_category_list",gajeon_category_list);
        mav.addObject("season_gajeon_category_list",season_gajeon_category_list);
        mav.addObject("kitchen_gajeon_category_list",kitchen_gajeon_category_list);
        mav.addObject("life_gajeon_category_list",life_gajeon_category_list);

        //================================================================================================================================================
        // 검색화면에서 뿌려지는 각종 리스트들 나머지, 전부,   
        // 각 세부 및 색상 브랜드 카테고리 리스트 담아서 다 가져온걸 addObject 함.
        mav.addObject("energy_grade_list",energy_grade_list);
        mav.addObject("g_brand_list",g_brand_list);
        mav.addObject("g_color_list",g_color_list);
        
        
        mav.addObject("g_season_color_list",g_season_color_list);
        mav.addObject("g_season_brand_list",g_season_brand_list);
        
        mav.addObject("g_season_aircon_color_list",g_season_aircon_color_list);
        mav.addObject("g_season_aircon_brand_list",g_season_aircon_brand_list);
        mav.addObject("g_season_airfresh_brand_list",g_season_airfresh_brand_list);
        mav.addObject("g_season_airfresh_color_list",g_season_airfresh_color_list);
        mav.addObject("g_season_hitter_brand_list",g_season_hitter_brand_list);
        mav.addObject("g_season_hitter_color_list",g_season_hitter_color_list);
        mav.addObject("g_season_aircon_airfrash_color_list",g_season_aircon_airfrash_color_list);
        mav.addObject("g_season_aircon_airfrash_brand_list",g_season_aircon_airfrash_brand_list);
        mav.addObject("g_season_aircon_hitter_color_list",g_season_aircon_hitter_color_list);
        mav.addObject("g_season_aircon_hitter_brand_list",g_season_aircon_hitter_brand_list);
        mav.addObject("g_season_airfresh_hitter_color_list",g_season_airfresh_hitter_color_list);
        mav.addObject("g_season_airfresh_hitter_brand_list",g_season_airfresh_hitter_brand_list);
        
        
        mav.addObject("g_kitchen_color_list",g_kitchen_color_list);
        mav.addObject("g_kitchen_brand_list",g_kitchen_brand_list);
        
        mav.addObject("g_kitchen_fridge_color_list",g_kitchen_fridge_color_list);
        mav.addObject("g_kitchen_fridge_brand_list",g_kitchen_fridge_brand_list);
        mav.addObject("g_kitchen_cooker_color_list",g_kitchen_cooker_color_list);
        mav.addObject("g_kitchen_cooker_brand_list",g_kitchen_cooker_brand_list);
        mav.addObject("g_kitchen_airfryer_color_list",g_kitchen_airfryer_color_list);
        mav.addObject("g_kitchen_airfryer_brand_list",g_kitchen_airfryer_brand_list);
        
        mav.addObject("g_kitchen_fridge_cooker_color_list",g_kitchen_fridge_cooker_color_list);
        mav.addObject("g_kitchen_fridge_cooker_brand_list",g_kitchen_fridge_cooker_brand_list);
        mav.addObject("g_kitchen_fridge_airfryer_color_list",g_kitchen_fridge_airfryer_color_list);
        mav.addObject("g_kitchen_fridge_airfryer_brand_list",g_kitchen_fridge_airfryer_brand_list);
        mav.addObject("g_kitchen_cooker_airfryer_color_list",g_kitchen_cooker_airfryer_color_list);
        mav.addObject("g_kitchen_cooker_airfryer_brand_list",g_kitchen_cooker_airfryer_brand_list);
    
        
        mav.addObject("g_life_color_list",g_life_color_list);
        mav.addObject("g_life_brand_list",g_life_brand_list);
        mav.addObject("g_life_washer_color_list",g_life_washer_color_list);
        mav.addObject("g_life_washer_brand_list",g_life_washer_brand_list);
        mav.addObject("g_life_dryer_color_list",g_life_dryer_color_list);
        mav.addObject("g_life_dryer_brand_list",g_life_dryer_brand_list);
        mav.addObject("g_life_cleaner_color_list",g_life_cleaner_color_list);
        mav.addObject("g_life_cleaner_brand_list",g_life_cleaner_brand_list);
        mav.addObject("g_life_washer_dryer_color_list",g_life_washer_dryer_color_list);
        mav.addObject("g_life_washer_dryer_brand_list",g_life_washer_dryer_brand_list);
        mav.addObject("g_life_washer_cleaner_color_list",g_life_washer_cleaner_color_list);
        mav.addObject("g_life_washer_cleaner_brand_list",g_life_washer_cleaner_brand_list);
        mav.addObject("g_life_dryer_cleaner_color_list",g_life_dryer_cleaner_color_list);
        mav.addObject("g_life_dryer_cleaner_brand_list",g_life_dryer_cleaner_brand_list);
        return mav;
    }
    

    // TV 재고관리 접속.
    @RequestMapping(value = "/t_stock_management.do")
    public ModelAndView go_T_Sstock_management() {
    	
        // 검색화면에서 뿌려지는 각종 리스트들
        List<Map<String,String>> category_list = this.erpDAO.get_Category_List();
    	List<Map<String,String>> gajeon_category_list = this.erpDAO.get_Gajeon_Category_List();
    	List<Map<String,String>> season_gajeon_category_list = this.erpDAO.get_Season_Gajeon_Category_List();
    	List<Map<String,String>> kitchen_gajeon_category_list = this.erpDAO.get_kitchen_Gajeon_Category_List();
    	List<Map<String,String>> life_gajeon_category_list = this.erpDAO.get_Life_Gajeon_Category_List();
    	List<Map<String,String>> tv_category_list = this.erpDAO.get_TV_Category_List();
    	List<Map<String,String>> pc_category_list = this.erpDAO.get_PC_Category_List();
    	List<Map<String,String>> gaming_pc_category_list = this.erpDAO.get_Gaming_PC_Category_List();
    	List<Map<String,String>> office_pc_category_list = this.erpDAO.get_Office_PC_Category_List();
    	List<Map<String,String>> mobile_category_list = this.erpDAO.get_Mobile_Category_List();
    	List<Map<String,String>> phone_category_list = this.erpDAO.get_Phone_Category_List();
    	List<Map<String,String>> tablet_category_list = this.erpDAO.get_Tablet_Category_List();

    	

        //=================================================================================================================================================
        // 검색화면에서 뿌려지는 각종 리스트들 나머지, 전부,   
        // 각 세부 및 색상 브랜드 카테고리 리스트 담아서 다 가져옴. 
    	List<Map<String,String>> energy_grade_list = this.erpDAO.get_Energy_Grade_List();
    	
    	
    	List<Map<String,String>> t_brand_list = this.erpDAO.get_T_Brand_List();
    	List<Map<String,String>> t_color_list = this.erpDAO.get_T_Color_List();
    	List<Map<String,String>> t_qled_brand_list = this.erpDAO.get_T_QLED_Brand_List();
    	List<Map<String,String>> t_qled_color_list = this.erpDAO.get_T_QLED_Color_List();
    	List<Map<String,String>> t_miniled_brand_list = this.erpDAO.get_T_MINILED_Brand_List();
    	List<Map<String,String>> t_miniled_color_list = this.erpDAO.get_T_MINILED_Color_List();
    	List<Map<String,String>> t_oled_brand_list = this.erpDAO.get_T_OLED_Brand_List();
    	List<Map<String,String>> t_oled_color_list = this.erpDAO.get_T_OLED_Color_List();
    	
    	
        ModelAndView mav = new ModelAndView();
        mav.setViewName("t_stock_in_out.jsp");
        // 검색화면에서 뿌려지는 각종 리스트들
        //================================================================================================================================================
        // 검색화면에서 뿌려지는 각종 리스트들 나머지, 전부,   
        // 각 세부 및 색상 브랜드 카테고리 리스트 담아서 다 가져온걸 addObject 함.
        mav.addObject("energy_grade_list",energy_grade_list);       
        mav.addObject("category_list",category_list);
        mav.addObject("gajeon_category_list",gajeon_category_list);
        mav.addObject("season_gajeon_category_list",season_gajeon_category_list);
        mav.addObject("kitchen_gajeon_category_list",kitchen_gajeon_category_list);
        mav.addObject("life_gajeon_category_list",life_gajeon_category_list);
        mav.addObject("tv_category_list",tv_category_list);
        mav.addObject("pc_category_list",pc_category_list);
        mav.addObject("gaming_pc_category_list",gaming_pc_category_list);
        mav.addObject("office_pc_category_list",office_pc_category_list);
        mav.addObject("mobile_category_list",mobile_category_list);
        mav.addObject("phone_category_list",phone_category_list);
        mav.addObject("tablet_category_list",tablet_category_list);

        mav.addObject("t_brand_list",t_brand_list);
        mav.addObject("t_color_list",t_color_list);
        mav.addObject("t_qled_brand_list",t_qled_brand_list);
        mav.addObject("t_qled_color_list",t_qled_color_list);
        mav.addObject("t_miniled_brand_list",t_miniled_brand_list);
        mav.addObject("t_miniled_color_list",t_miniled_color_list); 
        mav.addObject("t_oled_brand_list",t_oled_brand_list);
        mav.addObject("t_oled_color_list",t_oled_color_list); 



        return mav;
    }
    // PC 재고관리 접속.
    @RequestMapping(value = "/p_stock_management.do")
    public ModelAndView go_P_Sstock_management() {
    	
    	
    	
        // 검색화면에서 뿌려지는 각종 리스트들
        List<Map<String,String>> category_list = this.erpDAO.get_Category_List();
    	List<Map<String,String>> pc_category_list = this.erpDAO.get_PC_Category_List();
    	List<Map<String,String>> gaming_pc_category_list = this.erpDAO.get_Gaming_PC_Category_List();
    	List<Map<String,String>> office_pc_category_list = this.erpDAO.get_Office_PC_Category_List();
    	

        //=================================================================================================================================================
        // 검색화면에서 뿌려지는 각종 리스트들 나머지, 전부,   
        // 각 세부 및 색상 브랜드 카테고리 리스트 담아서 다 가져옴. 
    	List<Map<String,String>> energy_grade_list = this.erpDAO.get_Energy_Grade_List();
    	
    	
    	List<Map<String,String>> p_brand_list = this.erpDAO.get_P_Brand_List();
    	List<Map<String,String>> p_color_list = this.erpDAO.get_P_Color_List();	
    	List<Map<String,String>> p_desktop_brand_list = this.erpDAO.get_P_Desktop_Brand_List();
    	List<Map<String,String>> p_desktop_color_list = this.erpDAO.get_P_Desktop_Color_List();
    	List<Map<String,String>> p_notebook_brand_list = this.erpDAO.get_P_Notebook_Brand_List();
    	List<Map<String,String>> p_notebook_color_list = this.erpDAO.get_P_Notebook_Color_List();
    	List<Map<String,String>> p_desktop_office_brand_list = this.erpDAO.get_P_Desktop_Office_Brand_List();
    	List<Map<String,String>> p_desktop_office_color_list = this.erpDAO.get_P_Desktop_Office_Color_List();
    	List<Map<String,String>> p_desktop_gaming_brand_list = this.erpDAO.get_P_Desktop_Gaming_Brand_List();
    	List<Map<String,String>> p_desktop_gaming_color_list = this.erpDAO.get_P_Desktop_Gaming_Color_List();
    	List<Map<String,String>> p_notebook_business_brand_list = this.erpDAO.get_P_Notebook_Business_Brand_List();
    	List<Map<String,String>> p_notebook_business_color_list = this.erpDAO.get_P_Notebook_Business_Color_List();
    	List<Map<String,String>> p_notebook_gaming_brand_list = this.erpDAO.get_P_Notebook_Gaming_Brand_List();
    	List<Map<String,String>> p_notebook_gaming_color_list = this.erpDAO.get_P_Notebook_Gaming_Color_List();
    	
    	
        ModelAndView mav = new ModelAndView();
        mav.setViewName("p_stock_in_out.jsp");
        
        
        mav.addObject("category_list",category_list);
        mav.addObject("pc_category_list",pc_category_list);
        mav.addObject("gaming_pc_category_list",gaming_pc_category_list);
        mav.addObject("office_pc_category_list",office_pc_category_list);


        //================================================================================================================================================
        // 검색화면에서 뿌려지는 각종 리스트들 나머지, 전부,   
        // 각 세부 및 색상 브랜드 카테고리 리스트 담아서 다 가져온걸 addObject 함.
        mav.addObject("energy_grade_list",energy_grade_list);
        mav.addObject("p_brand_list",p_brand_list);
        mav.addObject("p_color_list",p_color_list);
        mav.addObject("p_desktop_brand_list",p_desktop_brand_list);
        mav.addObject("p_desktop_color_list",p_desktop_color_list);
        mav.addObject("p_notebook_brand_list",p_notebook_brand_list);
        mav.addObject("p_notebook_color_list",p_notebook_color_list);
        mav.addObject("p_desktop_office_brand_list",p_desktop_office_brand_list);
        mav.addObject("p_desktop_office_color_list",p_desktop_office_color_list);
        mav.addObject("p_desktop_gaming_brand_list",p_desktop_gaming_brand_list);
        mav.addObject("p_desktop_gaming_color_list",p_desktop_gaming_color_list);
        mav.addObject("p_notebook_business_brand_list",p_notebook_business_brand_list);
        mav.addObject("p_notebook_business_color_list",p_notebook_business_color_list);
        mav.addObject("p_notebook_gaming_brand_list",p_notebook_gaming_brand_list);
        mav.addObject("p_notebook_gaming_color_list",p_notebook_gaming_color_list);
        return mav;
    }
    // 모바일 재고관리 접속.
    @RequestMapping(value = "/m_stock_management.do")
    public ModelAndView go_M_Sstock_management() {
    	
        // 검색화면에서 뿌려지는 각종 리스트들
        List<Map<String,String>> category_list = this.erpDAO.get_Category_List();
    	List<Map<String,String>> mobile_category_list = this.erpDAO.get_Mobile_Category_List();
    	List<Map<String,String>> phone_category_list = this.erpDAO.get_Phone_Category_List();
    	List<Map<String,String>> tablet_category_list = this.erpDAO.get_Tablet_Category_List();

    	

        //=================================================================================================================================================
        // 검색화면에서 뿌려지는 각종 리스트들 나머지, 전부,   
        // 각 세부 및 색상 브랜드 카테고리 리스트 담아서 다 가져옴. 
    	List<Map<String,String>> energy_grade_list = this.erpDAO.get_Energy_Grade_List();
    	
    	List<Map<String,String>> m_brand_list = this.erpDAO.get_M_Brand_List();
    	List<Map<String,String>> m_color_list = this.erpDAO.get_M_Color_List();   
    	List<Map<String,String>> m_phone_brand_list = this.erpDAO.get_M_Phone_Brand_List();
    	List<Map<String,String>> m_phone_color_list = this.erpDAO.get_M_Phone_Color_List();
    	List<Map<String,String>> m_tablet_brand_list = this.erpDAO.get_M_Tablet_Brand_List();
    	List<Map<String,String>> m_tablet_color_list = this.erpDAO.get_M_Tablet_Color_List();
    	List<Map<String,String>> m_phone_samsung_brand_list = this.erpDAO.get_M_Phone_Samsung_Brand_List();
    	List<Map<String,String>> m_phone_samsung_color_list = this.erpDAO.get_M_Phone_Samsung_Color_List();
    	List<Map<String,String>> m_phone_apple_brand_list = this.erpDAO.get_M_Phone_Apple_Brand_List();
    	List<Map<String,String>> m_phone_apple_color_list = this.erpDAO.get_M_Phone_Apple_Color_List();
    	List<Map<String,String>> m_phone_other_brand_list = this.erpDAO.get_M_Phone_Other_Brand_List();
    	List<Map<String,String>> m_phone_other_color_list = this.erpDAO.get_M_Phone_Other_Color_List();
    	List<Map<String,String>> m_phone_samsung_apple_brand_list = this.erpDAO.get_M_Phone_Samsung_Apple_Brand_List();
    	List<Map<String,String>> m_phone_samsung_apple_color_list = this.erpDAO.get_M_Phone_Samsung_Apple_Color_List();
    	List<Map<String,String>> m_phone_samsung_other_brand_list = this.erpDAO.get_M_Phone_Samsung_Other_Brand_List();
    	List<Map<String,String>> m_phone_samsung_other_color_list = this.erpDAO.get_M_Phone_Samsung_Other_Color_List();
    	List<Map<String,String>> m_phone_apple_other_brand_list = this.erpDAO.get_M_Phone_Apple_Other_Brand_List();
    	List<Map<String,String>> m_phone_apple_other_color_list = this.erpDAO.get_M_Phone_Apple_Other_Color_List();
    	List<Map<String,String>> m_tablet_android_brand_list = this.erpDAO.get_M_Tablet_Android_Brand_List();
    	List<Map<String,String>> m_tablet_android_color_list = this.erpDAO.get_M_Tablet_Android_Color_List();
    	List<Map<String,String>> m_tablet_windows_brand_list = this.erpDAO.get_M_Tablet_Windows_Brand_List();
    	List<Map<String,String>> m_tablet_windows_color_list = this.erpDAO.get_M_Tablet_Windows_Color_List();
    	List<Map<String,String>> m_tablet_ipad_brand_list = this.erpDAO.get_M_Tablet_Ipad_Brand_List();
    	List<Map<String,String>> m_tablet_ipad_color_list = this.erpDAO.get_M_Tablet_Ipad_Color_List();
    	List<Map<String,String>> m_tablet_android_windows_brand_list = this.erpDAO.get_M_Tablet_Android_Windows_Brand_List();
    	List<Map<String,String>> m_tablet_android_windows_color_list = this.erpDAO.get_M_Tablet_Android_Windows_Color_List();
    	List<Map<String,String>> m_tablet_android_ipad_brand_list = this.erpDAO.get_M_Tablet_Android_Ipad_Brand_List();
    	List<Map<String,String>> m_tablet_android_ipad_color_list = this.erpDAO.get_M_Tablet_Android_Ipad_Color_List();
    	List<Map<String,String>> m_tablet_windows_ipad_brand_list = this.erpDAO.get_M_Tablet_Windows_Ipad_Brand_List();
    	List<Map<String,String>> m_tablet_windows_ipad_color_list = this.erpDAO.get_M_Tablet_Windows_Ipad_Color_List();   	
    	
    	
    	
        ModelAndView mav = new ModelAndView();
        mav.setViewName("m_stock_in_out.jsp");
        // 검색화면에서 뿌려지는 각종 리스트들
        mav.addObject("category_list",category_list);
        mav.addObject("mobile_category_list",mobile_category_list);
        mav.addObject("phone_category_list",phone_category_list);
        mav.addObject("tablet_category_list",tablet_category_list);


        //================================================================================================================================================
        // 검색화면에서 뿌려지는 각종 리스트들 나머지, 전부,   
        // 각 세부 및 색상 브랜드 카테고리 리스트 담아서 다 가져온걸 addObject 함.
        mav.addObject("energy_grade_list",energy_grade_list);
        mav.addObject("m_brand_list",m_brand_list);
        mav.addObject("m_color_list",m_color_list);  
        mav.addObject("m_phone_brand_list",m_phone_brand_list);
        mav.addObject("m_phone_color_list",m_phone_color_list); 
        mav.addObject("m_tablet_brand_list",m_tablet_brand_list);
        mav.addObject("m_tablet_color_list",m_tablet_color_list); 
        mav.addObject("m_phone_samsung_brand_list",m_phone_samsung_brand_list);
        mav.addObject("m_phone_samsung_color_list",m_phone_samsung_color_list); 
        mav.addObject("m_phone_apple_brand_list",m_phone_apple_brand_list);
        mav.addObject("m_phone_apple_color_list",m_phone_apple_color_list);
        mav.addObject("m_phone_other_brand_list",m_phone_other_brand_list);
        mav.addObject("m_phone_other_color_list",m_phone_other_color_list); 
        mav.addObject("m_phone_samsung_apple_brand_list",m_phone_samsung_apple_brand_list);
        mav.addObject("m_phone_samsung_apple_color_list",m_phone_samsung_apple_color_list); 
        mav.addObject("m_phone_samsung_other_brand_list",m_phone_samsung_other_brand_list);
        mav.addObject("m_phone_samsung_other_color_list",m_phone_samsung_other_color_list); 
        mav.addObject("m_phone_apple_other_brand_list",m_phone_apple_other_brand_list);
        mav.addObject("m_phone_apple_other_color_list",m_phone_apple_other_color_list); 
        mav.addObject("m_tablet_android_brand_list",m_tablet_android_brand_list);
        mav.addObject("m_tablet_android_color_list",m_tablet_android_color_list);
        mav.addObject("m_tablet_windows_brand_list",m_tablet_windows_brand_list);
        mav.addObject("m_tablet_windows_color_list",m_tablet_windows_color_list);
        mav.addObject("m_tablet_ipad_brand_list",m_tablet_ipad_brand_list);
        mav.addObject("m_tablet_ipad_color_list",m_tablet_ipad_color_list);
        mav.addObject("m_tablet_android_windows_brand_list",m_tablet_android_windows_brand_list);
        mav.addObject("m_tablet_android_windows_color_list",m_tablet_android_windows_color_list);
        mav.addObject("m_tablet_android_ipad_brand_list",m_tablet_android_ipad_brand_list);
        mav.addObject("m_tablet_android_ipad_color_list",m_tablet_android_ipad_color_list);
        mav.addObject("m_tablet_windows_ipad_brand_list",m_tablet_windows_ipad_brand_list);
        mav.addObject("m_tablet_windows_ipad_color_list",m_tablet_windows_ipad_color_list);
        
        return mav;
    }
    //===================================================================================================================
    //===================================================================================================================
    //===================================================================================================================   
    
    
    //===================================================================================================================
    //===================================================================================================================
    //===================================================================================================================
      //통계자료페이지 이동 컨트롤러 메소드
    

    // 전체 통계화면 접속.
      //통계자료페이지 이동 컨트롤러 메소드
  //★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★ 
  //★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    //  전체 통계화면 접속.
  //★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
  //★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★

  @RequestMapping(value = "/statistics.do")
  public ModelAndView goStatistics(

      ERPSearchDTO erpSearchDTO
      ,ERPDTO erpDTO
  ) {
      //----------------------------
      // 가전 소분류 1~9번째 총개수
      int g_subsub_eachcnt = this.erpDAO.G_SubSub_Each_AllCnt();
      int g_subsub_eachcnt_2 = this.erpDAO.G_SubSub_Each_AllCnt_2();
      int g_subsub_eachcnt_3 = this.erpDAO.G_SubSub_Each_AllCnt_3();
      int g_subsub_eachcnt_4 = this.erpDAO.G_SubSub_Each_AllCnt_4();
      int g_subsub_eachcnt_5 = this.erpDAO.G_SubSub_Each_AllCnt_5();
      int g_subsub_eachcnt_6 = this.erpDAO.G_SubSub_Each_AllCnt_6();
      int g_subsub_eachcnt_7 = this.erpDAO.G_SubSub_Each_AllCnt_7();
      int g_subsub_eachcnt_8 = this.erpDAO.G_SubSub_Each_AllCnt_8();
      int g_subsub_eachcnt_9 = this.erpDAO.G_SubSub_Each_AllCnt_9(); 
              
      
      //----------------------------
      // 가전 카테고리 총수량
      //----------------------------
             int g_item_Cnt = this.erpDAO.G_Category_AllCnt();  	
         //----------------------------
      // TV 카테고리 총수량
         //----------------------------
          int t_item_Cnt = this.erpDAO.T_Category_AllCnt(); 
      //----------------------------
      // PC 카테고리 총수량
      //----------------------------
          int p_item_Cnt = this.erpDAO.P_Category_AllCnt();  
      //----------------------------
      // 모바일 카테고리 총수량
      //----------------------------
          int m_item_Cnt = this.erpDAO.M_Category_AllCnt(); 	
      //----------------------------------------------		
      // TV 소분류 1~3번째  총개수
      //----------------------------------------------
          int t_subsub_eachcnt = this.erpDAO.T_SubSub_Each_AllCnt();
          int t_subsub_eachcnt_2 = this.erpDAO.T_SubSub_Each_AllCnt_2();
          int t_subsub_eachcnt_3 = this.erpDAO.T_SubSub_Each_AllCnt_3();    
          
              
              
              
              
          //MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
              //----------------------------------------------
              // PC 소분류 1번째(사무용_인강용) 총개수
              //----------------------------------------------
                  int p_subsub_eachcnt = this.erpDAO.P_SubSub_Each_AllCnt();
              //----------------------------------------------
              // PC 소분류 2번째(게이밍) 총개수
              //----------------------------------------------
                  int p_subsub_eachcnt_2 = this.erpDAO.P_SubSub_Each_AllCnt_2();
              //----------------------------------------------
              // PC 소분류 3번째(비지니스) 총개수
              //----------------------------------------------
                  int p_subsub_eachcnt_3 = this.erpDAO.P_SubSub_Each_AllCnt_3();
              //----------------------------------------------
              // PC 소분류 4번째(게이밍노트북) 총개수
              //----------------------------------------------
                  int p_subsub_eachcnt_4 = this.erpDAO.P_SubSub_Each_AllCnt_4();
         //MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM 		
              //----------------------------------------------
              //	가전 소분류 BEST 10 총수량
              //----------------------------------------------
                  List<Map<String,String>> g_sub_sub_color_best_ten_alllist = this.erpDAO.G_Sub_Sub_Color_Best_ten_AllList(erpDTO);            		
              //----------------------------------------------
              // TV 소분류 BEST 10 총수량
              //----------------------------------------------
                  List<Map<String,String>> t_sub_sub_color_best_ten_alllist = this.erpDAO.T_Sub_Sub_Color_Best_ten_AllList(erpDTO);	
              //----------------------------------------------	
              //	PC 소분류 BEST 10 총수량
              //----------------------------------------------
                  List<Map<String,String>> p_sub_sub_color_best_ten_alllist = this.erpDAO.P_Sub_Sub_Color_Best_ten_AllList(erpDTO);	
              //----------------------------------------------	
              // 모바일 소분류 BEST 10 총수량
              //----------------------------------------------	
                  List<Map<String,String>> m_sub_sub_color_best_ten_alllist = this.erpDAO.M_Sub_Sub_Color_Best_ten_AllList(erpDTO);
        //MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM   
              //----------------------------------------------
              // 가전 선호 브랜드 순위 best 5 
              //----------------------------------------------
                  List<Map<String,String>> g_subsub_brand_best = this.erpDAO.G_SubSub_Best_Brand(erpDTO);
              //----------------------------------------------
              // TV 선호 브랜드 순위 best 5
              //----------------------------------------------
                  List<Map<String,String>> t_subsub_brand_best = this.erpDAO.T_SubSub_Best_Brand(erpDTO);
              //----------------------------------------------
              // PC 선호 브랜드 순위 best 5
              //----------------------------------------------
                  List<Map<String,String>> p_subsub_brand_best = this.erpDAO.P_SubSub_Best_Brand(erpDTO);  
              //----------------------------------------------
              // PC 선호 브랜드 순위 best 5
              //----------------------------------------------
                  List<Map<String,String>> m_subsub_brand_best = this.erpDAO.M_SubSub_Best_Brand(erpDTO);
                      

 
                  
                  
              //----------------------------------------------	
              // 모바일 소분류 1번째(삼성전자) 총개수
              //----------------------------------------------
                  int m_subsub_eachcnt = this.erpDAO.M_SubSub_Each_AllCnt();
              //----------------------------------------------
              // 모바일 소분류 2번째(애플) 총개수
              //----------------------------------------------
                  int m_subsub_eachcnt_2 = this.erpDAO.M_SubSub_Each_AllCnt_2();
              //----------------------------------------------
              // 모바일 소분류 3번째(기타) 총개수
              //----------------------------------------------
                  int m_subsub_eachcnt_3 = this.erpDAO.M_SubSub_Each_AllCnt_3();
              //----------------------------------------------
              // 모바일 소분류 4번째(안드로이드) 총개수
              //----------------------------------------------
                  int m_subsub_eachcnt_4 = this.erpDAO.M_SubSub_Each_AllCnt_4();
              //----------------------------------------------
              // 모바일 소분류 5번째(윈도우) 총개수
              //----------------------------------------------
                  int m_subsub_eachcnt_5 = this.erpDAO.M_SubSub_Each_AllCnt_5();
              //----------------------------------------------
              // 모바일 소분류 6번째(아이패드) 총개수
              //----------------------------------------------
                  int m_subsub_eachcnt_6 = this.erpDAO.M_SubSub_Each_AllCnt_6();

      //====================================================================================
          
      //====================================================================================
          
      //====================================================================================
          
          
          
          
          //MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM	
          // 연도별 가전제품 수량 
          int g_year2019CNT = this.erpDAO.G_year_2019_CNT();
          int g_year2020CNT = this.erpDAO.G_year_2020_CNT();
          int g_year2021CNT = this.erpDAO.G_year_2021_CNT();

          int p_year2019CNT = this.erpDAO.P_year_2019_CNT();
          int p_year2020CNT = this.erpDAO.P_year_2020_CNT();
          int p_year2021CNT = this.erpDAO.P_year_2021_CNT();


          int m_year2019CNT = this.erpDAO.M_year_2019_CNT();
          int m_year2020CNT = this.erpDAO.M_year_2020_CNT();
          int m_year2021CNT = this.erpDAO.M_year_2021_CNT();

          int t_year2019CNT = this.erpDAO.T_year_2019_CNT();
          int t_year2020CNT = this.erpDAO.T_year_2020_CNT();
          int t_year2021CNT = this.erpDAO.T_year_2021_CNT();


          //MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM	
      //====================================================================================
          

          
          
      System.out.println( "g_item_Cnt  ==>" + erpDAO.G_Category_AllCnt() );
      System.out.println( "t_item_Cnt  ==>" + erpDAO.T_Category_AllCnt() );   
      System.out.println( "p_item_Cnt  ==>" + erpDAO.P_Category_AllCnt() );
      System.out.println( "m_item_Cnt  ==>" + erpDAO.M_Category_AllCnt() );

      //MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
      System.out.println( "g_year2019CNT  ==>" + erpDAO.G_year_2019_CNT() );
      System.out.println( "g_year2020CNT  ==>" + erpDAO.G_year_2020_CNT() );
      System.out.println( "g_year2021CNT  ==>" + erpDAO.G_year_2021_CNT() );
      //MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
      
      

      ModelAndView mav = new ModelAndView();
      mav.setViewName("statistics.jsp");




      //---------------------------------------
      // 10월23일 대분류 카테고리별 총개수(전체통계쪽)
      //---------------------------------------
      mav.addObject("g_item_Cnt", g_item_Cnt);
      mav.addObject("t_item_Cnt", t_item_Cnt);
      mav.addObject("p_item_Cnt", p_item_Cnt);
      mav.addObject("m_item_Cnt", m_item_Cnt);
      // 테스트용
     // mav.addObject("category_code",1);

      //===========================================================
      // 연도별 입고수량
      //MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
       mav.addObject("g_year2019CNT", g_year2019CNT);
       mav.addObject("g_year2020CNT", g_year2020CNT);
       mav.addObject("g_year2021CNT", g_year2021CNT);

       mav.addObject("p_year2019CNT", p_year2019CNT);
       mav.addObject("p_year2020CNT", p_year2020CNT);
       mav.addObject("p_year2021CNT", p_year2021CNT);

       mav.addObject("m_year2019CNT", m_year2019CNT);
       mav.addObject("m_year2020CNT", m_year2020CNT);
       mav.addObject("m_year2021CNT", m_year2021CNT);

       mav.addObject("t_year2019CNT", t_year2019CNT);
       mav.addObject("t_year2020CNT", t_year2020CNT);
       mav.addObject("t_year2021CNT", t_year2021CNT);
       //MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM        

      //----------------------------------------------
      // 가전 소분류 별 총수량
      //----------------------------------------------
      mav.addObject("g_subsub_eachcnt" , g_subsub_eachcnt);
      mav.addObject("g_subsub_eachcnt_2" , g_subsub_eachcnt_2);
      mav.addObject("g_subsub_eachcnt_3" , g_subsub_eachcnt_3);
      mav.addObject("g_subsub_eachcnt_4" , g_subsub_eachcnt_4);
      mav.addObject("g_subsub_eachcnt_5" , g_subsub_eachcnt_5);
      mav.addObject("g_subsub_eachcnt_6" , g_subsub_eachcnt_6);
      mav.addObject("g_subsub_eachcnt_7" , g_subsub_eachcnt_7);
      mav.addObject("g_subsub_eachcnt_8" , g_subsub_eachcnt_8);
      mav.addObject("g_subsub_eachcnt_9" , g_subsub_eachcnt_9);
      
      
      // 가전 소분류 색상 베스트5
      //===============================================
      mav.addObject("g_sub_sub_color_best_ten_alllist" , g_sub_sub_color_best_ten_alllist);
      
      // 가전 소분류 브랜드 베스트5
      //===============================================
      mav.addObject("g_subsub_brand_best", g_subsub_brand_best);
      //============================================================
      //----------------------------------------------
      // TV 소분류 '1'(QLED)총수량
      //----------------------------------------------
        mav.addObject("t_sub_sub_color_best_ten_alllist" , t_sub_sub_color_best_ten_alllist);
      //----------------------------------------------
      // TV 소분류 '1'(QLED)총수량
      //----------------------------------------------
        mav.addObject("t_subsub_eachcnt" , t_subsub_eachcnt);
      //----------------------------------------------
      // TV 소분류 '2'(mini_LED)총수량
      //----------------------------------------------
        mav.addObject("t_subsub_eachcnt_2" , t_subsub_eachcnt_2);
      //----------------------------------------------
      // TV 소분류 '3'(OLED)총수량
      //----------------------------------------------
        mav.addObject("t_subsub_eachcnt_3" , t_subsub_eachcnt_3);
        
     //----------------------------------------------
     // 10월23일 TV 선호 브랜드 순위 best 5 총개수(TV통계쪽)
     //----------------------------------------------
        mav.addObject("t_subsub_brand_best", t_subsub_brand_best);
        
      //----------------------------------------------
      //
      //----------------------------------------------
        mav.addObject("p_sub_sub_color_best_ten_alllist" , p_sub_sub_color_best_ten_alllist);
      //----------------------------------------------
      // PC 소분류 '1~6개' 총수량
      //----------------------------------------------
        mav.addObject("p_subsub_eachcnt" , p_subsub_eachcnt);
        mav.addObject("p_subsub_eachcnt_2" , p_subsub_eachcnt_2);
        mav.addObject("p_subsub_eachcnt_3" , p_subsub_eachcnt_3);
        mav.addObject("p_subsub_eachcnt_4" , p_subsub_eachcnt_4);
        mav.addObject("p_subsub_brand_best", p_subsub_brand_best);               
      //----------------------------------------------
      //
      //----------------------------------------------
        mav.addObject("m_sub_sub_color_best_ten_alllist" , m_sub_sub_color_best_ten_alllist);
      //----------------------------------------------
      // 모바일 소분류 1~6개'
      //----------------------------------------------
        mav.addObject("m_subsub_eachcnt" , m_subsub_eachcnt);
        mav.addObject("m_subsub_eachcnt_2" , m_subsub_eachcnt_2);
        mav.addObject("m_subsub_eachcnt_3" , m_subsub_eachcnt_3);
        mav.addObject("m_subsub_eachcnt_4" , m_subsub_eachcnt_4);
        mav.addObject("m_subsub_eachcnt_5" , m_subsub_eachcnt_5);
        mav.addObject("m_subsub_eachcnt_6" , m_subsub_eachcnt_6);
        
     // 10월23일 모바일 선호 브랜드 순위 best 5 총개수(모바일 통계쪽)
        mav.addObject("m_subsub_brand_best", m_subsub_brand_best);        
      return mav;
  }
//★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
//★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
//★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★




  //====================================================================================================================================================
  //====================================================================================================================================================
  //====================================================================================================================================================
    // 가전통계화면 접속.
    @RequestMapping(value = "/g_statistics.do")
    public ModelAndView go_G_Statistics(
    		ERPDTO erpDTO
    ) {
    	
    	// 가전 소분류 1~9번째 총개수
		int g_subsub_eachcnt = this.erpDAO.G_SubSub_Each_AllCnt();
		int g_subsub_eachcnt_2 = this.erpDAO.G_SubSub_Each_AllCnt_2();
		int g_subsub_eachcnt_3 = this.erpDAO.G_SubSub_Each_AllCnt_3();
		int g_subsub_eachcnt_4 = this.erpDAO.G_SubSub_Each_AllCnt_4();
		int g_subsub_eachcnt_5 = this.erpDAO.G_SubSub_Each_AllCnt_5();
		int g_subsub_eachcnt_6 = this.erpDAO.G_SubSub_Each_AllCnt_6();
		int g_subsub_eachcnt_7 = this.erpDAO.G_SubSub_Each_AllCnt_7();
		int g_subsub_eachcnt_8 = this.erpDAO.G_SubSub_Each_AllCnt_8();
		int g_subsub_eachcnt_9 = this.erpDAO.G_SubSub_Each_AllCnt_9();    	
    	
    	

		//----------------------------------------------
    	//	가전 소분류 BEST 10 총수량
		//----------------------------------------------
		List<Map<String,String>> g_sub_sub_color_best_ten_alllist = this.erpDAO.G_Sub_Sub_Color_Best_ten_AllList(erpDTO);
		//----------------------------------------------
	    // 가전 선호 브랜드 순위 best 5 
		//----------------------------------------------
    	List<Map<String,String>> g_subsub_brand_best = this.erpDAO.G_SubSub_Best_Brand(erpDTO);
    	
		
		System.out.println( "g_sub_sub_color_best_ten_alllist  =+++++=>" + erpDAO.G_Sub_Sub_Color_Best_ten_AllList(erpDTO) );
		
    	
        ModelAndView mav = new ModelAndView();
        mav.setViewName("g_statistics.jsp");
        
        
        //----------------------------------------------
        // 가전 소분류 별 총수량
        //----------------------------------------------
        mav.addObject("g_subsub_eachcnt" , g_subsub_eachcnt);
        mav.addObject("g_subsub_eachcnt_2" , g_subsub_eachcnt_2);
        mav.addObject("g_subsub_eachcnt_3" , g_subsub_eachcnt_3);
        mav.addObject("g_subsub_eachcnt_4" , g_subsub_eachcnt_4);
        mav.addObject("g_subsub_eachcnt_5" , g_subsub_eachcnt_5);
        mav.addObject("g_subsub_eachcnt_6" , g_subsub_eachcnt_6);
        mav.addObject("g_subsub_eachcnt_7" , g_subsub_eachcnt_7);
        mav.addObject("g_subsub_eachcnt_8" , g_subsub_eachcnt_8);
        mav.addObject("g_subsub_eachcnt_9" , g_subsub_eachcnt_9);
        
        
        
        //===============================================
        mav.addObject("g_sub_sub_color_best_ten_alllist" , g_sub_sub_color_best_ten_alllist);
        //===============================================
        mav.addObject("g_subsub_brand_best", g_subsub_brand_best);
        
        return mav;
    }
    //====================================================================================================================================================
    //====================================================================================================================================================
    //====================================================================================================================================================   
    // TV통계화면 접속.
    @RequestMapping(value = "/t_statistics.do")
    public ModelAndView go_T_Statistics(
    		ERPDTO erpDTO
    		) {
    //----------------------------------------------
    // TV 선호 브랜드 순위 best 5
    //----------------------------------------------
    	List<Map<String,String>> t_subsub_brand_best = this.erpDAO.T_SubSub_Best_Brand(erpDTO);

    	
    
    	System.out.println( "t_subsub_brand_best  ==>" + erpDAO.T_SubSub_Best_Brand(erpDTO) );
    	
    	
    	
    //----------------------------------------------		
    // TV 소분류 1~3번째  총개수
    //----------------------------------------------
		int t_subsub_eachcnt = this.erpDAO.T_SubSub_Each_AllCnt();
		int t_subsub_eachcnt_2 = this.erpDAO.T_SubSub_Each_AllCnt_2();
		int t_subsub_eachcnt_3 = this.erpDAO.T_SubSub_Each_AllCnt_3();
    	
		
		
		
		
	//----------------------------------------------
    // TV 소분류 BEST 10 총수량
	//----------------------------------------------
    	List<Map<String,String>> t_sub_sub_color_best_ten_alllist = this.erpDAO.T_Sub_Sub_Color_Best_ten_AllList(erpDTO);
    	
    	
    	
    	
    	System.out.println( "t_sub_sub_color_best_ten_alllist  ==>>" + erpDAO.T_Sub_Sub_Color_Best_ten_AllList(erpDTO) );
    	
    	
    	
    	
        ModelAndView mav = new ModelAndView();
        mav.setViewName("t_statistics.jsp");
        mav.addObject("t_sub_sub_color_best_ten_alllist" , t_sub_sub_color_best_ten_alllist);
      //----------------------------------------------
      // TV 소분류 '1'(QLED)총수량
      //----------------------------------------------
        mav.addObject("t_subsub_eachcnt" , t_subsub_eachcnt);
      //----------------------------------------------
      // TV 소분류 '2'(mini_LED)총수량
      //----------------------------------------------
        mav.addObject("t_subsub_eachcnt_2" , t_subsub_eachcnt_2);
      //----------------------------------------------
      // TV 소분류 '3'(OLED)총수량
      //----------------------------------------------
        mav.addObject("t_subsub_eachcnt_3" , t_subsub_eachcnt_3);
        
     //----------------------------------------------
     // 10월23일 TV 선호 브랜드 순위 best 5 총개수(TV통계쪽)
     //----------------------------------------------
        mav.addObject("t_subsub_brand_best", t_subsub_brand_best);
        
        return mav;
    } 
    //====================================================================================================================================================
    //====================================================================================================================================================
    //====================================================================================================================================================   
    // PC화면 접속.
    @RequestMapping(value = "/p_statistics.do")
    public ModelAndView go_P_Statistics(
    		ERPDTO erpDTO	 		
    		) {
    //----------------------------------------------	
    //	PC 소분류 BEST 10 총수량
    //----------------------------------------------
    	List<Map<String,String>> p_sub_sub_color_best_ten_alllist = this.erpDAO.P_Sub_Sub_Color_Best_ten_AllList(erpDTO);
    //----------------------------------------------
    // PC 소분류 1번째(사무용_인강용) 총개수
    //----------------------------------------------
		int p_subsub_eachcnt = this.erpDAO.P_SubSub_Each_AllCnt();
	//----------------------------------------------
	// PC 소분류 2번째(게이밍) 총개수
	//----------------------------------------------
		int p_subsub_eachcnt_2 = this.erpDAO.P_SubSub_Each_AllCnt_2();
	//----------------------------------------------
	// PC 소분류 3번째(비지니스) 총개수
	//----------------------------------------------
		int p_subsub_eachcnt_3 = this.erpDAO.P_SubSub_Each_AllCnt_3();
	//----------------------------------------------
	// PC 소분류 4번째(게이밍노트북) 총개수
	//----------------------------------------------
		int p_subsub_eachcnt_4 = this.erpDAO.P_SubSub_Each_AllCnt_4();
	//----------------------------------------------
	// PC 선호 브랜드 순위 best 5
	//----------------------------------------------
    	List<Map<String,String>> p_subsub_brand_best = this.erpDAO.P_SubSub_Best_Brand(erpDTO);	
  
    	
    	
    	System.out.println( "p_sub_sub_color_best_ten_alllist  ==>>>" + erpDAO.P_Sub_Sub_Color_Best_ten_AllList(erpDTO) );
    
    	
    	
    	
        ModelAndView mav = new ModelAndView();
        mav.setViewName("p_statistics.jsp");
        mav.addObject("p_sub_sub_color_best_ten_alllist" , p_sub_sub_color_best_ten_alllist);
      //----------------------------------------------
      // PC 소분류 '1~6개' 총수량
      //----------------------------------------------
        mav.addObject("p_subsub_eachcnt" , p_subsub_eachcnt);
        mav.addObject("p_subsub_eachcnt_2" , p_subsub_eachcnt_2);
        mav.addObject("p_subsub_eachcnt_3" , p_subsub_eachcnt_3);
        mav.addObject("p_subsub_eachcnt_4" , p_subsub_eachcnt_4);
        mav.addObject("p_subsub_brand_best", p_subsub_brand_best);
        
        return mav;
    } 
    //====================================================================================================================================================
    //====================================================================================================================================================
    //====================================================================================================================================================   
    // 모바일화면 접속.
    @RequestMapping(value = "/m_statistics.do")
    public ModelAndView go_M_Statistics(
    		ERPDTO erpDTO	
    		) {
    //----------------------------------------------	
    // 모바일 소분류 BEST 10 총수량
    //----------------------------------------------	
    	List<Map<String,String>> m_sub_sub_color_best_ten_alllist = this.erpDAO.M_Sub_Sub_Color_Best_ten_AllList(erpDTO);
    //----------------------------------------------	
    // 모바일 소분류 1번째(삼성전자) 총개수
    //----------------------------------------------
		int m_subsub_eachcnt = this.erpDAO.M_SubSub_Each_AllCnt();
	//----------------------------------------------
	// 모바일 소분류 2번째(애플) 총개수
	//----------------------------------------------
		int m_subsub_eachcnt_2 = this.erpDAO.M_SubSub_Each_AllCnt_2();
	//----------------------------------------------
	// 모바일 소분류 3번째(기타) 총개수
	//----------------------------------------------
		int m_subsub_eachcnt_3 = this.erpDAO.M_SubSub_Each_AllCnt_3();
	//----------------------------------------------
	// 모바일 소분류 4번째(안드로이드) 총개수
	//----------------------------------------------
		int m_subsub_eachcnt_4 = this.erpDAO.M_SubSub_Each_AllCnt_4();
	//----------------------------------------------
	// 모바일 소분류 5번째(윈도우) 총개수
	//----------------------------------------------
		int m_subsub_eachcnt_5 = this.erpDAO.M_SubSub_Each_AllCnt_5();
	//----------------------------------------------
	// 모바일 소분류 6번째(아이패드) 총개수
	//----------------------------------------------
		int m_subsub_eachcnt_6 = this.erpDAO.M_SubSub_Each_AllCnt_6();
		
		  // PC 선호 브랜드 순위 best 5
    	List<Map<String,String>> m_subsub_brand_best = this.erpDAO.M_SubSub_Best_Brand(erpDTO);	
    	
    	System.out.println( "m_sub_sub_color_best_ten_alllist  ==>>>>" + erpDAO.M_Sub_Sub_Color_Best_ten_AllList(erpDTO) );
    	
    	
        ModelAndView mav = new ModelAndView();
        mav.setViewName("m_statistics.jsp");
        mav.addObject("m_sub_sub_color_best_ten_alllist" , m_sub_sub_color_best_ten_alllist);
      //----------------------------------------------
      // 모바일 소분류 1~6개'
      //----------------------------------------------
        mav.addObject("m_subsub_eachcnt" , m_subsub_eachcnt);
        mav.addObject("m_subsub_eachcnt_2" , m_subsub_eachcnt_2);
        mav.addObject("m_subsub_eachcnt_3" , m_subsub_eachcnt_3);
        mav.addObject("m_subsub_eachcnt_4" , m_subsub_eachcnt_4);
        mav.addObject("m_subsub_eachcnt_5" , m_subsub_eachcnt_5);
        mav.addObject("m_subsub_eachcnt_6" , m_subsub_eachcnt_6);
        
     // 10월23일 모바일 선호 브랜드 순위 best 5 총개수(모바일 통계쪽)
        mav.addObject("m_subsub_brand_best", m_subsub_brand_best);
        
        return mav;
    }

    //====================================================================================================================================================
    //====================================================================================================================================================
    //====================================================================================================================================================


















    // ==============================================================================
    
    
    //새 물품 입력
    @RequestMapping( 
        value="/itemRegProc.do"
        ,method = RequestMethod.POST
        ,produces = "application/json;charset=UTF8"
    )
    @ResponseBody
    public Map<String, String> insertErp( 
        ERPDTO erpDTO
        ,@RequestParam(value = "reg_img") MultipartFile multi
    ){
        System.out.println(multi);
        //*******************************************
        // 업로드 파일의 크기와 확장자 체크하기
        //*******************************************
        // 만약에 업로드된 파일이 있으면
        if( multi.isEmpty()==false ) {
            // 만약에 업로드된 파일의 크기가 1000000 byte(=1000kb) 보다 크면
            if( multi.getSize()>50000000 ) {
                Map<String,String> map = new HashMap<String,String>();
                map.put( "erpRegCnt", "0" );
                map.put( "msg","업로드 파일이 1000kb 보다크면 안됩니다." );
                return map;
            }
            // 만약에 업로드된 파일의 확장자가 이미지 확장자가 아니면
            String fileName = multi.getOriginalFilename();
            if( fileName.endsWith(".jpeg")==false && fileName.endsWith(".jpg")==false && fileName.endsWith(".gif")==false && fileName.endsWith(".png")==false ){
                Map<String,String> map = new HashMap<String,String>();
                map.put( "erpRegCnt", "0" );
                map.put( "msg", "이미지 파일이 아닙니다." );
                return map;
            }
        }

        System.out.println( "itemRegProc 시작" );
        
        String fileName = multi.getOriginalFilename();
        
        System.out.println( "===========================================" );
        System.out.println( "pic       => " + fileName              );    	    
        System.out.println( "Item_code => " + erpDTO.getG_item_code() );
        System.out.println( "Item_name => " + erpDTO.getG_item_name() );
        System.out.println( "brand     => " + erpDTO.getBrand_code() );      
        System.out.println( "bigDivision => " + erpDTO.getCategory_code() );
        System.out.println( "g_sub_category_code => " + erpDTO.getG_sub_category_code() );
        System.out.println( "getG_sub_sub_category_code => " + erpDTO.getG_sub_sub_category_code() );
        System.out.println( "============" );      	    
        System.out.println( "power_consum => " + erpDTO.getG_power_consum() );
        System.out.println( "build_day    => " + erpDTO.getG_build_day()    );
        System.out.println( "energy_grade => " + erpDTO.getEnergy_grade_code() );
        System.out.println( "color        => " + erpDTO.getColor_code()        );
        System.out.println( "getG_item_sizex     => " + erpDTO.getG_item_size_x()     );
        System.out.println( "discontinued => " + erpDTO.getG_discontinued() );	    
        System.out.println( "===========================================" );
            
        //*******************************************
        // 게시판 등록 성공여부가 저장된 변수 선언. 1이 저장되면 성공했다는 의미
        // 유효성 체크 에러 메시지 저장할 변수 msg 선언.
        //*******************************************
        int erpRegCnt = 0;
        
            try {
                erpRegCnt = this.erpService.insertErp(erpDTO, multi);
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        
            System.out.println( "BoardController.insertBoard 메소드 호출 성공 " );
        
        Map<String, String> map = new HashMap<String,String>();
        map.put("erpRegCnt", erpRegCnt+"");
        
        System.out.println( "itemRegProc 종료" );
        return map;
    }


    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    // /itemUpDelProc.do 접속 시 호출되는 메소드 선언
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm

    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    // 가상주소 /itemUpDelProc.do 로 접근하면 호출되는 메소드 선언하기
    // 메소드 앞에 
    // @RequestMapping(~,~,produces = "application/json;charset=UTF8") 하고
    // @ResponseBody 가 붙으면 리턴하는 데이터가 클라이언트에게 전송된다.  
    // ModelAndView 객체를 리턴하면 JSP 를 호출하고 그 JSP 페이지의 실행결과인 HTML 문서가 응답 메시지에 저장되어 전송되지만  
    // @RequestMapping(~) 와 @ResponseBody 가 붙으면 리턴하는 데이터가 JSON 형태로 응답메시지에 저장되어 전송된다.  
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    @RequestMapping( 
        value="/itemUpDelProc.do"
        ,method = RequestMethod.POST
        ,produces = "application/json;charset=UTF8"
    )
    @ResponseBody
    public Map<String,String> itemUpDelProc( 
        // ***********************************************
        // 파라미터값을 저장할 [ERPDTO 객체]를 매개변수로 선언
        // ***********************************************
        ERPDTO erpDTO

        // **********************************************
        // <input type=file name=img> 입력양식의 파일이 저장된 MultipartFile 객체 저장 매개변수 선언.
        // <주의> 업로드된 파일이 없어도 MultipartFile 객체는 생성되어 들어온다. 
        // **********************************************
        ,@RequestParam(
            value = "img"
            ,required = false
            
        ) MultipartFile multi

        // ***********************************************
        // "upDel" 라는 파라미터명의 파라미터값이 저장된 매개변수 upDel 선언
        // ***********************************************
        ,@RequestParam(value = "upDel") String upDel
        ,@RequestParam(value = "paramV") String paramV

        // **********************************************
        // Error 객체를 관리하는 BindingResult 객체가 저장되어 들어오는 매개변수 bindingResult 선언
        // 유효성 검사결과를 관리
        // **********************************************
        , BindingResult bindingResult
    ){
        System.out.println("컨트롤러에서 upDel 확인 ==>   " + upDel);
        // **********************************************
        // 업로드 파일의 크기와 확장자 체크하기
        // **********************************************
        // 만약에 업로드된 파일이 있으면
        if( multi != null && multi.isEmpty()==false ){
     
            // 만약에 업로드된 파일의 크기가 1000000 byte(=1000kb) 보다 크면 
            if( multi.getSize()>10000000){
                Map<String,String> map = new HashMap<String,String>();
                map.put("itemUpDelCnt", "0");
                map.put("msg", "업로드 파일이 10mb 보다 크면 업로드 할 수 없습니다.");
                return map;
            }

            // 만약에 업로드된 파일의 확장자가 이미지 확장자가 아니면 
            String fileName = multi.getOriginalFilename();

            System.out.println("파일이름 확인하기 =>>> " + fileName);

            // 아래 세개의 조건문은 같은 코드이다.  
            // if( !(fileName.endsWith(".jpg") || fileName.endsWith(".gif") || fileName.endsWith(".png")) ){
            // if( !fileName.endsWith(".jpg") && !fileName.endsWith(".gif") && !fileName.endsWith(".png") ){
            if( fileName.endsWith(".jpg")==false && fileName.endsWith(".gif")==false && fileName.endsWith(".png")==false ){
                Map<String,String> map = new HashMap<String,String>();
                map.put("itemUpDelCnt", "0");
                map.put("msg", "이미지 파일 형식이 아닙니다.");
                return map;
            }
            
        }

        // **********************************************
        // 수정 또는 삭제 행의 적용 개수 저장할 변수 선언 
        // 유효성 체크 시 경고메시지 저장할 변수 msg 선언.
        // **********************************************
        int itemUpDelCnt = 0;
        String msg ="";
        // **********************************************
        // 만약 제품 삭제 모드이면
        // **********************************************
        if( upDel.equals("del") ){

            System.out.println( "====================" );

            // 삭제 실행하고 삭제 적용행의 개수 얻기
            itemUpDelCnt = this.erpService.deleteErp(erpDTO);
            System.out.println( "BoardController 에서 /boardUpDelProc.do 접속." );
            System.out.println( "삭제할 PK 번호 호출 getB_no => " + erpDTO.getCategory_code() );
        }

        // **********************************************
        // 만약 제품 수정 모드이면 수정 실행하고 수정 적용행의 개수 얻기
        // **********************************************
        else if(upDel.equals("up")){

            // *********************************************
            // check_BoardDTO 메소드를 호출하여 [유효성 체크]하고 경고문자 얻기
            // *********************************************
            // check_BoardDTO 메소드를 호출하여 [유효성 체크]하고 [에러 메시지] 문자 얻기
            // msg = check_BoardDTO( erpDTO, bindingResult );  
            // 만약 msg 안에 "" 가 저장되어 있으면, 즉, 유효성 체크를 통과했으면  
            if( msg.equals("") ){
                // -----------------------------------------
                // ERPServiceImpl 객체의 updateBoard 라는 메소드 호출로
                // 게시판 수정 실행하고 수정 적용행의 개수 얻기
                // -----------------------------------------
//                itemUpDelCnt = this.erpService.updateItem(erpDTO,multi);
 
                
                try {
                	itemUpDelCnt = this.erpService.updateItem(erpDTO, multi);
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                
                
                
                // System.out.println( "멀티 확인 ==>>>" + multi);


                System.out.println( "유효성체크 통과." );
            }
        }
        //*******************************************
        // HashMap<String,String> 객체 생성하기
        // HashMap<String,String> 객체에 게시판 수정.삭제 성공행의 개수 저장하기
        // HashMap<String,String> 객체에 유효성 체크 시 메시지 저장하기
        // HashMap<String,String> 객체 리턴하기
        //*******************************************
        Map<String,String> map = new HashMap<String,String>();
        map.put("boardUpDelCnt", itemUpDelCnt+"");
        map.put("msg", msg);
        System.out.println( "유효성체크 확인 => " + msg );

        return map;
    }






    // 입출고 입력
    @RequestMapping(value = "/stockInsertProc.do")
    @ResponseBody
    public int stockInsert(
    		ERPStockDTO erpStockDTO
    ){
        System.out.println( "ERPController.stockInsert 시작" );
        
        System.out.println( "=========================================================+"     );       
        System.out.println( "stockInsertCode     => " + erpStockDTO.getStockInsertCode()     );
        System.out.println( "stockInsertInOut    => " + erpStockDTO.getStockInsertInOut()    );
        System.out.println( "stockInsertNumber   => " + erpStockDTO.getStockInsertNumber()   );
        System.out.println( "stockInsertCategory => " + erpStockDTO.getStockInsertCategory() );         
        System.out.println( "=========================================================="     ); 
        
        int stockInsertCnt = 0;
        stockInsertCnt = this.erpService.insertStock(erpStockDTO);
        
        
        
        System.out.println( "ERPController.stockInsert 종료" );
        return stockInsertCnt;
        
    }





    // ============================================================================================================
    // 메인페이지 재고요약 순환 부분.
        // 메인 홈페이지에서 최다 조회수 게시판 검색
        @RequestMapping(value = "/homeBoardSearchProc.do")
        @ResponseBody
        public ModelAndView HomeBoardSelect(
                ERPHomeDTO erpHomeDTO
        ){
            System.out.println( "ERPController.HomeBoardSelect 시작" );
            
            ModelAndView mav = new ModelAndView();
            mav.setViewName("daybreak.jsp");
            
            System.out.println( "=========================================================+"     );       
            System.out.println( "homeBoardDaySelect   => " + erpHomeDTO.getHomeBoardDaySelect()  );       
            System.out.println( "=========================================================="     ); 
            
            List<Map<String, String>> homeBoardList = this.erpDAO.getHomeBoardList(erpHomeDTO);
            mav.addObject("homeBoardList",homeBoardList);
            System.out.println(homeBoardList);
    
            System.out.println( "ERPController.HomeBoardSelect 종료" );
            return mav;
            
        }   
        
        // 메인 홈페이지에서 재고요약 1번 기간 검색
        @RequestMapping(value = "/homeSummarybtnOneProc.do")
        @ResponseBody
        public ModelAndView homeSummarybtnOneSelect(
                ERPHomeDTO erpHomeDTO
        ){
            System.out.println( "ERPController.HomeBtnOneSelect 시작" );
            
            ModelAndView mav = new ModelAndView();
            mav.setViewName("daybreak.jsp");
            
            System.out.println( "=========================================================+"     );       
            System.out.println( "homeSummarybtnOneSelect   => " + erpHomeDTO.getHomeSummarybtnOneSelect()  );       
            System.out.println( "=========================================================="     ); 
            
            List<Map<String, String>> homeSummarybtnOneList = this.erpDAO.getHomeSummarybtnOneList(erpHomeDTO);
            mav.addObject("homeSummarybtnOneList",homeSummarybtnOneList);
            System.out.println(homeSummarybtnOneList);
    
            System.out.println( "ERPController.HomeBtnOneSelect 종료" );
            return mav;
            
        }  
    
        // 메인 홈페이지에서 재고요약 2번 기간 검색
        @RequestMapping(value = "/homeSummarybtnTwoProc.do")
        @ResponseBody
        public ModelAndView homeSummarybtnTwoSelect(
                ERPHomeDTO erpHomeDTO
        ){
            System.out.println( "ERPController.HomeBtnTwoSelect 시작" );
            
            ModelAndView mav = new ModelAndView();
            mav.setViewName("daybreak.jsp");
            
            System.out.println( "=========================================================+"     );       
            System.out.println( "homeSummarybtnTwoSelect   => " + erpHomeDTO.getHomeSummarybtnTwoSelect()  );       
            System.out.println( "=========================================================="     ); 
            
            List<Map<String, String>> homeSummarybtnTwoList = this.erpDAO.getHomeSummarybtnTwoList(erpHomeDTO);
            mav.addObject("homeSummarybtnTwoList",homeSummarybtnTwoList);
            System.out.println(homeSummarybtnTwoList);
    
            System.out.println( "ERPController.HomeBtnTwoSelect 종료" );
            return mav;
            
        }  
        
        // 메인 홈페이지에서 재고요약 3번 기간 검색
        @RequestMapping(value = "/homeSummarybtnThreeProc.do")
        @ResponseBody
        public ModelAndView homeSummarybtnThreeSelect(
                ERPHomeDTO erpHomeDTO
        ){
            System.out.println( "ERPController.HomeBtnThreeSelect 시작" );
            
            ModelAndView mav = new ModelAndView();
            mav.setViewName("daybreak.jsp");
            
            System.out.println( "=========================================================+"     );       
            System.out.println( "homeSummarybtnTwoSelect   => " + erpHomeDTO.getHomeSummarybtnThreeSelect()  );       
            System.out.println( "=========================================================="     ); 
            
            List<Map<String, String>> homeSummarybtnThreeList = this.erpDAO.getHomeSummarybtnThreeList(erpHomeDTO);
            mav.addObject("homeSummarybtnThreeList",homeSummarybtnThreeList);
            System.out.println(homeSummarybtnThreeList);
    
            System.out.println( "ERPController.HomeBtnThreeSelect 종료" );
            return mav;
            
        }      
    // ============================================================================================================
    






    //============================================================
    // 게시판 접속.
    // boardList.do로 바로 접속하게함.  
    // @RequestMapping(value = "/board.do")
    // public ModelAndView goBoard() {
    //     System.out.println("ERPController 쪽, ==> board.do 접속!@#!@#");

    //     ModelAndView mav = new ModelAndView();
    //     mav.setViewName("board.jsp");
    //     return mav;
    // }
    //============================================================
    
    

    

    // 통계화면 접속.
    // @RequestMapping(value = "/statistics.do")
    // public ModelAndView goStatistics() {
    //     ModelAndView mav = new ModelAndView();
    //     mav.setViewName("statistics.jsp");
    //     return mav;
    // }

    // 재고관리 접속.
    // 예전 재고관리 페이지라서 주석처리 했습니다.
    // @RequestMapping(value = "/stock_management.do")
    // public ModelAndView goSstock_management() {
    //     ModelAndView mav = new ModelAndView();
    //     mav.setViewName("stock_in_out.jsp");
    //     return mav;
    // }






    // 고객센터 접속.
    @RequestMapping(value = "/service_center.do")
    public ModelAndView goService_center() {
        ModelAndView mav = new ModelAndView();
        mav.setViewName("service_center.jsp");
        return mav;
    }

    // 재고관리 안에서 가전 검색.
    @RequestMapping(value = "/jaego_search.do")
    public ModelAndView goJaego_search() {
        ModelAndView mav = new ModelAndView();
        mav.setViewName("jaego_search.jsp");
        return mav;
    }
    @RequestMapping(value="/getItemInfo.do", method=RequestMethod.POST, produces = "application/json;charset=UTF8" )
    @ResponseBody
    public Map getItemInfo(ERPSearchDTO erpSearchDTO) {
        System.out.println("getItemInfo에서 확인   : " + erpSearchDTO.getITEM_CODE());
        Map map = new HashMap();
        List<Map<String,String>> searchALLList = this.erpDAO.getSearcALLhList(erpSearchDTO);
        if(searchALLList != null && searchALLList.size() > 0){
            map.put("getItemInfo", searchALLList.get(0));
            return map;
        }
        map.put("msg", "이미 삭제된 제품입니다.");
        return map;
    }
    



}
