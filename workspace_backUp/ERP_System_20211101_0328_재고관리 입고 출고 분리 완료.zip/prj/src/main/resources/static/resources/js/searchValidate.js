function searchValidate() {
  var BO = $(".brand_office");
  var itemName = $(".ITEM_NAME");
  var itemCode = $(".item_code");
  var P1 = $(".power.one");
  var P2 = $(".power.two");
  var build_date_year_F = $.trim($(".build_date_year.first").val());
  var build_date_month_F = $.trim($(".build_date_month.first").val());
  var build_date_year_L = $.trim($(".build_date_year.last").val());
  var build_date_month_L = $.trim($(".build_date_month.last").val());
  var input_date_year_F = $.trim($(".input_date_year.first").val());
  var input_date_month_F = $.trim($(".input_date_month.first").val());
  var input_date_year_L = $.trim($(".input_date_year.last").val());
  var input_date_month_L = $.trim($(".input_date_month.last").val());
  var output_date_year_F = $.trim($(".output_date_year.first").val());
  var output_date_month_F = $.trim($(".output_date_month.first").val());
  var output_date_year_L = $.trim($(".output_date_year.last").val());
  var output_date_month_L = $.trim($(".output_date_month.last").val());
  if ($.trim(BO.val()) === "0") {
    alert("지점을 선택해주세요!");
    return true;
  }
  if ($.trim(itemName.val()) === "") {
    itemName.val("");
  }
  if ($.trim(itemCode.val()) === "") {
    itemCode.val("");
  }
  if (P1.val().length > 0 || P2.val().length > 0) {
    var regExp = new RegExp(/^[0-9]*$/);
    var intP1 = 0;
    var intP2 = 0;
    if (P1.val().length > 0 && !regExp.test($.trim(P1.val()))) {
      alert("소비전력은 숫자만 입력할 수 있습니다.");
      P1.val("");
      P1.focus();
      return true;
    } else {
      intP1 = parseInt($.trim(P1.val()), 10);
    }
    if (P2.val().length > 0 && !regExp.test($.trim(P2.val()))) {
      alert("소비전력은 숫자만 입력할 수 있습니다.");
      P2.val("");
      P2.focus();
      return true;
    } else {
      intP2 = parseInt($.trim(P1.val()), 10);
    }
    if (intP1 > 0 && intP2 > 0) {
      var interval = parseInt($.trim(P2.val()), 10) - parseInt($.trim(P1.val()), 10);
      if (interval < 0) {
        alert("소비전력 최솟값이 최댓값보다 큽니다!");
        P1.val("");
        P2.val("");
        P1.focus();
        return true;
      }
    }
  }

  if (build_date_year_F.length > 0 && build_date_month_F.length > 0 && build_date_year_L.length > 0 && build_date_month_L.length > 0) {
    var intBuildFirstYear = parseInt(build_date_year_F, 10);
    var intBuildFirstMonth = parseInt(build_date_month_F, 10);
    var intBuildLastYear = parseInt(build_date_year_L, 10);
    var intBuildLastMonth = parseInt(build_date_month_L, 10);
    if (intBuildFirstYear >= intBuildLastYear || intBuildFirstMonth >= intBuildLastMonth) {
      if (intBuildFirstYear > intBuildLastYear || intBuildFirstMonth > intBuildLastMonth) {
        alert("제조일 시작년도가 끝년도보다 높습니다.");
        return true;
      }
      if (intBuildFirstYear == intBuildLastYear && intBuildFirstMonth === intBuildLastMonth) {
        alert("같은 제조일 기간은 검색 할 수 없습니다.");
        return true;
      }
    }
  }
  if (input_date_year_F.length > 0 && input_date_month_F.length > 0 && input_date_year_L.length > 0 && input_date_month_L.length > 0) {
    var intInputFirstYear = parseInt(input_date_year_F, 10);
    var intInputFirstMonth = parseInt(input_date_month_F, 10);
    var intInputLastYear = parseInt(input_date_year_L, 10);
    var intInputLastMonth = parseInt(input_date_month_L, 10);
    if (intInputFirstYear >= intInputLastYear || intInputFirstMonth >= intInputLastMonth) {
      if (intInputFirstYear > intInputLastYear || intInputFirstMonth > intInputLastMonth) {
        alert("입고일 시작년도가 끝년도보다 높습니다.");
        return true;
      }
      if (intInputFirstYear == intInputLastYear && intInputFirstMonth === intInputLastMonth) {
        alert("같은 입고일 기간은 검색 할 수 없습니다.");
        return true;
      }
    }
  }
  if (output_date_year_F.length > 0 && output_date_month_F.length > 0 && output_date_year_L.length > 0 && output_date_month_L.length > 0) {
    var intOutputFirstYear = parseInt(output_date_year_F, 10);
    var intOutputFirstMonth = parseInt(output_date_month_F, 10);
    var intOutputLastYear = parseInt(output_date_year_L, 10);
    var intOutputLastMonth = parseInt(output_date_month_L, 10);
    if (intOutputFirstYear >= intOutputLastYear || intOutputFirstMonth >= intOutputLastMonth) {
      if (intOutputFirstYear > intOutputLastYear || intOutputFirstMonth > intOutputLastMonth) {
        alert("출고일 시작년도가 끝년도보다 높습니다.");
        return true;
      }
      if (intOutputFirstYear == intOutputLastYear && intOutputFirstMonth === intOutputLastMonth) {
        alert("같은 출고일 기간은 검색 할 수 없습니다.");
        return true;
      }
    }
  }
  return false;
}
