package com.daybreak.prj.Service;

import org.springframework.web.multipart.MultipartFile;

import com.daybreak.prj.DTO.ERPDTO;

public interface ERPService {

	// 입력 리턴하는 메소드
	int insertErp(ERPDTO erpDTO, MultipartFile multi)throws Exception;




    // 가전제품 삭제 메소드
    int deleteErp(ERPDTO erpDTO);



    // 제품 업데이트 메소드
	public int updateItem(ERPDTO drpDTO,  MultipartFile multi)throws Exception;



    































    // ===================================================================================
    // 게시판 Service 참고용 주석. 삭제하지마시고, 그냥 코드들 참고하시고 위에 코딩 해주세요.
    // ===================================================================================
/*
    // ****************************************************
    // [게시판 글 입력 후 입력 적용 행의 개수] 리턴하는 메소드 선언
    // ****************************************************
    int insertBoard(BoardDTO boardDTO, MultipartFile multi)throws Exception;
	
    // ****************************************************
	// [1개 게시판 글] 리턴하는 메소드 선언
    // ****************************************************
	BoardDTO getBoard(int b_no);

    // ****************************************************
    // [1개 게시판] 수정 실행하고 수정 적용행의 개수를 리턴하는 메소드 선언
    // ****************************************************
    int updateBoard(BoardDTO boardDTO, MultipartFile multi)throws Exception;

    // ****************************************************
    // [1개 게시판] 삭제 후 삭제 적용행의 개수를 리턴하는 메소드 선언
    // ****************************************************
    int deleteBoard(BoardDTO boardDTO);
*/

}
