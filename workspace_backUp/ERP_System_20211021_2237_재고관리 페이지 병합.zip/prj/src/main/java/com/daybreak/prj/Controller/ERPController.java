package com.daybreak.prj.Controller;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.daybreak.prj.DAO.ERPDAO;
import com.daybreak.prj.DTO.ERPDTO;
import com.daybreak.prj.DTO.ERPSearchDTO;
import com.daybreak.prj.Service.ERPService;
import com.daybreak.prj.Util.Util;

@Controller
public class ERPController {
	
	@Autowired
	private ERPDAO erpDAO;
	@Autowired
	private ERPService erpService;	
	
	// 메인화면 접속
    @RequestMapping(value = "/daybreak.do")
    public ModelAndView daybreak() {
        ModelAndView mav = new ModelAndView();
        mav.setViewName("daybreak.jsp");
        return mav;
    }


    // 통합검색 접속.
    @RequestMapping( value="/searchAll.do" )
    public ModelAndView goSearchAll( 
    		ERPSearchDTO erpSearchDTO
            
    ){
        System.out.println("searchAll.do 접속 확인 >>>>>>");
    	//검색결과의 제품수를 가져오는 메소드실행후 변수에 담음
    	int searchListAllCnt = this.erpDAO.getSearchAllCnt(erpSearchDTO);
    	
    	// 페이징 처리 메소드 결과물을 변수에 담음
    	Map<String,Integer> map = Util.getPagingNos(searchListAllCnt, erpSearchDTO.getSelectPageNo(), erpSearchDTO.getRowCntPerPage(), 10);
    	erpSearchDTO.setSelectPageNo(map.get("selectPageNo"));
    	
    	// DB연동해 가져온 검색리스트
    	List<Map<String,String>> searchALLList = this.erpDAO.getSearcALLhList(erpSearchDTO);
    	
    	
        //*******************************************
        // [ModelAndView 객체] 생성하기
        // [ModelAndView 객체]에 [호출 JSP 페이지명]을 저장하기
        //*******************************************
        ModelAndView mav = new ModelAndView( );
        mav.setViewName("allSearch.jsp");
        // mav.addObject("boardDTO", boardDTO);
        mav.addObject("searchListAllCnt",searchListAllCnt);
        mav.addObject("searchALLList",searchALLList);
        mav.addObject("pagingNos",map);


        //*******************************************
        // [ModelAndView 객체] 리턴하기
        //*******************************************
        return mav;
    }
    // ==============================================================================
    // 재고관리 - 가전검색페이지 
    // 가전검색페이지 접속.
    @RequestMapping( value="/searchgajeon.do" )
    public ModelAndView goSearchGajeon( 
    		ERPSearchDTO erpSearchDTO
            
    ){
    	//검색결과의 제품수를 가져오는 메소드실행후 변수에 담음
    	int search_g_list_cnt = this.erpDAO.getSearch_G_List_Cnt(erpSearchDTO);
    	
    	// 페이징 처리 메소드 결과물을 변수에 담음
    	Map<String,Integer> map = Util.getPagingNos(search_g_list_cnt, erpSearchDTO.getSelectPageNo(), erpSearchDTO.getRowCntPerPage(), 10);
    	erpSearchDTO.setSelectPageNo(map.get("selectPageNo"));
    	
    	// DB연동해 가져온 검색리스트
    	List<Map<String,String>> g_searchList = this.erpDAO.getSearch_G_List(erpSearchDTO);
    	System.out.println(g_searchList);
    	System.out.println(search_g_list_cnt);
        //*******************************************
        // [ModelAndView 객체] 생성하기
        // [ModelAndView 객체]에 [호출 JSP 페이지명]을 저장하기
        //*******************************************
        ModelAndView mav = new ModelAndView( );
        mav.setViewName("g_search.jsp");
        // mav.addObject("boardDTO", boardDTO);
        mav.addObject("search_g_list_cnt",search_g_list_cnt);
        mav.addObject("g_searchList",g_searchList);
        mav.addObject("pagingNos",map);


        //*******************************************
        // [ModelAndView 객체] 리턴하기
        //*******************************************
        return mav;
    }  
    
    
    
    // 티비 검색페이지 접속.
    @RequestMapping( value="/searchtv.do" )
    public ModelAndView goSearchTV( 
    		ERPSearchDTO erpSearchDTO
            
    ){
    	//검색결과의 제품수를 가져오는 메소드실행후 변수에 담음
    	int search_t_list_cnt = this.erpDAO.getSearch_T_List_Cnt(erpSearchDTO);
    	
    	// 페이징 처리 메소드 결과물을 변수에 담음
    	Map<String,Integer> map = Util.getPagingNos(search_t_list_cnt, erpSearchDTO.getSelectPageNo(), erpSearchDTO.getRowCntPerPage(), 10);
    	erpSearchDTO.setSelectPageNo(map.get("selectPageNo"));
    	
    	// DB연동해 가져온 검색리스트
    	List<Map<String,String>> t_searchList = this.erpDAO.getSearch_T_List(erpSearchDTO);
    	System.out.println("searchtv.do 리스트 ==>>> "+t_searchList.get(0));
    	
        //*******************************************
        // [ModelAndView 객체] 생성하기
        // [ModelAndView 객체]에 [호출 JSP 페이지명]을 저장하기
        //*******************************************
        ModelAndView mav = new ModelAndView( );
        mav.setViewName("t_search.jsp");
        // mav.addObject("boardDTO", boardDTO);
        mav.addObject("search_t_list_cnt",search_t_list_cnt);
        mav.addObject("t_searchList",t_searchList);
        mav.addObject("pagingNos",map);


        //*******************************************
        // [ModelAndView 객체] 리턴하기
        //*******************************************
        return mav;
    }
    
    
    
    // PC검색페이지 접속.
    @RequestMapping( value="/searchpc.do" )
    public ModelAndView goSearchPC( 
    		ERPSearchDTO erpSearchDTO
            
    ){
    	//검색결과의 제품수를 가져오는 메소드실행후 변수에 담음
    	int search_p_list_cnt = this.erpDAO.getSearch_P_List_Cnt(erpSearchDTO);
    	
    	// 페이징 처리 메소드 결과물을 변수에 담음
    	Map<String,Integer> map = Util.getPagingNos(search_p_list_cnt, erpSearchDTO.getSelectPageNo(), erpSearchDTO.getRowCntPerPage(), 10);
    	erpSearchDTO.setSelectPageNo(map.get("selectPageNo"));
    	System.out.println("map 안에 들었는것 확인 min_pageNo 리스트 ==>>> "+map.get("min_pageNo"));
    	System.out.println("map 안에 들었는것 확인 max_pageNo 리스트 ==>>> "+map.get("max_pageNo"));
    	System.out.println("map 안에 들었는것 확인 search_p_list_cnt 리스트 ==>>> "+search_p_list_cnt);
    	

    	// DB연동해 가져온 검색리스트
    	List<Map<String,String>> p_searchList = this.erpDAO.getSearch_P_List(erpSearchDTO);
    	System.out.println("searchpc.do 리스트 ==>>> "+p_searchList.get(0));
    	
    	
        //*******************************************
        // [ModelAndView 객체] 생성하기
        // [ModelAndView 객체]에 [호출 JSP 페이지명]을 저장하기
        //*******************************************
        ModelAndView mav = new ModelAndView( );
        mav.setViewName("p_search.jsp");
        // mav.addObject("boardDTO", boardDTO);
        mav.addObject("search_p_list_cnt",search_p_list_cnt);
        mav.addObject("p_searchList",p_searchList);
        mav.addObject("pagingNos",map);


        //*******************************************
        // [ModelAndView 객체] 리턴하기
        //*******************************************
        return mav;
    }
    
    
    
    // 모바일검색페이지 접속.
    @RequestMapping( value="/searchmobile.do" )
    public ModelAndView goSearchMobile( 
    		ERPSearchDTO erpSearchDTO
            
    ){
    	//검색결과의 제품수를 가져오는 메소드실행후 변수에 담음
    	int search_m_list_cnt = this.erpDAO.getSearch_M_List_Cnt(erpSearchDTO);
    	
    	// 페이징 처리 메소드 결과물을 변수에 담음
    	Map<String,Integer> map = Util.getPagingNos(search_m_list_cnt, erpSearchDTO.getSelectPageNo(), erpSearchDTO.getRowCntPerPage(), 10);
    	erpSearchDTO.setSelectPageNo(map.get("selectPageNo"));
    	
    	// DB연동해 가져온 검색리스트
    	List<Map<String,String>> m_searchList = this.erpDAO.getSearch_M_List(erpSearchDTO);
    	
    	
        //*******************************************
        // [ModelAndView 객체] 생성하기
        // [ModelAndView 객체]에 [호출 JSP 페이지명]을 저장하기
        //*******************************************
        ModelAndView mav = new ModelAndView( );
        mav.setViewName("m_search.jsp");
        // mav.addObject("boardDTO", boardDTO);
        mav.addObject("search_m_list_cnt",search_m_list_cnt);
        mav.addObject("m_searchList",m_searchList);
        mav.addObject("pagingNos",map);


        //*******************************************
        // [ModelAndView 객체] 리턴하기
        //*******************************************
        return mav;
    }
    
    

  //===================================================================================================================
  //===================================================================================================================
  //===================================================================================================================
    //입출력 접속 컨트롤러 메소드
    
    
    // 가전 재고관리 접속.
    @RequestMapping(value = "/g_stock_management.do")
    public ModelAndView go_G_Sstock_management() {
        ModelAndView mav = new ModelAndView();
        mav.setViewName("g_stock_in_out.jsp");
        return mav;
    }

    // TV 재고관리 접속.
    @RequestMapping(value = "/t_stock_management.do")
    public ModelAndView go_T_Sstock_management() {
        ModelAndView mav = new ModelAndView();
        mav.setViewName("t_stock_in_out.jsp");
        return mav;
    }
    // PC 재고관리 접속.
    @RequestMapping(value = "/p_stock_management.do")
    public ModelAndView go_P_Sstock_management() {
        ModelAndView mav = new ModelAndView();
        mav.setViewName("p_stock_in_out.jsp");
        return mav;
    }
    // 모바일 재고관리 접속.
    @RequestMapping(value = "/m_stock_management.do")
    public ModelAndView go_M_Sstock_management() {
        ModelAndView mav = new ModelAndView();
        mav.setViewName("m_stock_in_out.jsp");
        return mav;
    }
    //===================================================================================================================
    //===================================================================================================================
    //===================================================================================================================   
    
    
    //===================================================================================================================
    //===================================================================================================================
    //===================================================================================================================
      //통계자료페이지 이동 컨트롤러 메소드
    
    // 통계화면 접속.
    @RequestMapping(value = "/statistics.do")
    public ModelAndView goStatistics() {
        ModelAndView mav = new ModelAndView();
        mav.setViewName("statistics.jsp");
        return mav;
    }
    // 가전통계화면 접속.
    @RequestMapping(value = "/g_statistics.do")
    public ModelAndView go_G_Statistics() {
        ModelAndView mav = new ModelAndView();
        mav.setViewName("g_statistics.jsp");
        return mav;
    }
    
    // TV통계화면 접속.
    @RequestMapping(value = "/t_statistics.do")
    public ModelAndView go_T_Statistics() {
        ModelAndView mav = new ModelAndView();
        mav.setViewName("t_statistics.jsp");
        return mav;
    }
    // PC화면 접속.
    @RequestMapping(value = "/p_statistics.do")
    public ModelAndView go_P_Statistics() {
        ModelAndView mav = new ModelAndView();
        mav.setViewName("p_statistics.jsp");
        return mav;
    }
    // 모바일화면 접속.
    @RequestMapping(value = "/m_statistics.do")
    public ModelAndView go_M_Statistics() {
        ModelAndView mav = new ModelAndView();
        mav.setViewName("m_statistics.jsp");
        return mav;
    }


















    // ==============================================================================
    
    
    //새 물품 입력
    @RequestMapping( 
        value="/itemRegProc.do"
        ,method = RequestMethod.POST
        ,produces = "application/json;charset=UTF8"
    )
    @ResponseBody
    public Map<String, String> insertErp( 
        ERPDTO erpDTO
        ,@RequestParam("img") MultipartFile multi
    ){

        //*******************************************
        // 업로드 파일의 크기와 확장자 체크하기
        //*******************************************
        // 만약에 업로드된 파일이 있으면
        if( multi.isEmpty()==false ) {
            // 만약에 업로드된 파일의 크기가 1000000 byte(=1000kb) 보다 크면
            if( multi.getSize()>1000000 ) {
                Map<String,String> map = new HashMap<String,String>();
                map.put( "erpRegCnt", "0" );
                map.put( "msg","업로드 파일이 1000kb 보다크면 안됩니다." );
                return map;
            }
            // 만약에 업로드된 파일의 확장자가 이미지 확장자가 아니면
            String fileName = multi.getOriginalFilename();
            if( fileName.endsWith(".jpg")==false && fileName.endsWith(".gif")==false&& fileName.endsWith(".png")==false ) {
                Map<String,String> map = new HashMap<String,String>();
                map.put( "erpRegCnt", "0" );
                map.put( "msg", "이미지 파일이 아닙니다." );
                return map;
            }
        }

        System.out.println( "itemRegProc 시작" );
        
        String fileName = multi.getOriginalFilename();
        
        System.out.println( "===========================================" );
        System.out.println( "pic       => " + fileName              );    	    
        System.out.println( "Item_code => " + erpDTO.getG_item_code() );
        System.out.println( "Item_name => " + erpDTO.getG_item_name() );
        System.out.println( "brand     => " + erpDTO.getBrand_code() );      
        System.out.println( "bigDivision => " + erpDTO.getCategory_code() );
        System.out.println( "g_sub_category_code => " + erpDTO.getG_sub_category_code() );
        System.out.println( "getG_sub_sub_category_code => " + erpDTO.getG_sub_sub_category_code() );
        System.out.println( "============" );      	    
        System.out.println( "power_consum => " + erpDTO.getG_power_consum() );
        System.out.println( "build_day    => " + erpDTO.getG_build_day()    );
        System.out.println( "energy_grade => " + erpDTO.getEnergy_grade_code() );
        System.out.println( "color        => " + erpDTO.getColor_code()        );
        System.out.println( "getG_item_sizex     => " + erpDTO.getG_item_size_x()     );
        System.out.println( "discontinued => " + erpDTO.getG_discontinued() );	    
        System.out.println( "===========================================" );
            
        //*******************************************
        // 게시판 등록 성공여부가 저장된 변수 선언. 1이 저장되면 성공했다는 의미
        // 유효성 체크 에러 메시지 저장할 변수 msg 선언.
        //*******************************************
        int erpRegCnt = 0;
        
            try {
                erpRegCnt = this.erpService.insertErp(erpDTO, multi);
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        
            System.out.println( "BoardController.insertBoard 메소드 호출 성공 " );
        
        Map<String, String> map = new HashMap<String,String>();
        map.put("erpRegCnt", erpRegCnt+"");
        
        System.out.println( "itemRegProc 종료" );
        return map;
    }


    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    // /itemUpDelProc.do 접속 시 호출되는 메소드 선언
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm

    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    // 가상주소 /itemUpDelProc.do 로 접근하면 호출되는 메소드 선언하기
    // 메소드 앞에 
    // @RequestMapping(~,~,produces = "application/json;charset=UTF8") 하고
    // @ResponseBody 가 붙으면 리턴하는 데이터가 클라이언트에게 전송된다.  
    // ModelAndView 객체를 리턴하면 JSP 를 호출하고 그 JSP 페이지의 실행결과인 HTML 문서가 응답 메시지에 저장되어 전송되지만  
    // @RequestMapping(~) 와 @ResponseBody 가 붙으면 리턴하는 데이터가 JSON 형태로 응답메시지에 저장되어 전송된다.  
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    @RequestMapping( 
        value="/itemUpDelProc.do"
        ,method = RequestMethod.POST
        ,produces = "application/json;charset=UTF8"
    )
    @ResponseBody
    public Map<String,String> itemUpDelProc( 
        // ***********************************************
        // 파라미터값을 저장할 [ERPDTO 객체]를 매개변수로 선언
        // ***********************************************
        ERPDTO erpDTO

        // **********************************************
        // <input type=file name=img> 입력양식의 파일이 저장된 MultipartFile 객체 저장 매개변수 선언.
        // <주의> 업로드된 파일이 없어도 MultipartFile 객체는 생성되어 들어온다. 
        // **********************************************
        // ,@RequestParam("img") MultipartFile multi

        // ***********************************************
        // "upDel" 라는 파라미터명의 파라미터값이 저장된 매개변수 upDel 선언
        // ***********************************************
        ,@RequestParam(value = "upDel") String upDel
        ,@RequestParam(value = "paramV") String paramV

        // **********************************************
        // Error 객체를 관리하는 BindingResult 객체가 저장되어 들어오는 매개변수 bindingResult 선언
        // 유효성 검사결과를 관리
        // **********************************************
        , BindingResult bindingResult
    )throws Exception{


        System.out.println("컨트롤러에서 upDel 확인 ==>   " + upDel);
        // **********************************************
        // 업로드 파일의 크기와 확장자 체크하기
        // **********************************************
        // 만약에 업로드된 파일이 있으면
        // if( multi.isEmpty()==false ){
     
        //     // 만약에 업로드된 파일의 크기가 1000000 byte(=1000kb) 보다 크면 
        //     if( multi.getSize()>10000000){
        //         Map<String,String> map = new HashMap<String,String>();
        //         map.put("itemUpDelCnt", "0");
        //         map.put("msg", "업로드 파일이 10mb 보다 크면 업로드 할 수 없습니다.");
        //         return map;
        //     }

        //     // 만약에 업로드된 파일의 확장자가 이미지 확장자가 아니면 
        //     String fileName = multi.getOriginalFilename();

        //     System.out.println("파일이름 확인하기 =>>> " + fileName);

        //     // 아래 세개의 조건문은 같은 코드이다.  
        //     // if( !(fileName.endsWith(".jpg") || fileName.endsWith(".gif") || fileName.endsWith(".png")) ){
        //     // if( !fileName.endsWith(".jpg") && !fileName.endsWith(".gif") && !fileName.endsWith(".png") ){
        //     if( fileName.endsWith(".jpg")==false && fileName.endsWith(".gif")==false && fileName.endsWith(".png")==false ){
        //         Map<String,String> map = new HashMap<String,String>();
        //         map.put("itemUpDelCnt", "0");
        //         map.put("msg", "이미지 파일 형식이 아닙니다.");
        //         return map;
        //     }
            
        // }

        // **********************************************
        // 수정 또는 삭제 행의 적용 개수 저장할 변수 선언 
        // 유효성 체크 시 경고메시지 저장할 변수 msg 선언.
        // **********************************************
        int itemUpDelCnt = 0;
        String msg ="";
        // **********************************************
        // 만약 제품 삭제 모드이면
        // **********************************************
        if( upDel.equals("del") ){

            System.out.println( "====================" );

            // 삭제 실행하고 삭제 적용행의 개수 얻기
            itemUpDelCnt = this.erpService.deleteErp(erpDTO);
            System.out.println( "BoardController 에서 /boardUpDelProc.do 접속." );
            System.out.println( "삭제할 PK 번호 호출 getB_no => " + erpDTO.getCategory_code() );
        }

        // **********************************************
        // 만약 제품 수정 모드이면 수정 실행하고 수정 적용행의 개수 얻기
        // **********************************************
        else if(upDel.equals("up")){

            // *********************************************
            // check_BoardDTO 메소드를 호출하여 [유효성 체크]하고 경고문자 얻기
            // *********************************************
            // check_BoardDTO 메소드를 호출하여 [유효성 체크]하고 [에러 메시지] 문자 얻기
            // msg = check_BoardDTO( erpDTO, bindingResult );  
            // 만약 msg 안에 "" 가 저장되어 있으면, 즉, 유효성 체크를 통과했으면  
            if( msg.equals("") ){
                // -----------------------------------------
                // ERPServiceImpl 객체의 updateBoard 라는 메소드 호출로
                // 게시판 수정 실행하고 수정 적용행의 개수 얻기
                // -----------------------------------------
                // itemUpDelCnt = this.erpService.updateBoard(erpDTO,multi);
 
                // System.out.println( "멀티 확인 ==>>>" + multi);


                System.out.println( "유효성체크 통과." );
            }
        }
        //*******************************************
        // HashMap<String,String> 객체 생성하기
        // HashMap<String,String> 객체에 게시판 수정.삭제 성공행의 개수 저장하기
        // HashMap<String,String> 객체에 유효성 체크 시 메시지 저장하기
        // HashMap<String,String> 객체 리턴하기
        //*******************************************
        Map<String,String> map = new HashMap<String,String>();
        map.put("boardUpDelCnt", itemUpDelCnt+"");
        map.put("msg", msg);
        System.out.println( "유효성체크 확인 => " + msg );

        return map;
    }






    //============================================================
    // 게시판 접속.
    // boardList.do로 바로 접속하게함.  
    // @RequestMapping(value = "/board.do")
    // public ModelAndView goBoard() {
    //     System.out.println("ERPController 쪽, ==> board.do 접속!@#!@#");

    //     ModelAndView mav = new ModelAndView();
    //     mav.setViewName("board.jsp");
    //     return mav;
    // }
    //============================================================
    
    

    

    // 통계화면 접속.
    // @RequestMapping(value = "/statistics.do")
    // public ModelAndView goStatistics() {
    //     ModelAndView mav = new ModelAndView();
    //     mav.setViewName("statistics.jsp");
    //     return mav;
    // }

    // 재고관리 접속.
    @RequestMapping(value = "/stock_management.do")
    public ModelAndView goSstock_management() {
        ModelAndView mav = new ModelAndView();
        mav.setViewName("stock_in_out.jsp");
        return mav;
    }

    // 재고관리 안에서 가전 검색.
    @RequestMapping(value = "/jaego_search.do")
    public ModelAndView goJaego_search() {
        ModelAndView mav = new ModelAndView();
        mav.setViewName("jaego_search.jsp");
        return mav;
    }



}
