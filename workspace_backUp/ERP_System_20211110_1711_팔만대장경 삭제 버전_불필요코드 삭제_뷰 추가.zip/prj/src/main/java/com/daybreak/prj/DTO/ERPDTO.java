package com.daybreak.prj.DTO;

import java.util.List;
import java.util.Map;

public class ERPDTO {
	
	// ===================================================
	// 검색 및 공용 DTO
	// g_ 들어간것은 무시. 공용으로 사용하는 것들이므로...
	private String g_pic ;
	private String g_sub_category_code;
	private String g_sub_sub_category_code;
	private String category_code;
	private String brand_code;
	private String g_item_code;
	private String g_item_name;
	private String g_build_day;
	private String energy_grade_code;
	private String g_power_consum;
	private String color_code;
	private String g_item_size_x;
	private String g_item_size_y;
	private String g_item_size_z;
	private String g_discontinued ;
	// ===================================================
	
	// 수정, 삭제 할 때 그 대상 행의 아이템 코드를 잡아주는 paramV
	private String paramV;
	// 삭제 할 때 대상을 지칭하는 카테고리 코드 
	private String del_category_code;

	// ===================================================
	// 등록할때 사용하는 DTO
	private String reg_sub_category_code;
	private String reg_sub_sub_category_code;
	private String reg_category_code;
	private String reg_brand_code;
	private String reg_item_code;
	private String reg_item_name;
	private String reg_build_day;
	private String reg_energy_grade_code;
	private String reg_power_consum;
	private String reg_color_code;
	private String reg_item_size_x;
	private String reg_item_size_y;
	private String reg_item_size_z;
	private String reg_discontinued ;
	// ===================================================




	
	
	// ===================================================
	// 통계
	
	private List<Map<String,String>> g_sub_sub_color_best_ten_alllist;	// 가전 소분류 '색상 BEST 순위' 담은 리스트
	private List<Map<String,String>> t_sub_sub_color_best_ten_alllist;	// TV 소분류 '색상 BEST 순위' 담은 리스트
	private List<Map<String,String>> p_sub_sub_color_best_ten_alllist;	// PC 소분류 '색상 BEST 순위' 담은 리스트
	private List<Map<String,String>> m_sub_sub_color_best_ten_alllist;	// 모바일 소분류 '색상 BEST 순위' 담은 리스트
	
	
	private List<Map<String,String>> g_sub_sub_best_brand;				// 가전 소분류 '브랜드 BEST 순위' 담은 리스트
	private List<Map<String,String>> t_sub_sub_best_brand;				// TV 소분류 '브랜드 BEST 순위' 담은 리스트
	private List<Map<String,String>> p_sub_sub_best_brand;				// PC 소분류 '브랜드 BEST 순위' 담은 리스트
	private List<Map<String,String>> m_sub_sub_best_brand;				// 모바일 소분류 '브랜드 BEST 순위' 담은 리스트
	// ===================================================









	
	public String getG_pic() {
		return g_pic;
	}
	public void setG_pic(String g_pic) {
		this.g_pic = g_pic;
	}
	public String getG_sub_category_code() {
		return g_sub_category_code;
	}
	public void setG_sub_category_code(String g_sub_category_code) {
		this.g_sub_category_code = g_sub_category_code;
	}
	public String getG_sub_sub_category_code() {
		return g_sub_sub_category_code;
	}
	public void setG_sub_sub_category_code(String g_sub_sub_category_code) {
		this.g_sub_sub_category_code = g_sub_sub_category_code;
	}
	public String getCategory_code() {
		return category_code;
	}
	public void setCategory_code(String category_code) {
		this.category_code = category_code;
	}
	public String getBrand_code() {
		return brand_code;
	}
	public void setBrand_code(String brand_code) {
		this.brand_code = brand_code;
	}
	public String getG_item_code() {
		return g_item_code;
	}
	public void setG_item_code(String g_item_code) {
		this.g_item_code = g_item_code;
	}
	public String getG_item_name() {
		return g_item_name;
	}
	public void setG_item_name(String g_item_name) {
		this.g_item_name = g_item_name;
	}
	public String getG_build_day() {
		return g_build_day;
	}
	public void setG_build_day(String g_build_day) {
		this.g_build_day = g_build_day;
	}
	public String getEnergy_grade_code() {
		return energy_grade_code;
	}
	public void setEnergy_grade_code(String energy_grade_code) {
		this.energy_grade_code = energy_grade_code;
	}
	public String getG_power_consum() {
		return g_power_consum;
	}
	public void setG_power_consum(String g_power_consum) {
		this.g_power_consum = g_power_consum;
	}
	public String getColor_code() {
		return color_code;
	}
	public void setColor_code(String color_code) {
		this.color_code = color_code;
	}
	public String getG_item_size_x() {
		return g_item_size_x;
	}
	public void setG_item_size_x(String g_item_size_x) {
		this.g_item_size_x = g_item_size_x;
	}
	public String getG_item_size_y() {
		return g_item_size_y;
	}
	public void setG_item_size_y(String g_item_size_y) {
		this.g_item_size_y = g_item_size_y;
	}
	public String getG_item_size_z() {
		return g_item_size_z;
	}
	public void setG_item_size_z(String g_item_size_z) {
		this.g_item_size_z = g_item_size_z;
	}
	public String getG_discontinued() {
		return g_discontinued;
	}
	public void setG_discontinued(String g_discontinued) {
		this.g_discontinued = g_discontinued;
	}
	public String getParamV() {
		return paramV;
	}
	public void setParamV(String paramV) {
		this.paramV = paramV;
	}
	public String getReg_sub_category_code() {
		return reg_sub_category_code;
	}
	public void setReg_sub_category_code(String reg_sub_category_code) {
		this.reg_sub_category_code = reg_sub_category_code;
	}
	public String getReg_sub_sub_category_code() {
		return reg_sub_sub_category_code;
	}
	public void setReg_sub_sub_category_code(String reg_sub_sub_category_code) {
		this.reg_sub_sub_category_code = reg_sub_sub_category_code;
	}
	public String getReg_category_code() {
		return reg_category_code;
	}
	public void setReg_category_code(String reg_category_code) {
		this.reg_category_code = reg_category_code;
	}
	public String getReg_brand_code() {
		return reg_brand_code;
	}
	public void setReg_brand_code(String reg_brand_code) {
		this.reg_brand_code = reg_brand_code;
	}
	public String getReg_item_code() {
		return reg_item_code;
	}
	public void setReg_item_code(String reg_item_code) {
		this.reg_item_code = reg_item_code;
	}
	public String getReg_item_name() {
		return reg_item_name;
	}
	public void setReg_item_name(String reg_item_name) {
		this.reg_item_name = reg_item_name;
	}
	public String getReg_build_day() {
		return reg_build_day;
	}
	public void setReg_build_day(String reg_build_day) {
		this.reg_build_day = reg_build_day;
	}
	public String getReg_energy_grade_code() {
		return reg_energy_grade_code;
	}
	public void setReg_energy_grade_code(String reg_energy_grade_code) {
		this.reg_energy_grade_code = reg_energy_grade_code;
	}
	public String getReg_power_consum() {
		return reg_power_consum;
	}
	public void setReg_power_consum(String reg_power_consum) {
		this.reg_power_consum = reg_power_consum;
	}
	public String getReg_color_code() {
		return reg_color_code;
	}
	public void setReg_color_code(String reg_color_code) {
		this.reg_color_code = reg_color_code;
	}
	public String getReg_item_size_x() {
		return reg_item_size_x;
	}
	public void setReg_item_size_x(String reg_item_size_x) {
		this.reg_item_size_x = reg_item_size_x;
	}
	public String getReg_item_size_y() {
		return reg_item_size_y;
	}
	public void setReg_item_size_y(String reg_item_size_y) {
		this.reg_item_size_y = reg_item_size_y;
	}
	public String getReg_item_size_z() {
		return reg_item_size_z;
	}
	public void setReg_item_size_z(String reg_item_size_z) {
		this.reg_item_size_z = reg_item_size_z;
	}
	public String getReg_discontinued() {
		return reg_discontinued;
	}
	public void setReg_discontinued(String reg_discontinued) {
		this.reg_discontinued = reg_discontinued;
	}
	public String getDel_category_code() {
		return del_category_code;
	}
	public void setDel_category_code(String del_category_code) {
		this.del_category_code = del_category_code;
	}
	public List<Map<String, String>> getG_sub_sub_color_best_ten_alllist() {
		return g_sub_sub_color_best_ten_alllist;
	}
	public void setG_sub_sub_color_best_ten_alllist(List<Map<String, String>> g_sub_sub_color_best_ten_alllist) {
		this.g_sub_sub_color_best_ten_alllist = g_sub_sub_color_best_ten_alllist;
	}
	public List<Map<String, String>> getT_sub_sub_color_best_ten_alllist() {
		return t_sub_sub_color_best_ten_alllist;
	}
	public void setT_sub_sub_color_best_ten_alllist(List<Map<String, String>> t_sub_sub_color_best_ten_alllist) {
		this.t_sub_sub_color_best_ten_alllist = t_sub_sub_color_best_ten_alllist;
	}
	public List<Map<String, String>> getP_sub_sub_color_best_ten_alllist() {
		return p_sub_sub_color_best_ten_alllist;
	}
	public void setP_sub_sub_color_best_ten_alllist(List<Map<String, String>> p_sub_sub_color_best_ten_alllist) {
		this.p_sub_sub_color_best_ten_alllist = p_sub_sub_color_best_ten_alllist;
	}
	public List<Map<String, String>> getM_sub_sub_color_best_ten_alllist() {
		return m_sub_sub_color_best_ten_alllist;
	}
	public void setM_sub_sub_color_best_ten_alllist(List<Map<String, String>> m_sub_sub_color_best_ten_alllist) {
		this.m_sub_sub_color_best_ten_alllist = m_sub_sub_color_best_ten_alllist;
	}
	public List<Map<String, String>> getG_sub_sub_best_brand() {
		return g_sub_sub_best_brand;
	}
	public void setG_sub_sub_best_brand(List<Map<String, String>> g_sub_sub_best_brand) {
		this.g_sub_sub_best_brand = g_sub_sub_best_brand;
	}
	public List<Map<String, String>> getT_sub_sub_best_brand() {
		return t_sub_sub_best_brand;
	}
	public void setT_sub_sub_best_brand(List<Map<String, String>> t_sub_sub_best_brand) {
		this.t_sub_sub_best_brand = t_sub_sub_best_brand;
	}
	public List<Map<String, String>> getP_sub_sub_best_brand() {
		return p_sub_sub_best_brand;
	}
	public void setP_sub_sub_best_brand(List<Map<String, String>> p_sub_sub_best_brand) {
		this.p_sub_sub_best_brand = p_sub_sub_best_brand;
	}
	public List<Map<String, String>> getM_sub_sub_best_brand() {
		return m_sub_sub_best_brand;
	}
	public void setM_sub_sub_best_brand(List<Map<String, String>> m_sub_sub_best_brand) {
		this.m_sub_sub_best_brand = m_sub_sub_best_brand;
	}






	





































	// ===================================================================================
    // 게시판 DTO 참고용 주석. 삭제하지마시고, 그냥 코드들 참고하시고 위에 코딩 해주세요.
    // ===================================================================================
/*
	private int b_no;
    private String subject;
    private String writer;
    private String reg_date;
    private int readcount;
    private String content;

	private String pic;

    private String is_del;

    private String pwd;
    private String email;
    private int group_no;
    private int print_no;
    private int print_level;
    
    public int getB_no() {
		return b_no;
	}
	public void setB_no(int b_no) {
		this.b_no = b_no;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getReg_date() {
		return reg_date;
	}
	public void setReg_date(String reg_date) {
		this.reg_date = reg_date;
	}
	public int getReadcount() {
		return readcount;
	}
	public void setReadcount(int readcount) {
		this.readcount = readcount;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getPic() {
		return pic;
	}
	public void setPic(String pic) {
		this.pic = pic;
	}
	public String getIs_del() {
		return is_del;
	}
	public void setIs_del(String is_del) {
		this.is_del = is_del;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getGroup_no() {
		return group_no;
	}
	public void setGroup_no(int group_no) {
		this.group_no = group_no;
	}
	public int getPrint_no() {
		return print_no;
	}
	public void setPrint_no(int print_no) {
		this.print_no = print_no;
	}
	public int getPrint_level() {
		return print_level;
	}
	public void setPrint_level(int print_level) {
		this.print_level = print_level;
	}
*/
    
}
