// 이 변수는 2개의 함수에서 사용해야하므로 전역변수로 선언했습니다.
var sortId;

$(document).ready(function () {
  // 페이지가 로딩되었을때 한번 실행해서
  // 이벤트 걸어주기.
  successSearchEvent();
});

// search 혹은 모두검색이 완료되었을때(ajax success 콜백함수)
//이 함수를 실행하면 됩니다.
function successSearchEvent() {
  sortRow();
  //  sort클래스의 hidden 태그에서 값 가져와서,
  var sort = $(".sort").val();
  // sortId 가 STOCK 이거나 POWER_CONSUM 이면 TO_NUMBER() 없애기
  if (sortId === "STOCK" || sortId === "POWER_CONSUM" || sortId === "STOCK_IN_CNT" || sortId === "STOCK_OUT_CNT") {
    if (sort.indexOf("asc") > 0) {
      sort = `${sortId} asc`;
    }
    if (sort.indexOf("desc") > 0) {
      sort = `${sortId} desc`;
    }
  }
  // 어떤 행에서 asc/sesc 솔트를 했는지 확인하고 화살표 넣어주기.
  if (sort == `${sortId} asc`) {
    $(`#${sortId}`).append("▲");
  } else if (sort == `${sortId} desc`) {
    $(`#${sortId}`).append("▼");
  }
}

// 행sort function
function sortRow() {
  // sort 해서 검색하기 전에 페이지 번호 초기화 해주기.
  $(".selectPageNo").val(1);
  // sort할 행은 sortRow 클래스를 가지고 있음.
  var obj = $(".sortRow");
  // sort행 마우스 커서 포인터로 바꾸기.
  obj.css("cursor", "pointer");
  obj.click(function () {
    var obj = $(this);
    var text = $.trim(obj.text());
    sortId = $.trim(obj.attr("id"));
    var sortTemp;
    if (sortId === "STOCK" || sortId === "POWER_CONSUM" || sortId === "STOCK_IN_CNT" || sortId === "STOCK_OUT_CNT") {
      sortTemp = sortId;
      sortId = `TO_NUMBER(${sortId})`;
    }
    // sortID 에 따라 쿼리 바꾸기.
    if (text.indexOf("▲") >= 0) {
      $(".sort").val("");
    } else if (text.indexOf("▼") >= 0) {
      $(".sort").val(`${sortId} asc`);
    } else {
      $(".sort").val(`${sortId} desc`);
    }
    if (sortTemp === "STOCK" || sortTemp === "POWER_CONSUM" || sortTemp == "STOCK_IN_CNT" || sortTemp === "STOCK_OUT_CNT") {
      sortId = sortTemp;
    }
    search();
  });
}
