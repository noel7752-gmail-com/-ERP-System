package com.daybreak.prj.DAO;

import java.util.List;
import java.util.Map;

import com.daybreak.prj.DTO.ERPDTO;
import com.daybreak.prj.DTO.ERPHomeDTO;
import com.daybreak.prj.DTO.ERPSearchDTO;
import com.daybreak.prj.DTO.ERPStockDTO;

public interface ERPDAO {
	
	// =====================================================================
	// 리스트 가져오는 부분.
	List<Map<String,String>> getSearcALLhList(ERPSearchDTO erpSearchDTO);

    // 재고관리 카테고리 리스트 가져오는 부분(가전) 입고
	List<Map<String,String>> get_g_stock_manage(ERPSearchDTO erpSearchDTO);
    // 재고관리 카테고리 리스트 가져오는 부분(가전) 출고
	List<Map<String,String>> get_g_stock_manage_out(ERPSearchDTO erpSearchDTO);

    
    // 재고관리 카테고리 리스트 가져오는 부분(pc) 입고
	List<Map<String,String>> get_p_stock_manage(ERPSearchDTO erpSearchDTO);
    // 재고관리 카테고리 리스트 가져오는 부분(pc) 출고
	List<Map<String,String>> get_p_stock_manage_out(ERPSearchDTO erpSearchDTO);

    // 재고관리 카테고리 리스트 가져오는 부분(모바일) 입고
	List<Map<String,String>> get_m_stock_manage(ERPSearchDTO erpSearchDTO);         
    // 재고관리 카테고리 리스트 가져오는 부분(모바일) 출고
	List<Map<String,String>> get_m_stock_manage_out(ERPSearchDTO erpSearchDTO);	
    
    // 재고관리 카테고리 리스트 가져오는 부분(TV) 입고 
	List<Map<String,String>> get_t_stock_manage(ERPSearchDTO erpSearchDTO);
    // 재고관리 카테고리 리스트 가져오는 부분(TV) 출고
	List<Map<String,String>> get_t_stock_manage_out(ERPSearchDTO erpSearchDTO);
	// =====================================================================


	int getSearchAllCnt(ERPSearchDTO erpSearchDTO);


    // ===========================================================================
    // 재고관리(입고) 카테고리 총개수 가져오는 부분(가전)
	int get_stock_SearchAllCnt(ERPSearchDTO erpSearchDTO);
    // 재고관리(출고) 카테고리 총개수 가져오는 부분(가전)
	int get_out_stock_SearchAllCnt(ERPSearchDTO erpSearchDTO);

    // 재고관리(입고) 카테고리 총개수 가져오는 부분(pc)
	int get_p_stock_SearchAllCnt(ERPSearchDTO erpSearchDTO);
    // 재고관리(출고) 카테고리 총개수 가져오는 부분(pc)
	int get_p_out_stock_SearchAllCnt(ERPSearchDTO erpSearchDTO);

    // 재고관리(입고) 카테고리 총개수 가져오는 부분(모바일)
	int get_m_stock_SearchAllCnt(ERPSearchDTO erpSearchDTO);	                     
    // 재고관리(출고) 카테고리 총개수 가져오는 부분(모바일)
	int get_m_out_stock_SearchAllCnt(ERPSearchDTO erpSearchDTO);	
    
    // 재고관리(입고) 카테고리 총개수 가져오는 부분(TV)
	int get_t_stock_SearchAllCnt(ERPSearchDTO erpSearchDTO);
    // 재고관리(출고) 카테고리 총개수 가져오는 부분(TV)
	int get_t_out_stock_SearchAllCnt(ERPSearchDTO erpSearchDTO);
    // ===========================================================================

    
    
	// =====================================================================

	// =====================================================================
    // 입력하는 메소드 선언
    int insertErp(ERPDTO erpDTO);
	// =====================================================================

	// =====================================================================
	// 게시판 이미지 이름 가져오는  메소드 선언
	public String G_pic(ERPDTO erpDTO);
	// =====================================================================

	// =====================================================================
    // 삭제할 제품 존재개수 리턴
    public int get_del_ERPCnt(ERPDTO erpDTO);
	// =====================================================================

	// =====================================================================
    // 삭제후 삭제 적용행의 개수 리턴
    public int delete_erp(ERPDTO erpDTO);
	// =====================================================================

	// =====================================================================
    // input 쪽 삭제 적용 개수 리턴 
    public int delete_input(ERPDTO erpDTO);
	// =====================================================================

	// =====================================================================
    // output 쪽 삭제 적용 개수 리턴 
    public int delete_output(ERPDTO erpDTO);
	// =====================================================================

	// =====================================================================
    // 수정 적용 개수 리턴 
	public int getUpdateItemCnt(ERPDTO erpDTO);
	// =====================================================================



    //============================================================================
	//각 재고관리 카테고리별 검색리스트 가져오는 메소드
	public List<Map<String,String>> getSearch_G_List(ERPSearchDTO erpSearchDTO);

	public List<Map<String,String>> getSearch_T_List(ERPSearchDTO erpSearchDTO);
	
	public List<Map<String,String>> getSearch_P_List(ERPSearchDTO erpSearchDTO);
	
	public List<Map<String,String>> getSearch_M_List(ERPSearchDTO erpSearchDTO);
	//============================================================================
	//각 카테고리별 갬색개수를 가져오는 메소드
	int getSearch_G_List_Cnt(ERPSearchDTO erpSearchDTO);
	int getSearch_T_List_Cnt(ERPSearchDTO erpSearchDTO);
	int getSearch_P_List_Cnt(ERPSearchDTO erpSearchDTO);
	int getSearch_M_List_Cnt(ERPSearchDTO erpSearchDTO);
	//============================================================================


	//=======================================================
	// 통합검색쪽 검색 조건(셀렉스 및 체크박스) 값 가져오는 메소드
	
	// 대 카테고리
	List<Map<String,String>> get_Category_List();
	
	//가전 종류 카테고리
	List<Map<String,String>> get_Gajeon_Category_List();
	List<Map<String,String>> get_Season_Gajeon_Category_List();
	List<Map<String,String>> get_kitchen_Gajeon_Category_List();
	List<Map<String,String>> get_Life_Gajeon_Category_List();
	
	//TV 종류 카테고리
	List<Map<String,String>> get_TV_Category_List();
	
	//PC 종류 카테고리
	List<Map<String,String>> get_PC_Category_List();
	List<Map<String,String>> get_Gaming_PC_Category_List();
	List<Map<String,String>> get_Office_PC_Category_List();
	
	//모바일 종류 카테고리
	List<Map<String,String>> get_Mobile_Category_List();
	List<Map<String,String>> get_Phone_Category_List();
	List<Map<String,String>> get_Tablet_Category_List();
	//=======================================================




	//============================================================================================================================================
	// 검색화면에서 뿌려지는 각종 리스트들 나머지, 전부,   
    // 각 세부 및 색상 브랜드 카테고리 리스트 담아서 다 가져옴. 
	//=======================================================	
	
	// 에너지소비등급 리스트 가져오기
	List<Map<String,String>> get_Energy_Grade_List();
	
	// 브랜드, 컬러 리스트 가져오는 메소드
	
	// 가전쪽 검색조건 브랜드, 컬러 리스트 가져오기
	List<Map<String,String>> get_G_Brand_List();
	List<Map<String,String>> get_G_Color_List();

	List<Map<String,String>> get_G_Season_Color_List();
	List<Map<String,String>> get_G_Season_Brand_List();
	List<Map<String,String>> get_G_Season_Aircon_Color_List();
	List<Map<String,String>> get_G_Season_Aircon_Brand_List();
	List<Map<String,String>> get_G_Season_Airfresh_Brand_List();
	List<Map<String,String>> get_G_Season_Airfresh_Color_List();
	List<Map<String,String>> get_G_Season_Hitter_Brand_List();
	List<Map<String,String>> get_G_Season_Hitter_Color_List();
	List<Map<String,String>> get_G_Season_Aircon_Airfresh_Color_List();
	List<Map<String,String>> get_G_Season_Aircon_Airfresh_Brand_List();
	List<Map<String,String>> get_G_Season_Aircon_Hitter_Color_List();
	List<Map<String,String>> get_G_Season_Aircon_Hitter_Brand_List();
	List<Map<String,String>> get_G_Season_Airfresh_Hitter_Color_List();
	List<Map<String,String>> get_G_Season_Airfresh_Hitter_Brand_List();
	
	
	
	List<Map<String,String>> get_G_Kitchen_Color_List();
	List<Map<String,String>> get_G_Kitchen_Brand_List();
	List<Map<String,String>> get_G_Kitchen_Fridge_Color_List();
	List<Map<String,String>> get_G_Kitchen_Fridge_Brand_List();
	List<Map<String,String>> get_G_Kitchen_Cooker_Brand_List();
	List<Map<String,String>> get_G_Kitchen_Cooker_Color_List();
	List<Map<String,String>> get_G_Kitchen_Airfryer_Brand_List();
	List<Map<String,String>> get_G_Kitchen_Airfryer_Color_List();
	List<Map<String,String>> get_G_Kitchen_Fridge_Cooker_Color_List();
	List<Map<String,String>> get_G_Kitchen_Fridge_Cooker_Brand_List();
	List<Map<String,String>> get_G_Kitchen_Fridge_Airfryer_Color_List();
	List<Map<String,String>> get_G_Kitchen_Fridge_Airfryer_Brand_List();
	List<Map<String,String>> get_G_Kitchen_Cooker_Airfryer_Color_List();
	List<Map<String,String>> get_G_Kitchen_Cooker_Airfryer_Brand_List();
	
	
	
	List<Map<String,String>> get_G_Life_Color_List();
	List<Map<String,String>> get_G_Life_Brand_List();
	List<Map<String,String>> get_G_Life_Washer_Color_List();
	List<Map<String,String>> get_G_Life_Washer_Brand_List();
	List<Map<String,String>> get_G_Life_Dryer_Color_List();
	List<Map<String,String>> get_G_Life_Dryer_Brand_List();
	List<Map<String,String>> get_G_Life_Cleaner_Color_List();
	List<Map<String,String>> get_G_Life_Cleaner_Brand_List();
	List<Map<String,String>> get_G_Life_Washer_Dryer_Color_List();
	List<Map<String,String>> get_G_Life_Washer_Dryer_Brand_List();
	List<Map<String,String>> get_G_Life_Washer_Cleaner_Color_List();
	List<Map<String,String>> get_G_Life_Washer_Cleaner_Brand_List();
	List<Map<String,String>> get_G_Life_Dryer_Cleaner_Color_List();
	List<Map<String,String>> get_G_Life_Dryer_Cleaner_Brand_List();
	
	
	
	// TV 쪽 검색조건 브랜드, 컬러 리스트 가져오기
	List<Map<String,String>> get_T_Brand_List();
	List<Map<String,String>> get_T_Color_List();
	List<Map<String,String>> get_T_QLED_Color_List();
	List<Map<String,String>> get_T_QLED_Brand_List();
	List<Map<String,String>> get_T_MINILED_Color_List();
	List<Map<String,String>> get_T_MINILED_Brand_List();
	List<Map<String,String>> get_T_OLED_Color_List();
	List<Map<String,String>> get_T_OLED_Brand_List();
	
	
	
	
	// PC 쪽 검색조건 브랜드, 컬러 리스트 가져오기
	List<Map<String,String>> get_P_Brand_List();
	List<Map<String,String>> get_P_Color_List();
	List<Map<String,String>> get_P_Desktop_Brand_List();
	List<Map<String,String>> get_P_Desktop_Color_List();
	List<Map<String,String>> get_P_Notebook_Brand_List();
	List<Map<String,String>> get_P_Notebook_Color_List();
	List<Map<String,String>> get_P_Desktop_Office_Brand_List();
	List<Map<String,String>> get_P_Desktop_Office_Color_List();
	List<Map<String,String>> get_P_Desktop_Gaming_Brand_List();
	List<Map<String,String>> get_P_Desktop_Gaming_Color_List();
	List<Map<String,String>> get_P_Notebook_Business_Brand_List();
	List<Map<String,String>> get_P_Notebook_Business_Color_List();
	List<Map<String,String>> get_P_Notebook_Gaming_Brand_List();
	List<Map<String,String>> get_P_Notebook_Gaming_Color_List();
	
	
	
	
	//모바일 쪽 검새조건 브랜드, 컬러 리스트 가져오기
	List<Map<String,String>> get_M_Brand_List();
	List<Map<String,String>> get_M_Color_List();
	List<Map<String,String>> get_M_Phone_Brand_List();
	List<Map<String,String>> get_M_Phone_Color_List();
	List<Map<String,String>> get_M_Tablet_Brand_List();
	List<Map<String,String>> get_M_Tablet_Color_List();
	List<Map<String,String>> get_M_Phone_Samsung_Brand_List();
	List<Map<String,String>> get_M_Phone_Samsung_Color_List();
	List<Map<String,String>> get_M_Phone_Apple_Brand_List();
	List<Map<String,String>> get_M_Phone_Apple_Color_List();
	List<Map<String,String>> get_M_Phone_Other_Brand_List();
	List<Map<String,String>> get_M_Phone_Other_Color_List();
	List<Map<String,String>> get_M_Phone_Samsung_Apple_Brand_List();
	List<Map<String,String>> get_M_Phone_Samsung_Apple_Color_List();
	List<Map<String,String>> get_M_Phone_Samsung_Other_Brand_List();
	List<Map<String,String>> get_M_Phone_Samsung_Other_Color_List();
	List<Map<String,String>> get_M_Phone_Apple_Other_Brand_List();
	List<Map<String,String>> get_M_Phone_Apple_Other_Color_List();
	List<Map<String,String>> get_M_Tablet_Android_Brand_List();
	List<Map<String,String>> get_M_Tablet_Android_Color_List();
	List<Map<String,String>> get_M_Tablet_Windows_Brand_List();
	List<Map<String,String>> get_M_Tablet_Windows_Color_List();
	List<Map<String,String>> get_M_Tablet_Ipad_Brand_List();
	List<Map<String,String>> get_M_Tablet_Ipad_Color_List();
	List<Map<String,String>> get_M_Tablet_Android_Windows_Brand_List();
	List<Map<String,String>> get_M_Tablet_Android_Windows_Color_List();
	List<Map<String,String>> get_M_Tablet_Android_Ipad_Brand_List();
	List<Map<String,String>> get_M_Tablet_Android_Ipad_Color_List();
	List<Map<String,String>> get_M_Tablet_Windows_Ipad_Brand_List();
	List<Map<String,String>> get_M_Tablet_Windows_Ipad_Color_List();
	//=====================================================================================================================================================================



	
	// =====================================================================
    //재고 입출력
	public int getInsertStockCnt(ERPStockDTO erpStockDTO);






// mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
// 통계 파트------------------------------------------------------------
// mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	
    // =====================================================================
    // 가전 카테고리 총수량
    // =====================================================================
    public int G_Category_AllCnt();

    // =====================================================================
    // TV 카테고리 총수량
    // =====================================================================
    public int T_Category_AllCnt();
    
    // =====================================================================
    // PC 카테고리 총수량
    // =====================================================================
    public int P_Category_AllCnt();
    
    // =====================================================================
    // 모바일 카테고리 총수량
    // =====================================================================
    public int M_Category_AllCnt();

    
	// =====================================================================
    // ------------------------------10월 24일------------------------------
    // =====================================================================
    // 가전 소분류 Best10 총수량
    // =====================================================================	
    public List<Map<String, String>> G_Sub_Sub_Color_Best_ten_AllList(ERPDTO erpDTO);
	
    // =====================================================================
    // 가전 소분류 Best10 총수량
    // =====================================================================
    public List<Map<String, String>> T_Sub_Sub_Color_Best_ten_AllList(ERPDTO erpDTO);
    
    // =====================================================================
    // 가전 소분류 Best10 총수량
    // =====================================================================
    public List<Map<String, String>> P_Sub_Sub_Color_Best_ten_AllList(ERPDTO erpDTO);
    
    // =====================================================================
    // 가전 소분류 Best10 총수량
    // =====================================================================
    public List<Map<String, String>> M_Sub_Sub_Color_Best_ten_AllList(ERPDTO erpDTO); 
    // =====================================================================
    // ---------------------------------------------------------------------
    // =====================================================================


    //MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM 연도별 입고 총수량 통계
	// =====================================================================
    // 2019년 가전 입고 수량
    // =====================================================================
	public int G_year_2019_CNT();
	
	// =====================================================================
    // 2020년 가전 입고 수량
    // =====================================================================
	public int G_year_2020_CNT();	
	
	// =====================================================================
    // 2021년 가전 입고 수량
    // =====================================================================
	public int G_year_2021_CNT();	


	
	// =====================================================================
    // 2019년 pc 입고 수량
    // =====================================================================
	public int P_year_2019_CNT();
	
	// =====================================================================
    // 2020년 pc 입고 수량
    // =====================================================================
	public int P_year_2020_CNT();	
	
	// =====================================================================
    // 2021년 pc 입고 수량
    // =====================================================================
	public int P_year_2021_CNT();	


	// =====================================================================
    // 2019년 모바일 입고 수량
    // =====================================================================
	public int M_year_2019_CNT();
	
	// =====================================================================
    // 2020년 모바일 입고 수량
    // =====================================================================
	public int M_year_2020_CNT();	
	
	// =====================================================================
    // 2021년 모바일 입고 수량
    // =====================================================================
	public int M_year_2021_CNT();	



	// =====================================================================
    // 2019년 tv 입고 수량
    // =====================================================================
	public int T_year_2019_CNT();
	
	// =====================================================================
    // 2020년 tv 입고 수량
    // =====================================================================
	public int T_year_2020_CNT();	
	
	// =====================================================================
    // 2021년 tv 입고 수량
    // =====================================================================
	public int T_year_2021_CNT();	
	//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM	


	//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM 소분류 별 총수량 통계
    // =====================================================================
    // 가전 소분류 '1'(에어컨)총수량
    // =====================================================================
    public int G_SubSub_Each_AllCnt();
    
    // =====================================================================
    // 가전 소분류 '2'(공기청정)총수량
    // =====================================================================
    public int G_SubSub_Each_AllCnt_2();
    
    // =====================================================================
    // 가전 소분류 '3'(난방기기)총수량
    // =====================================================================
    public int G_SubSub_Each_AllCnt_3();
    
    // =====================================================================
    // 가전 소분류 '4'(냉장고)총수량
    // =====================================================================
    public int G_SubSub_Each_AllCnt_4();
    
    // =====================================================================
    // 가전 소분류 '5'(전기밥솥)총수량
    // =====================================================================
    public int G_SubSub_Each_AllCnt_5();
    
    // =====================================================================
    // 가전 소분류 '6'(에어프라이어)총수량
    // =====================================================================
    public int G_SubSub_Each_AllCnt_6();
    
    // =====================================================================
    // 가전 소분류 '7'(세탁기)총수량
    // =====================================================================
    public int G_SubSub_Each_AllCnt_7();
    
    // =====================================================================
    // 가전 소분류 '8'(건조기)총수량
    // =====================================================================
    public int G_SubSub_Each_AllCnt_8();
    
    // =====================================================================
    // 가전 소분류 '9'(청소기)총수량
    // =====================================================================
    public int G_SubSub_Each_AllCnt_9();
    
    // =====================================================================
    // TV 소분류 '1'(QLED)총수량
    // =====================================================================
    public int T_SubSub_Each_AllCnt();
    
    // =====================================================================
    // TV 소분류 '2'(mini-LED)총수량
    // =====================================================================
    public int T_SubSub_Each_AllCnt_2();
    
    // =====================================================================
    // TV 소분류 '3'(OLED)총수량
    // =====================================================================
    public int T_SubSub_Each_AllCnt_3();
    
    // =====================================================================
    // pc 소분류 '1'(사무용_인강용)총수량
    // =====================================================================
    public int P_SubSub_Each_AllCnt();
    
    // =====================================================================
    // pc 소분류 '2'(게이밍)총수량
    // =====================================================================
    public int P_SubSub_Each_AllCnt_2();
    
    // =====================================================================
    // pc 소분류 '3'(비지니스)총수량
    // =====================================================================
    public int P_SubSub_Each_AllCnt_3();
    
    // =====================================================================
    // pc 소분류 '4'(게이밍노트북)총수량
    // =====================================================================
    public int P_SubSub_Each_AllCnt_4();
    
    // =====================================================================
    // 모바일 소분류 '1'(삼성전자)총수량
    // =====================================================================
    public int M_SubSub_Each_AllCnt();
    
    // =====================================================================
    // 모바일 소분류 '2'(애플)총수량
    // =====================================================================
    public int M_SubSub_Each_AllCnt_2();
    
    // =====================================================================
    // 모바일 소분류 '3'(기타)총수량
    // =====================================================================
    public int M_SubSub_Each_AllCnt_3();
    
    // =====================================================================
    // 모바일 소분류 '4'(안드로이드)총수량
    // =====================================================================
    public int M_SubSub_Each_AllCnt_4();
    
    // =====================================================================
    // 모바일 소분류 '5'(윈도우)총수량
    // =====================================================================
    public int M_SubSub_Each_AllCnt_5();
    
    // =====================================================================
    // 모바일 소분류 '6'(아이패드)총수량
    // =====================================================================
    public int M_SubSub_Each_AllCnt_6();
	 //MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM 브랜드 부분 통계   
    // =====================================================================
    // 가전 선호 브랜드 best 5 총수량
    // =====================================================================
    public List<Map<String,String>> G_SubSub_Best_Brand(ERPDTO erpDTO);
    
    // =====================================================================
    // TV 선호 브랜드 best 5 총수량
    // =====================================================================
    public List<Map<String,String>> T_SubSub_Best_Brand(ERPDTO erpDTO);   

    // =====================================================================
    // PC 선호 브랜드 best 5 총수량
    // =====================================================================
    public List<Map<String,String>> P_SubSub_Best_Brand(ERPDTO erpDTO);
      
    // =====================================================================
    // 모바일 선호 브랜드 best 5 총수량
    // =====================================================================
    public List<Map<String,String>> M_SubSub_Best_Brand(ERPDTO erpDTO);
// mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
// mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm

	



// mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    // 게시판 요약 부분.
    //  아래 메인페이지 재고요약 부분에 전부 포함되어 주석 처리 함.
    //메인에 표기할 주간 게시판 얻는 메소드	
    // public List<Map<String,String>> getWeeklyBoard(ERPSearchDTO erpSearchDTO);

    //재고요약 1번 - 카테고리별 가장 출고량이 많은 품목
    // public List<Map<String,String>> getBestItemByCategory(ERPSearchDTO erpSearchDTO);
// mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm





// mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
// insert all 로 input output 디폴트 수량 0 isert 해주기.
    public int stock_in_out_insert_all(ERPDTO erpDTO);
// mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm





// mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
// 메인페이지 재고요약 순환 부분 
    //홈 게시판에 표기할 게시판 얻는 메소드
	public List<Map<String,String>> getHomeBoardList(ERPHomeDTO erpHomeDTO);

	//홈 재고요약 1번 리스트 검색하는 메소드
	public List<Map<String,String>> getHomeSummarybtnOneList(ERPHomeDTO erpHomeDTO);

	//홈 재고요약 2번 리스트 검색하는 메소드
	public List<Map<String,String>> getHomeSummarybtnTwoList(ERPHomeDTO erpHomeDTO);

	//홈 재고요약 3번 리스트 검색하는 메소드
	public List<Map<String,String>> getHomeSummarybtnThreeList(ERPHomeDTO erpHomeDTO);

	//홈 재고요약 4번 리스트 검색하는 메소드
	public List<Map<String,String>> getHomeSummarybtnFourList(ERPHomeDTO erpHomeDTO);
// mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm












    // ===================================================================================
    // 게시판 DAO 참고용 주석. 삭제하지마시고, 그냥 코드들 참고하시고 위에 코딩 해주세요.
    // ===================================================================================
/*
    // ****************************************************
    // [게시판 글 입력 후 입력 적용 행의 개수] 리턴하는 메소드 선언
    // ****************************************************
    int insertBoard(BoardDTO boardDTO);
	
    // ******************************************************
    // [검색한 게시판 목록] 리턴하는 메소드 선언
    // ******************************************************
    List<Map<String,String>> getBoardList( BoardSearchDTO boardSearchDTO );

    // ******************************************************
    // [1개의 게시판 정보]를 리턴하는 메소드 선언
    // ******************************************************
    BoardDTO getBoard(int b_no);
    // ******************************************************
    // 조회수를 1 증가하고 업데이트한 행의 개수를 얻는 메소드 선언
    // ******************************************************
    int updateReadcount(int b_no);  
    
    // ******************************************************
    // 수정할 게시판의 존재 개수를 리턴하는 
    // ******************************************************
    int getBoardCnt(BoardDTO boardDTO);
    // ******************************************************
    // 수정할 게시판의 비밀번호 존재 개수를 리턴하는 메소드 선언
    // ******************************************************
    int getPwdCnt(BoardDTO boardDTO);
    // ******************************************************
    // 게시판 수정 명령한 후 수정 적용행의 개수를 리턴하는 메소드 선언
    // ******************************************************
    int updateBoard(BoardDTO boardDTO);

    // ******************************************************
    // [삭제할 게시판의 아들글 존재개수]를 얻는 메소드 선언
    // ******************************************************
    int getChildrenCnt(BoardDTO boardDTO);

    // ******************************************************
    // [삭제될 게시판 이후 글의 출력 순서번호를 1씩 감소 시키는 메소드 선언
    // ******************************************************
    int downPrintNo(BoardDTO boardDTO);

    // ******************************************************
    // [게시판 삭제 명령한 후 삭제 적용행의 개수]를 얻는 메소드 선언
    // ******************************************************
    int deleteBoard(BoardDTO boardDTO);

    // ******************************************************
    // [게시판 글 출력번호 1증가하고 수정 행의 개수] 리턴하는 메소드 선언
    // ******************************************************
    int updatePrintNo(BoardDTO boardDTO);

    // ******************************************************
    // [검색한 게시판 목록 총개수] 리턴하는 메소드 선언
    // ******************************************************
    int getBoardListCount(BoardSearchDTO boardSearchDTO);
    
    // ******************************************************
    // 게시판 이미지 이름가져오는 메소드 선언
    // ******************************************************
    public String getPic(BoardDTO boardDTO);
*/

}
