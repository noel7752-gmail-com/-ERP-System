// package com.naver.erp;
package com.daybreak.prj.Util;


public interface Info { 
	
    // <주의> 경로가 문자열이므로 \ 를 \\ 로 써야함. \\ 대신에 / 쓰지 말것.
	public static String board_pic_dir 
		= "C:\\Users\\akskd\\Desktop\\ERP_System_20211110_1711_팔만대장경 삭제 버전_불필요코드 삭제_뷰 추가\\prj\\src\\main\\resources\\static\\resources\\img\\";


	public static String naverPath = "naver/";
	

}

