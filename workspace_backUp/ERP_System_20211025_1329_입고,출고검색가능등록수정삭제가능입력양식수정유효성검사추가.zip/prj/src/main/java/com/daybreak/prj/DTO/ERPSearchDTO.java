package com.daybreak.prj.DTO;


public class ERPSearchDTO {
	
	// 페이징 처리 사용.
	private int selectPageNo =1;
	private int rowCntPerPage=5;
	
	
	// 제품명 검색 테스트.
	private String ITEM_NAME;
	private String ITEM_CODE;

	// 제조일자 검색.
	private String build_date_year_first;
	private String build_date_month_first;
	
	private String build_date_year_last;
	private String build_date_month_last;

	// 입고일자 검색 위한. 년월
	private String input_date_year_first;
	private String input_date_month_first;
	
	private String input_date_year_last;
	private String input_date_month_last;

	// 출고일자 검색위한 년월
	private String output_date_year_first;
	private String output_date_month_first;

	private String output_date_year_last;
	private String output_date_month_last;

	// 카테고리코드 검색
	private String category_code;
	private String[] sub_category_code;
	private String[] sub_sub_category_code;

	// 색상/ 브랜드/ 에너지등급 검색
	private String brand_code;
	private String color_code;
	private String[] energy_grade_code;

	// 단종, 재고수량0 검색
	private String discontinued;
	private String zerostock;

	// 소비전력 검색
	private String power_consum_first;
	private String power_consum_last;
	public int getSelectPageNo() {
		return selectPageNo;
	}
	public void setSelectPageNo(int selectPageNo) {
		this.selectPageNo = selectPageNo;
	}
	public int getRowCntPerPage() {
		return rowCntPerPage;
	}
	public void setRowCntPerPage(int rowCntPerPage) {
		this.rowCntPerPage = rowCntPerPage;
	}
	public String getITEM_NAME() {
		return ITEM_NAME;
	}
	public void setITEM_NAME(String iTEM_NAME) {
		ITEM_NAME = iTEM_NAME;
	}
	public String getITEM_CODE() {
		return ITEM_CODE;
	}
	public void setITEM_CODE(String iTEM_CODE) {
		ITEM_CODE = iTEM_CODE;
	}
	public String getBuild_date_year_first() {
		return build_date_year_first;
	}
	public void setBuild_date_year_first(String build_date_year_first) {
		this.build_date_year_first = build_date_year_first;
	}
	public String getBuild_date_month_first() {
		return build_date_month_first;
	}
	public void setBuild_date_month_first(String build_date_month_first) {
		this.build_date_month_first = build_date_month_first;
	}
	public String getBuild_date_year_last() {
		return build_date_year_last;
	}
	public void setBuild_date_year_last(String build_date_year_last) {
		this.build_date_year_last = build_date_year_last;
	}
	public String getBuild_date_month_last() {
		return build_date_month_last;
	}
	public void setBuild_date_month_last(String build_date_month_last) {
		this.build_date_month_last = build_date_month_last;
	}
	public String getInput_date_year_first() {
		return input_date_year_first;
	}
	public void setInput_date_year_first(String input_date_year_first) {
		this.input_date_year_first = input_date_year_first;
	}
	public String getInput_date_month_first() {
		return input_date_month_first;
	}
	public void setInput_date_month_first(String input_date_month_first) {
		this.input_date_month_first = input_date_month_first;
	}
	public String getInput_date_year_last() {
		return input_date_year_last;
	}
	public void setInput_date_year_last(String input_date_year_last) {
		this.input_date_year_last = input_date_year_last;
	}
	public String getInput_date_month_last() {
		return input_date_month_last;
	}
	public void setInput_date_month_last(String input_date_month_last) {
		this.input_date_month_last = input_date_month_last;
	}
	public String getOutput_date_year_first() {
		return output_date_year_first;
	}
	public void setOutput_date_year_first(String output_date_year_first) {
		this.output_date_year_first = output_date_year_first;
	}
	public String getOutput_date_month_first() {
		return output_date_month_first;
	}
	public void setOutput_date_month_first(String output_date_month_first) {
		this.output_date_month_first = output_date_month_first;
	}
	public String getOutput_date_year_last() {
		return output_date_year_last;
	}
	public void setOutput_date_year_last(String output_date_year_last) {
		this.output_date_year_last = output_date_year_last;
	}
	public String getOutput_date_month_last() {
		return output_date_month_last;
	}
	public void setOutput_date_month_last(String output_date_month_last) {
		this.output_date_month_last = output_date_month_last;
	}
	public String getCategory_code() {
		return category_code;
	}
	public void setCategory_code(String category_code) {
		this.category_code = category_code;
	}
	public String[] getSub_category_code() {
		return sub_category_code;
	}
	public void setSub_category_code(String[] sub_category_code) {
		this.sub_category_code = sub_category_code;
	}
	public String[] getSub_sub_category_code() {
		return sub_sub_category_code;
	}
	public void setSub_sub_category_code(String[] sub_sub_category_code) {
		this.sub_sub_category_code = sub_sub_category_code;
	}
	public String getBrand_code() {
		return brand_code;
	}
	public void setBrand_code(String brand_code) {
		this.brand_code = brand_code;
	}
	public String getColor_code() {
		return color_code;
	}
	public void setColor_code(String color_code) {
		this.color_code = color_code;
	}
	public String[] getEnergy_grade_code() {
		return energy_grade_code;
	}
	public void setEnergy_grade_code(String[] energy_grade_code) {
		this.energy_grade_code = energy_grade_code;
	}
	public String getDiscontinued() {
		return discontinued;
	}
	public void setDiscontinued(String discontinued) {
		this.discontinued = discontinued;
	}
	public String getZerostock() {
		return zerostock;
	}
	public void setZerostock(String zerostock) {
		this.zerostock = zerostock;
	}
	public String getPower_consum_first() {
		return power_consum_first;
	}
	public void setPower_consum_first(String power_consum_first) {
		this.power_consum_first = power_consum_first;
	}
	public String getPower_consum_last() {
		return power_consum_last;
	}
	public void setPower_consum_last(String power_consum_last) {
		this.power_consum_last = power_consum_last;
	}
	
	
	
	//====================================================================
	


















	



























	// ===================================================================================
    // 게시판 SearchDTO 참고용 주석. 삭제하지마시고, 그냥 코드들 참고하시고 위에 코딩 해주세요.
    // ===================================================================================
/*
	// -------------------------------------------------
	// [검색 키워드] 저장하는 속성변수 선언
	// 현재 [선택된 페이지 번호]를 저장하는 속성변수 선언.
	// 한 화면에 보여줄 [행의 개수]를 저장하는 속성변수 선언.
	// -------------------------------------------------
	private String keyword1;		// 키워드1가 저장될 속성변수
	private String keyword2;		// 키워드2가 저장될 속성변수

	private String orAnd;			// 두개의 키워드 사이에 들어갈 or 또는 and 가 저장되는 속성변수.    

	private int selectPageNo=1;		// 유저가 선택한 페이지번호가 저장되는 속성변수. 반드시 디폴트값이 있어야 DB 연동시 에러가 없다. DB연동하여 처음화면을 보여준다.
	private int rowCntPerPage=10;	// 한 화면에 보여줄 행의 개수가 저장되는 속성변수. 반드시 디폴트값이 있어야 DB 연동시 에러가 없다. DB연동하여 처음화면을 보여준다.
	
	// private String[] day;  // 배열로 받을수 있다. 아래코드와 이 코드 방식 두가지로 체크박스르 담을 수 있다.  
	private List<String> day; 		// 어제 또는 오늘 또는 그제, 등등이 저장되는 변수. checkbox 입력양식 값이 들어올때는 ArrayList 가 받는다.  
	private String sort;			// 등록일 관련 정렬 데이터가 저장되는 속성변수 선언. reg_date desc 또는 reg_date asc 가 저장된다.  

	// -------------------------------------------------
	// getter, setter 메소드 선언
	// -------------------------------------------------
	
	public String getKeyword1() {
		return keyword1;
	}
	public void setKeyword1(String keyword1) {
		this.keyword1 = keyword1;
	}
	public String getKeyword2() {
		return keyword2;
	}
	public void setKeyword2(String keyword2) {
		this.keyword2 = keyword2;
	}
	public String getOrAnd() {
		return orAnd;
	}
	public void setOrAnd(String orAnd) {
		this.orAnd = orAnd;
	}
	public int getSelectPageNo() {
		return selectPageNo;
	}
	public void setSelectPageNo(int selectPageNo) {
		this.selectPageNo = selectPageNo;
	}
	public int getRowCntPerPage() {
		return rowCntPerPage;
	}
	public void setRowCntPerPage(int rowCntPerPage) {
		this.rowCntPerPage = rowCntPerPage;
	}
	public List<String> getDay() {
		return day;
	}
	public void setDay(List<String> day) {
		this.day = day;
	}
	public String getSort() {
		return sort;
	}
	public void setSort(String sort) {
		this.sort = sort;
	}
*/
    
}
